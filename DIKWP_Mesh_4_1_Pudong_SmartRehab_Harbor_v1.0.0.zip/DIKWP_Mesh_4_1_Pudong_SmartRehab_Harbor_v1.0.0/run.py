#!/usr/bin/env python3
from smart_harbor.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
