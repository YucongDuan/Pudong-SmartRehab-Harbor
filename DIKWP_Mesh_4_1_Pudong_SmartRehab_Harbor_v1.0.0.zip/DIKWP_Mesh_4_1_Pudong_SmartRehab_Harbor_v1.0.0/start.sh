#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
exec python run.py serve
