#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
errors=[]
for item in manifest['files']:
 p=ROOT/item['path']
 if not p.is_file(): errors.append({'path':item['path'],'error':'missing'}); continue
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if p.stat().st_size!=item['size'] or h!=item['sha256']:
  errors.append({'path':item['path'],'error':'mismatch','size':p.stat().st_size,'sha256':h})
print(json.dumps({'valid':not errors,'checked':len(manifest['files']),'errors':errors},ensure_ascii=False,indent=2))
raise SystemExit(0 if not errors else 1)
