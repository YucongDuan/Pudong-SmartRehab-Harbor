#!/usr/bin/env python3
from __future__ import annotations

import compileall
import hashlib
import http.client
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.parse
from contextlib import closing
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(parents=True, exist_ok=True)

CHECKS: list[dict[str, Any]] = []


def check(group: str, name: str, condition: bool, detail: Any = None) -> None:
    item = {"group": group, "name": name, "passed": bool(condition)}
    if detail is not None:
        item["detail"] = detail
    CHECKS.append(item)


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def free_port() -> int:
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def http_request(port: int, method: str, path: str, *, token: str | None = None, body: Any = None) -> tuple[int, dict[str, str], Any]:
    headers: dict[str, str] = {}
    raw = None
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if body is not None:
        raw = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    conn.request(method, path, body=raw, headers=headers)
    response = conn.getresponse()
    payload_raw = response.read()
    response_headers = {k.lower(): v for k, v in response.getheaders()}
    conn.close()
    try:
        payload = json.loads(payload_raw.decode("utf-8")) if payload_raw else {}
    except Exception:
        payload = payload_raw.decode("utf-8", errors="replace")
    return response.status, response_headers, payload


def run_compile_checks() -> None:
    ok = compileall.compile_dir(str(ROOT / "smart_harbor"), quiet=1, force=True)
    check("compile", "backend Python modules compile", ok)
    ok_tests = compileall.compile_dir(str(ROOT / "tests"), quiet=1, force=True)
    check("compile", "test modules compile", ok_tests)
    result = subprocess.run(["node", "--check", str(ROOT / "web" / "app.js")], capture_output=True, text=True)
    check("compile", "frontend JavaScript syntax", result.returncode == 0, result.stderr.strip() or "node --check passed")


def run_unit_tests() -> None:
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    loader = unittest.TestLoader()
    suite = loader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    result = unittest.TestResult()
    old_env = os.environ.get("SMART_HARBOR_QUIET")
    os.environ["SMART_HARBOR_QUIET"] = "1"
    try:
        suite.run(result)
    finally:
        if old_env is None:
            os.environ.pop("SMART_HARBOR_QUIET", None)
        else:
            os.environ["SMART_HARBOR_QUIET"] = old_env
    for test, traceback_text in result.failures:
        check("unit_api", str(test), False, traceback_text[-1500:])
    for test, traceback_text in result.errors:
        check("unit_api", str(test), False, traceback_text[-1500:])
    failed_ids = {str(t) for t, _ in result.failures + result.errors}
    # Record one check for each executed test so the check count remains transparent.
    for test in _flatten_tests(loader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))):
        name = str(test)
        if name not in failed_ids:
            check("unit_api", name, True)
    check("unit_api", "test suite executed 19 tests", result.testsRun == 19, {"tests_run": result.testsRun})


def _flatten_tests(suite: unittest.TestSuite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from _flatten_tests(item)
        else:
            yield item


def run_schema_checks() -> None:
    try:
        from jsonschema import Draft202012Validator
    except Exception as exc:
        check("schema", "jsonschema dependency available", False, str(exc))
        return
    schemas: dict[str, Any] = {}
    for path in sorted((ROOT / "schemas").glob("*.json")):
        try:
            schema = load_json(path)
            Draft202012Validator.check_schema(schema)
            schemas[path.name] = schema
            check("schema", f"meta-schema valid: {path.name}", True)
        except Exception as exc:
            check("schema", f"meta-schema valid: {path.name}", False, str(exc))
    mapping = {
        "strategy_initiative": "strategy-initiative.schema.json",
        "device": "device.schema.json",
        "rehab_episode": "rehab-episode.schema.json",
        "rehab_session": "rehab-session.schema.json",
        "technique_capture": "technique-capture.schema.json",
        "eras_episode": "eras-episode.schema.json",
        "research_protocol": "research-protocol.schema.json",
        "ethics_review": "ethics-review.schema.json",
        "biospecimen": "biospecimen.schema.json",
        "referral": "referral.schema.json",
        "device_ingest_batch": "device-ingest-batch.schema.json",
    }
    resources = load_json(ROOT / "data" / "demo_resources.json")["resources"]
    for resource in resources:
        schema = schemas.get(mapping.get(resource["resource_type"], "resource-type-index.schema.json"))
        errors = sorted(Draft202012Validator(schema).iter_errors(resource), key=lambda e: list(e.path))
        check("schema", f"demo resource: {resource['resource_type']}/{resource['resource_id']}", not errors,
              [f"{list(e.path)}: {e.message}" for e in errors[:5]] if errors else None)
    pairs = [
        ("data/source_register.json", "source-register.schema.json"),
        ("data/strategy_profile.json", "strategy-profile.schema.json"),
        ("examples/device_telemetry_batch.json", "telemetry-batch.schema.json"),
        ("examples/mesh_analysis.json", "mesh-analysis.schema.json"),
        ("examples/rehab_fhir_bundle.json", "fhir-bundle-lite.schema.json"),
        ("examples/research_fhir_bundle.json", "fhir-bundle-lite.schema.json"),
    ]
    for rel, schema_name in pairs:
        errors = sorted(Draft202012Validator(schemas[schema_name]).iter_errors(load_json(ROOT / rel)), key=lambda e: list(e.path))
        check("schema", f"artifact validation: {rel}", not errors,
              [f"{list(e.path)}: {e.message}" for e in errors[:5]] if errors else None)


def run_catalog_checks() -> None:
    strategy = load_json(ROOT / "data" / "strategy_profile.json")
    rehab = load_json(ROOT / "data" / "rehab_profiles.json")
    devices = load_json(ROOT / "data" / "device_catalog.json")
    eras = load_json(ROOT / "data" / "eras_templates.json")
    research = load_json(ROOT / "data" / "research_programs.json")
    governance = load_json(ROOT / "data" / "governance_rules.json")
    sources = load_json(ROOT / "data" / "source_register.json")
    demos = load_json(ROOT / "data" / "demo_resources.json")
    checks = [
        ("four campus mappings", len(strategy["campuses"]) == 4, len(strategy["campuses"])),
        ("seven strategic portfolios", len(strategy["portfolios"]) == 7, len(strategy["portfolios"])),
        ("six rehabilitation axes", len(rehab["axes"]) == 6, len(rehab["axes"])),
        ("22 rehabilitation metrics", len(rehab["metric_catalog"]) == 22, len(rehab["metric_catalog"])),
        ("eight rehabilitation modalities", len(rehab["modalities"]) == 8, len(rehab["modalities"])),
        ("eight device types", len(devices["device_types"]) == 8, len(devices["device_types"])),
        ("four device adapters", len(devices["adapters"]) == 4, len(devices["adapters"])),
        ("two CM-ERAS templates", len(eras["templates"]) == 2, len(eras["templates"])),
        ("four research programs", len(research["programs"]) == 4, len(research["programs"])),
        ("ten source records", len(sources["sources"]) == 10, len(sources["sources"])),
        ("25 DIKWP channels", len(governance["dikwp_channels"]) == 25, len(governance["dikwp_channels"])),
        ("19 synthetic demo resources", len(demos["resources"]) == 19, len(demos["resources"])),
        ("no scalar without source weights", governance.get("no_scalar_without_weights") is True, governance.get("no_scalar_without_weights")),
        ("demo bundle marked synthetic", demos.get("synthetic_only") is True, demos.get("synthetic_only")),
    ]
    for name, ok, detail in checks:
        check("catalog", name, ok, detail)
    uniqueness_sets = [
        ("campus_id", [x["campus_id"] for x in strategy["campuses"]]),
        ("initiative_id", [x["initiative_id"] for x in strategy["portfolios"]]),
        ("axis_id", [x["axis_id"] for x in rehab["axes"]]),
        ("metric code", [x["code"] for x in rehab["metric_catalog"]]),
        ("adapter_id", [x["adapter_id"] for x in devices["adapters"]]),
        ("device_type code", [x["device_type"] for x in devices["device_types"]]),
        ("template_id", [x["template_id"] for x in eras["templates"]]),
        ("program_id", [x["program_id"] for x in research["programs"]]),
        ("source_id", [x["source_id"] for x in sources["sources"]]),
        ("demo resource tuple", [(x["resource_type"], x["resource_id"]) for x in demos["resources"]]),
    ]
    for name, values in uniqueness_sets:
        check("catalog", f"unique {name}", len(values) == len(set(values)), {"count": len(values)})
    expected_channels = {f"{a}→{b}" for a in "DIKWP" for b in "DIKWP"}
    actual_channels = {x["channel"] if isinstance(x, dict) else x for x in governance["dikwp_channels"]}
    check("catalog", "complete directed DIKWP Cartesian product", actual_channels == expected_channels,
          {"missing": sorted(expected_channels - actual_channels), "extra": sorted(actual_channels - expected_channels)})


def run_static_boundary_checks() -> None:
    files = {p.relative_to(ROOT).as_posix(): p.read_text(encoding="utf-8") for p in (ROOT / "smart_harbor").glob("*.py")}
    joined = "\n".join(files.values())
    assertions = [
        ("clinical execution is server-side blocked", "telemetry ingest cannot authorize clinical device execution" in joined),
        ("real human recruitment is blocked", "does not execute real human recruitment" in joined),
        ("non-synthetic biospecimens are blocked", "only stores synthetic biospecimen demonstrations" in joined),
        ("human review false is blocked", "human_review_required" in files["smart_harbor/safety.py"]),
        ("autonomous treatment field scanning exists", "PROHIBITED_TRUE_KEYS" in files["smart_harbor/safety.py"] and "PROHIBITED_PARAMETER_KEYS" in files["smart_harbor/safety.py"]),
        ("optimistic revision conflict exists", "RevisionConflict" in files["smart_harbor/db.py"]),
        ("audit chain uses previous hash", "previous_hash" in files["smart_harbor/db.py"] and "event_hash" in files["smart_harbor/db.py"]),
        ("FHIR export marks local extensions", "extension" in files["smart_harbor/fhir.py"]),
        ("mesh counterfactual kernel exists", "intent_conditioned_kernel" in files["smart_harbor/mesh.py"]),
        ("25-channel source catalog is used", "DIKWP_CHANNELS" in files["smart_harbor/mesh.py"]),
        ("runtime has no requests dependency", "import requests" not in joined),
        ("runtime has no external LLM client", all(x not in joined for x in ["openai", "anthropic", "langchain"])),
    ]
    for name, ok in assertions:
        check("static_boundary", name, ok)
    html = (ROOT / "web" / "index.html").read_text(encoding="utf-8")
    js = (ROOT / "web" / "app.js").read_text(encoding="utf-8")
    check("static_boundary", "no inline JavaScript in index", "<script>" not in html and 'src="/app.js"' in html)
    check("static_boundary", "frontend escapes interpolated text", "function esc(value)" in js)
    check("static_boundary", "frontend exposes nine work areas", html.count('data-view="') == 9, html.count('data-view="'))
    docs_required = [
        "README.md", "openapi.yaml", "docs/00_interview_to_system_traceability.md",
        "docs/01_system_architecture.md", "docs/02_operational_workflows.md",
        "docs/03_data_dictionary.md", "docs/04_device_integration_contract.md",
        "docs/05_translational_research_governance.md", "docs/06_campus_operating_model.md",
        "docs/07_deployment_operations.md", "docs/08_acceptance_criteria.md",
        "docs/09_api_reference.md", "docs/10_security_privacy_audit.md",
        "docs/11_clinical_research_boundary.md", "docs/12_dikwp_mesh_41_runtime.md",
        "docs/13_configuration_guide.md",
    ]
    for rel in docs_required:
        path = ROOT / rel
        check("documentation", f"present and nonempty: {rel}", path.is_file() and path.stat().st_size > 200,
              path.stat().st_size if path.exists() else 0)


def run_openapi_checks() -> None:
    try:
        import yaml
        spec = yaml.safe_load((ROOT / "openapi.yaml").read_text(encoding="utf-8"))
        check("openapi", "OpenAPI YAML parses", isinstance(spec, dict))
        check("openapi", "OpenAPI version 3.1", spec.get("openapi") == "3.1.0", spec.get("openapi"))
        paths = spec.get("paths", {})
        check("openapi", "at least 25 documented paths", len(paths) >= 25, len(paths))
        for route in ["/api/health", "/api/resources", "/api/rehab/{episode_id}/simulate", "/api/device-ingest/{device_id}", "/api/mesh", "/api/fhir/{resource_type}/{resource_id}", "/api/audit/verify"]:
            check("openapi", f"documented route: {route}", route in paths)
    except Exception as exc:
        check("openapi", "OpenAPI YAML parses", False, str(exc))


def run_http_acceptance() -> None:
    port = free_port()
    with tempfile.TemporaryDirectory(prefix="smart-harbor-http-") as td:
        env = os.environ.copy()
        env.update({
            "SMART_HARBOR_DB": str(Path(td) / "acceptance.db"),
            "SMART_HARBOR_PORT": str(port),
            "SMART_HARBOR_HOST": "127.0.0.1",
            "SMART_HARBOR_QUIET": "1",
            "PYTHONPATH": str(ROOT),
        })
        proc = subprocess.Popen([sys.executable, "run.py", "serve", "--host", "127.0.0.1", "--port", str(port)], cwd=ROOT, env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            ready = False
            for _ in range(80):
                if proc.poll() is not None:
                    break
                try:
                    status, _, payload = http_request(port, "GET", "/api/health")
                    if status == 200:
                        ready = True
                        break
                except OSError:
                    pass
                time.sleep(0.05)
            check("http", "server starts from a clean database", ready, {"returncode": proc.poll(), "port": port})
            if not ready:
                return
            status, headers, health = http_request(port, "GET", "/api/health")
            check("http", "GET /api/health", status == 200 and health.get("status") == "ok")
            check("http", "health exposes 25 channels", health.get("dikwp_mesh", {}).get("channel_count") == 25)
            check("http", "initial audit chain valid", health.get("audit_chain", {}).get("valid") is True)
            status, headers, _ = http_request(port, "HEAD", "/")
            check("http", "HEAD /", status == 200 and "content-security-policy" in headers, headers)
            status, _, html = http_request(port, "GET", "/")
            check("http", "GET browser workbench", status == 200 and "SmartRehab Harbor" in str(html))
            status, _, unauthorized = http_request(port, "GET", "/api/dashboard")
            check("http", "protected route rejects missing token", status == 401, unauthorized)
            status, _, login = http_request(port, "POST", "/api/auth/login", body={"username": "admin", "password": "mesh41-demo"})
            token = login.get("token") if isinstance(login, dict) else None
            check("http", "demo admin login", status == 200 and bool(token), login.get("principal") if isinstance(login, dict) else login)
            if not token:
                return
            status, _, dashboard = http_request(port, "GET", "/api/dashboard", token=token)
            check("http", "dashboard returns seven portfolios", status == 200 and len(dashboard.get("portfolio_runtime", [])) == 7)
            status, _, strategy = http_request(port, "GET", "/api/strategy", token=token)
            check("http", "strategy returns four campuses", status == 200 and len(strategy.get("profile", {}).get("campuses", [])) == 4)
            for catalog in ["rehab", "devices", "eras", "research", "governance", "sources"]:
                status, _, payload = http_request(port, "GET", f"/api/catalog/{catalog}", token=token)
                check("http", f"catalog endpoint: {catalog}", status == 200 and isinstance(payload, dict))
            status, _, resource = http_request(port, "GET", "/api/resources/rehab_episode/REHAB-STROKE-001", token=token)
            revision = resource.get("revision")
            check("http", "read seeded rehab episode", status == 200 and isinstance(revision, int), revision)
            sim_body = {"expected_revision": revision, "session_id": "HTTP-SYN-001", "device_id": "DEV-HUMANOID-001", "sample_count": 80,
                        "approved_session": True, "operator_present": True, "consent_current": True, "calibration_current": True,
                        "emergency_stop_verified": True, "stop_conditions_recorded": True}
            status, _, simulation = http_request(port, "POST", "/api/rehab/REHAB-STROKE-001/simulate", token=token, body=sim_body)
            check("http", "synthetic rehabilitation simulation", status == 200 and simulation.get("telemetry_sample_count", 0) > 0,
                  simulation.get("telemetry_sample_count") if isinstance(simulation, dict) else simulation)
            status, _, telemetry = http_request(port, "GET", "/api/telemetry/HTTP-SYN-001", token=token)
            check("http", "simulation telemetry persisted", status == 200 and len(telemetry.get("items", [])) > 0)
            status, _, comparison = http_request(port, "POST", "/api/techniques/compare", token=token,
                                                  body={"left_id": "TECH-TUINA-001", "right_id": "TECH-TUINA-002"})
            check("http", "technique trajectories compare", status == 200 and comparison.get("method") == "linear_resampling_plus_rmse" and comparison.get("no_scalar_mastery_score") is True)
            status, _, mesh = http_request(port, "GET", "/api/mesh?intent=" + urllib.parse.quote("人形康复智慧港关系失效"), token=token)
            check("http", "mesh builds 25-channel catalog", status == 200 and mesh.get("channel_count") == 25)
            check("http", "mesh contains counterfactual kernel", bool(mesh.get("intent_conditioned_kernel")))
            status, headers, bundle = http_request(port, "GET", "/api/fhir/rehab_episode/REHAB-STROKE-001", token=token)
            check("http", "FHIR bundle export", status == 200 and bundle.get("resourceType") == "Bundle" and bundle.get("type") == "collection")
            check("http", "FHIR media type", headers.get("content-type", "").startswith("application/fhir+json"), headers.get("content-type"))
            bad_ingest = {"session_id": "ILLEGAL-HUMAN", "subject_kind": "patient", "clinical_execution": True,
                          "samples": [{"sequence": 0, "channel": "assistance_force", "numeric_value": 1.0, "unit": "N"}]}
            status, _, rejected = http_request(port, "POST", "/api/device-ingest/DEV-HUMANOID-001", token=token, body=bad_ingest)
            check("http", "human clinical device ingest is rejected", status == 422, rejected)
            status, _, audit = http_request(port, "GET", "/api/audit/verify", token=token)
            check("http", "audit chain remains valid after writes", status == 200 and audit.get("valid") is True, audit)
            # Restart-safe seed test through health count persistence.
            initial_counts = health.get("resource_counts", {})
            status, _, health_after = http_request(port, "GET", "/api/health")
            check("http", "resource store remains populated", sum(health_after.get("resource_counts", {}).values()) >= sum(initial_counts.values()))
            acceptance = {"port": port, "health": health_after, "dashboard": dashboard, "audit": audit}
            (OUTPUTS / "http_acceptance.json").write_text(json.dumps(acceptance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)


def run_cleanliness_checks() -> None:
    forbidden = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if "__pycache__" in rel or path.suffix in {".pyc", ".pyo", ".db"} or rel.endswith((".db-wal", ".db-shm")):
            forbidden.append(rel)
    check("cleanliness", "no runtime database/cache artifacts", not forbidden, forbidden)
    check("cleanliness", "var placeholder exists", (ROOT / "var" / ".gitkeep").is_file())
    check("cleanliness", "outputs placeholder exists", (ROOT / "outputs" / ".gitkeep").is_file())


def write_summary() -> int:
    passed = sum(1 for item in CHECKS if item["passed"])
    failed = len(CHECKS) - passed
    groups: dict[str, dict[str, int]] = {}
    for item in CHECKS:
        g = groups.setdefault(item["group"], {"passed": 0, "failed": 0, "total": 0})
        g["total"] += 1
        g["passed" if item["passed"] else "failed"] += 1
    summary = {
        "project": "DIKWP-Mesh 4.1 Pudong SmartRehab Harbor",
        "version": "1.0.0",
        "generated_at_epoch": int(time.time()),
        "passed": passed,
        "failed": failed,
        "total": len(CHECKS),
        "groups": groups,
        "checks": CHECKS,
        "boundary": "Engineering QA verifies the bundled synthetic prototype; it does not establish clinical validity, hospital acceptance, regulatory clearance or production cybersecurity.",
    }
    (OUTPUTS / "qa_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: summary[k] for k in ["passed", "failed", "total", "groups"]}, ensure_ascii=False, indent=2))
    return 0 if failed == 0 else 1


def main() -> int:
    run_compile_checks()
    run_unit_tests()
    run_schema_checks()
    run_catalog_checks()
    run_static_boundary_checks()
    run_openapi_checks()
    run_http_acceptance()
    # Remove compile artifacts before cleanliness and release packaging.
    for path in sorted(ROOT.rglob("__pycache__"), reverse=True):
        for child in path.iterdir():
            child.unlink()
        path.rmdir()
    run_cleanliness_checks()
    return write_summary()


if __name__ == "__main__":
    raise SystemExit(main())
