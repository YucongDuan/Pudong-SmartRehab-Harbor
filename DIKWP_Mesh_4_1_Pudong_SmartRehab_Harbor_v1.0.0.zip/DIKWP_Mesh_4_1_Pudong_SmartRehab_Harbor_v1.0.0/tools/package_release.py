#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/f"{ROOT.name}.zip"
subprocess.run([sys.executable,str(ROOT/'tools'/'generate_manifest.py')],check=True,cwd=ROOT)
for path in ROOT.rglob('__pycache__'):
 shutil.rmtree(path,ignore_errors=True)
for path in ROOT.rglob('*'):
 if path.is_file() and (path.suffix in {'.pyc','.pyo','.db'} or path.name.endswith(('.db-wal','.db-shm'))):
  path.unlink()
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
 for path in sorted(ROOT.rglob('*')):
  if path.is_file(): zf.write(path,arcname=f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}")
bad=None
with zipfile.ZipFile(OUT) as zf: bad=zf.testzip()
if bad: raise RuntimeError(f'zip corruption: {bad}')
digest=hashlib.sha256(OUT.read_bytes()).hexdigest()
sha=OUT.with_suffix(OUT.suffix+'.sha256')
sha.write_text(f"{digest}  {OUT.name}\n",encoding='utf-8')
print(json.dumps({'zip':str(OUT),'sha256':digest,'size':OUT.stat().st_size},ensure_ascii=False,indent=2))
