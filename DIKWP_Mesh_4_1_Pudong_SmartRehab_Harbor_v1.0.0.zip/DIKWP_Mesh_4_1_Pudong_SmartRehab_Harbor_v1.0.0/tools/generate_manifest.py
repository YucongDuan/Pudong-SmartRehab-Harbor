#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE = {"manifest.json", "SHA256SUMS"}
EXCLUDE_PARTS = {"__pycache__", ".git"}

def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

files = []
for path in sorted(ROOT.rglob("*")):
    if not path.is_file():
        continue
    rel = path.relative_to(ROOT).as_posix()
    if path.name in EXCLUDE or any(part in EXCLUDE_PARTS for part in path.parts):
        continue
    if path.suffix in {".pyc", ".pyo", ".db"} or rel.endswith((".db-wal", ".db-shm")):
        continue
    files.append({"path": rel, "size": path.stat().st_size, "sha256": digest(path)})
manifest = {
    "project": "DIKWP-Mesh 4.1 Pudong SmartRehab Harbor",
    "version": "1.0.0",
    "file_count": len(files),
    "files": files,
    "boundary": "Manifest covers release files before manifest and SHA256SUMS are added.",
}
(ROOT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
(ROOT / "SHA256SUMS").write_text("".join(f"{item['sha256']}  {item['path']}\n" for item in files), encoding="utf-8")
print(json.dumps({"file_count": len(files)}, ensure_ascii=False))
