from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from smart_harbor.app import SmartHarborApplication
from smart_harbor.auth import DEMO_USERS, AuthenticationError, authenticate
from smart_harbor.catalog import catalog_summary, load_catalogs
from smart_harbor.db import RevisionConflict, SmartHarborStore
from smart_harbor.domain import DIKWP_CHANNELS
from smart_harbor.fhir import export_fhir_bundle
from smart_harbor.safety import SafetyValidationError, validate_common


class SmartHarborCoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tempdir = tempfile.TemporaryDirectory()
        self.db = Path(self.tempdir.name) / "test.db"
        self.store = SmartHarborStore(self.db)
        self.app = SmartHarborApplication(self.store)
        self.admin = DEMO_USERS["admin"]
        self.app.seed_demos_if_empty()

    def tearDown(self) -> None:
        self.tempdir.cleanup()

    def test_catalog_integrity_and_25_channels(self) -> None:
        catalogs = load_catalogs()
        summary = catalog_summary(catalogs)
        self.assertEqual(summary["campuses"], 4)
        self.assertEqual(summary["portfolios"], 7)
        self.assertEqual(summary["rehab_axes"], 6)
        self.assertEqual(summary["dikwp_channels"], 25)
        self.assertEqual(tuple(catalogs["governance"]["dikwp_channels"]), DIKWP_CHANNELS)

    def test_seed_is_idempotent_and_restart_safe(self) -> None:
        first_counts = self.store.count_resources()
        result = self.app.seed_demos_if_empty()
        self.assertFalse(result["seeded"])
        reopened = SmartHarborApplication(SmartHarborStore(self.db))
        self.assertEqual(reopened.store.count_resources(), first_counts)
        self.assertEqual(reopened.store.get_resource("rehab_episode", "REHAB-STROKE-001")["revision"], 1)

    def test_authentication(self) -> None:
        principal = authenticate("admin", "mesh41-demo")
        self.assertEqual(principal.role, "admin")
        with self.assertRaises(AuthenticationError):
            authenticate("admin", "bad")

    def test_autonomous_flags_and_treatment_parameters_are_rejected(self) -> None:
        with self.assertRaises(SafetyValidationError):
            validate_common({"human_review_required": True, "autonomous_diagnosis": True})
        with self.assertRaises(SafetyValidationError):
            validate_common({"human_review_required": True, "needle_depth": "20mm"})
        with self.assertRaises(SafetyValidationError):
            validate_common({"human_review_required": False})

    def test_rehab_analysis_assessment_and_counterfactual_kernel(self) -> None:
        record = self.store.get_resource("rehab_episode", "REHAB-STROKE-001")
        result = self.app.add_rehab_assessment(
            "REHAB-STROKE-001",
            {
                "metric_code": "home_role_status",
                "value": "可完成简单家务",
                "raw_expression": "希望重新完成简单家务",
                "observer": "patient_proxy",
            },
            record["revision"],
            self.admin,
        )
        analysis = result["resource"]["analysis"]
        axis_c = next(item for item in analysis["axis_coverage"] if item["axis_id"] == "AXIS-C")
        self.assertTrue(axis_c["covered"])
        self.assertGreater(analysis["intent_conditioned_kernel"]["kernel_size"], 0)
        self.assertTrue(analysis["reliability"]["no_scalar_without_weights"])

    def test_revision_conflict(self) -> None:
        record = self.store.get_resource("rehab_episode", "REHAB-STROKE-001")
        self.app.add_rehab_assessment(
            "REHAB-STROKE-001",
            {"metric_code": "home_role_status", "value": "合成", "observer": "patient_proxy"},
            record["revision"],
            self.admin,
        )
        with self.assertRaises(RevisionConflict):
            self.app.add_rehab_assessment(
                "REHAB-STROKE-001",
                {"metric_code": "home_role_status", "value": "冲突", "observer": "patient_proxy"},
                record["revision"],
                self.admin,
            )

    def test_rehab_simulator_and_telemetry(self) -> None:
        episode = self.store.get_resource("rehab_episode", "REHAB-STROKE-001")
        session = self.store.get_resource("rehab_session", "SESSION-REHAB-001")
        result = self.app.simulate_rehab(
            "REHAB-STROKE-001",
            {
                "session_id": "SESSION-REHAB-001",
                "expected_session_revision": session["revision"],
                "sample_count": 50,
            },
            episode["revision"],
            self.admin,
        )
        # Four channels per frame; simulator enforces a minimum of 20 frames.
        self.assertEqual(result["telemetry_sample_count"], 200)
        self.assertTrue(result["simulation"]["simulation_executed"])
        samples = self.store.list_telemetry("SESSION-REHAB-001")
        self.assertEqual(len(samples), 200)
        self.assertEqual({item["channel"] for item in samples}, {"joint_angle", "assistance_force", "balance_proxy", "fatigue_proxy"})

    def test_generic_device_ingest_and_scope_gate(self) -> None:
        result = self.app.ingest_device_telemetry(
            "DEV-HUMANOID-001",
            {
                "session_id": "EXT-SESSION-001",
                "subject_kind": "synthetic",
                "samples": [
                    {"sequence": 0, "recorded_at": "T+0", "channel": "joint_angle", "numeric_value": 32, "unit": "degree"},
                    {"sequence": 1, "recorded_at": "T+1", "channel": "joint_angle", "numeric_value": 35, "unit": "degree"},
                ],
            },
            self.admin,
        )
        self.assertEqual(result["telemetry"]["sample_count"], 2)
        self.assertFalse(result["clinical_execution_authorized"])
        self.assertEqual(result["batch"]["resource"]["channel_counts"], {"joint_angle": 2})
        with self.assertRaises(SafetyValidationError):
            self.app.ingest_device_telemetry(
                "DEV-HUMANOID-001",
                {"session_id": "BAD", "subject_kind": "patient", "samples": [{"channel": "joint_angle", "numeric_value": 1}]},
                self.admin,
            )

    def test_technique_capture_and_comparison(self) -> None:
        left = self.store.get_resource("technique_capture", "TECH-TUINA-001")
        result = self.app.simulate_technique("TECH-TUINA-001", {"sample_count": 60}, left["revision"], self.admin)
        self.assertEqual(result["telemetry_sample_count"], 240)
        comparison = self.app.compare_techniques({"left_id": "TECH-TUINA-001", "right_id": "TECH-TUINA-002"}, self.admin)
        self.assertTrue(comparison["no_scalar_mastery_score"])
        self.assertEqual(len(comparison["channel_comparison"]), 4)

    def test_eras_checkpoint(self) -> None:
        record = self.store.get_resource("eras_episode", "ERAS-CRC-001")
        result = self.app.add_eras_checkpoint(
            "ERAS-CRC-001",
            {"phase_id": "preop", "code": "nutrition_plan_reference", "status": "complete", "raw_expression": "合成人工记录"},
            record["revision"],
            self.admin,
        )
        self.assertEqual(result["added_checkpoint"]["code"], "nutrition_plan_reference")
        self.assertFalse(result["resource"]["analysis"]["clinical_order_generation"])

    def test_research_transition_ethics_and_synthetic_biospecimen(self) -> None:
        record = self.store.get_resource("research_protocol", "RP-THYROID-001")
        transitioned = self.app.transition_research(
            "RP-THYROID-001",
            {"target_state": "ethics_review", "reason": "合成人工迁移"},
            record["revision"],
            self.admin,
        )
        self.assertEqual(transitioned["resource"]["status"], "ethics_review")
        reviewed = self.app.record_ethics(
            "RP-THYROID-001",
            {"decision": "approved_with_conditions", "committee_reference": "SYN-IRB", "synthetic_only": True},
            transitioned["revision"],
            self.admin,
        )
        self.assertEqual(reviewed["ethics_review"]["resource"]["decision"], "approved_with_conditions")
        current = self.store.get_resource("research_protocol", "RP-THYROID-001")
        specimen = self.app.add_research_biospecimen(
            "RP-THYROID-001",
            {"subject_kind": "synthetic", "specimen_type": "synthetic_organoid", "storage_location": "SIM-A01"},
            current["revision"],
            self.admin,
        )
        self.assertEqual(specimen["biospecimen"]["resource"]["subject_kind"], "synthetic")
        with self.assertRaises(SafetyValidationError):
            self.app.transition_research(
                "RP-THYROID-001",
                {"target_state": "recruiting", "reason": "must be rejected"},
                self.store.get_resource("research_protocol", "RP-THYROID-001")["revision"],
                self.admin,
            )

    def test_mesh_and_fhir(self) -> None:
        mesh = self.app.relation_mesh("人形康复智慧港闭环", self.admin)
        self.assertEqual(mesh["channel_count"], 25)
        self.assertGreater(len(mesh["nodes"]), 0)
        self.assertTrue(mesh["intent_conditioned_kernel"]["not_universal_essence"])
        episode = self.store.get_resource("rehab_episode", "REHAB-STROKE-001")["resource"]
        bundle = export_fhir_bundle(episode)
        self.assertEqual(bundle["resourceType"], "Bundle")
        self.assertEqual(bundle["type"], "collection")
        self.assertIn("Provenance", {entry["resource"]["resourceType"] for entry in bundle["entry"]})

    def test_audit_chain_and_reset(self) -> None:
        self.assertTrue(self.store.verify_audit_chain()["valid"])
        self.app.ingest_device_telemetry(
            "DEV-HUMANOID-001",
            {"session_id": "DYN", "subject_kind": "synthetic", "samples": [{"channel": "joint_angle", "numeric_value": 1}]},
            self.admin,
        )
        reset = self.app.reset_demo(self.admin)
        self.assertGreater(reset["deleted"], 19)
        self.assertTrue(reset["seeded"])
        self.assertEqual(self.store.count_resources()["strategy_initiative"], 7)
        self.assertTrue(self.store.verify_audit_chain()["valid"])


if __name__ == "__main__":
    unittest.main()
