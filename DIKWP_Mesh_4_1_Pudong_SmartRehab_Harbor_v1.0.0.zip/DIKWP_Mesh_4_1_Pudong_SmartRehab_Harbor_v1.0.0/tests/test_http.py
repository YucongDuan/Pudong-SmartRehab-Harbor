from __future__ import annotations

import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from smart_harbor.app import SmartHarborApplication, build_handler
from smart_harbor.db import SmartHarborStore


class SmartHarborHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tempdir = tempfile.TemporaryDirectory()
        store = SmartHarborStore(Path(cls.tempdir.name) / "http.db")
        cls.app = SmartHarborApplication(store)
        cls.app.seed_demos_if_empty()
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), build_handler(cls.app))
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        login = cls.request("POST", "/api/auth/login", {"username": "admin", "password": "mesh41-demo"}, authenticated=False)
        cls.token = login["token"]

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)
        cls.tempdir.cleanup()

    @classmethod
    def request(cls, method: str, path: str, body: dict | None = None, *, authenticated: bool = True):
        raw = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        headers = {"Content-Type": "application/json"}
        if authenticated and getattr(cls, "token", None):
            headers["Authorization"] = f"Bearer {cls.token}"
        request = urllib.request.Request(f"http://127.0.0.1:{cls.port}{path}", data=raw, headers=headers, method=method)
        with urllib.request.urlopen(request, timeout=5) as response:
            payload = response.read()
            return json.loads(payload.decode("utf-8")) if payload else {}

    def test_health_and_static(self) -> None:
        health = self.request("GET", "/api/health", authenticated=False)
        self.assertEqual(health["status"], "ok")
        with urllib.request.urlopen(f"http://127.0.0.1:{self.port}/", timeout=5) as response:
            html = response.read().decode("utf-8")
            self.assertIn("SmartRehab Harbor", html)
            self.assertIn("Content-Security-Policy", response.headers)

    def test_requires_authentication(self) -> None:
        with self.assertRaises(urllib.error.HTTPError) as context:
            self.request("GET", "/api/dashboard", authenticated=False)
        self.assertEqual(context.exception.code, 401)

    def test_dashboard_catalogs_and_resources(self) -> None:
        dashboard = self.request("GET", "/api/dashboard")
        self.assertEqual(dashboard["catalog"]["portfolios"], 7)
        catalog = self.request("GET", "/api/catalog/rehab")
        self.assertEqual(len(catalog["axes"]), 6)
        resource = self.request("GET", "/api/resources/rehab_episode/REHAB-STROKE-001")
        self.assertEqual(resource["resource"]["resource_type"], "rehab_episode")

    def test_write_revision_and_simulation(self) -> None:
        record = self.request("GET", "/api/resources/rehab_episode/REHAB-STROKE-001")
        updated = self.request(
            "POST",
            "/api/rehab/REHAB-STROKE-001/assessments",
            {
                "expected_revision": record["revision"],
                "metric_code": "home_role_status",
                "value": "合成家庭参与",
                "observer": "patient_proxy",
                "raw_expression": "合成HTTP记录",
            },
        )
        self.assertGreater(updated["revision"], record["revision"])
        episode = self.request("GET", "/api/resources/rehab_episode/REHAB-STROKE-001")
        session = self.request("GET", "/api/resources/rehab_session/SESSION-REHAB-001")
        simulated = self.request(
            "POST",
            "/api/rehab/REHAB-STROKE-001/simulate",
            {
                "expected_revision": episode["revision"],
                "session_id": "SESSION-REHAB-001",
                "expected_session_revision": session["revision"],
                "sample_count": 30,
            },
        )
        self.assertTrue(simulated["simulation"]["simulation_executed"])
        telemetry = self.request("GET", "/api/telemetry/SESSION-REHAB-001")
        self.assertEqual(len(telemetry["items"]), 120)

    def test_device_ingest_mesh_fhir_and_audit(self) -> None:
        ingested = self.request(
            "POST",
            "/api/device-ingest/DEV-HUMANOID-001",
            {
                "session_id": "HTTP-EXT-001",
                "subject_kind": "synthetic",
                "samples": [{"channel": "joint_angle", "numeric_value": 30, "unit": "degree"}],
            },
        )
        self.assertEqual(ingested["telemetry"]["sample_count"], 1)
        mesh = self.request("GET", "/api/mesh?intent=smart%20rehab")
        self.assertEqual(mesh["channel_count"], 25)
        fhir = self.request("GET", "/api/fhir/rehab_episode/REHAB-STROKE-001")
        self.assertEqual(fhir["resourceType"], "Bundle")
        audit = self.request("GET", "/api/audit/verify")
        self.assertTrue(audit["valid"])

    def test_unsupported_human_ingest_is_422(self) -> None:
        request = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/api/device-ingest/DEV-HUMANOID-001",
            data=json.dumps({"session_id": "BAD", "subject_kind": "patient", "samples": [{"channel": "joint_angle", "numeric_value": 1}]}).encode("utf-8"),
            headers={"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"},
            method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as context:
            urllib.request.urlopen(request, timeout=5)
        self.assertEqual(context.exception.code, 422)


if __name__ == "__main__":
    unittest.main()
