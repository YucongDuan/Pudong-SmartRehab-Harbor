"use strict";

const state = {
  token: sessionStorage.getItem("smartHarborToken") || "",
  principal: null,
  view: "overview",
  rehabId: "REHAB-STROKE-001",
  techniqueId: "TECH-TUINA-001",
  erasId: "ERAS-CRC-001",
  researchId: "RP-THYROID-001",
};

const viewMeta = {
  overview: ["RUNNING SYSTEM", "运行总览"],
  strategy: ["PORTFOLIO & CAMPUS", "院区与战略组合"],
  rehab: ["SIX-AXIS REHABILITATION", "六轴康复闭环"],
  devices: ["HUMAN–MACHINE INTERACTION", "人机交互与设备"],
  techniques: ["FORCE / POSITION / TIME", "大师手法数字化"],
  eras: ["CHINESE MEDICINE + ERAS", "CM-ERAS 围手术期闭环"],
  research: ["TRANSLATIONAL RESEARCH GOVERNANCE", "转化研究治理"],
  mesh: ["DIKWP × DIKWP", "意图驱动关系网"],
  governance: ["PROVENANCE / SAFETY / AUDIT", "证据、边界与审计"],
};

const loginView = document.getElementById("login-view");
const appView = document.getElementById("app-view");
const content = document.getElementById("content");
const toast = document.getElementById("toast");

function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function jsonPretty(value) {
  return esc(JSON.stringify(value, null, 2));
}

function badge(value, kind = "") {
  return `<span class="badge ${kind}">${esc(value)}</span>`;
}

function statusKind(value) {
  const v = String(value || "").toLowerCase();
  if (["active", "approved", "complete", "completed", "pass", "valid", "open_for_simulation_only", "locally_closed_for_tracking"].includes(v)) return "good";
  if (["held", "blocked", "rejected", "terminated", "retired", "error"].includes(v)) return "danger";
  return "warn";
}

function showToast(message, error = false) {
  toast.textContent = message;
  toast.classList.remove("hidden", "error");
  if (error) toast.classList.add("error");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.add("hidden"), 4200);
}

function loading() {
  const template = document.getElementById("loading-template");
  content.replaceChildren(template.content.cloneNode(true));
}

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  if (options.body && !headers["Content-Type"]) headers["Content-Type"] = "application/json";
  const response = await fetch(path, { ...options, headers });
  let payload = null;
  const text = await response.text();
  try { payload = text ? JSON.parse(text) : {}; } catch { payload = { raw: text }; }
  if (!response.ok) {
    const message = payload?.error?.message || `${response.status} ${response.statusText}`;
    const details = payload?.error?.details;
    const error = new Error(details ? `${message} · ${JSON.stringify(details)}` : message);
    error.status = response.status;
    throw error;
  }
  return payload;
}

async function login(username, password) {
  const payload = await api("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ username, password }),
  });
  state.token = payload.token;
  state.principal = payload.principal;
  sessionStorage.setItem("smartHarborToken", state.token);
  enterApp();
}

function logout() {
  state.token = "";
  state.principal = null;
  sessionStorage.removeItem("smartHarborToken");
  appView.classList.add("hidden");
  loginView.classList.remove("hidden");
}

async function restoreSession() {
  if (!state.token) return;
  try {
    const payload = await api("/api/auth/me");
    state.principal = payload.principal;
    enterApp();
  } catch {
    logout();
  }
}

function enterApp() {
  loginView.classList.add("hidden");
  appView.classList.remove("hidden");
  document.getElementById("principal-card").innerHTML = `
    <div class="principal-name">${esc(state.principal?.display_name)}</div>
    <div class="principal-role mono">${esc(state.principal?.role)}</div>`;
  renderView(state.view);
}

async function renderView(view) {
  state.view = view;
  document.querySelectorAll("#main-nav button").forEach((button) => button.classList.toggle("active", button.dataset.view === view));
  document.getElementById("page-eyebrow").textContent = viewMeta[view][0];
  document.getElementById("page-title").textContent = viewMeta[view][1];
  loading();
  try {
    await {
      overview: renderOverview,
      strategy: renderStrategy,
      rehab: renderRehab,
      devices: renderDevices,
      techniques: renderTechniques,
      eras: renderEras,
      research: renderResearch,
      mesh: renderMesh,
      governance: renderGovernance,
    }[view]();
    document.getElementById("health-pill").textContent = "本地服务已连接";
  } catch (error) {
    content.innerHTML = `<div class="card"><h3>读取失败</h3><p class="error">${esc(error.message)}</p></div>`;
    document.getElementById("health-pill").textContent = "读取异常";
    document.getElementById("health-pill").classList.add("danger");
  }
}

async function listRecords(type) {
  const summary = await api(`/api/resources?type=${encodeURIComponent(type)}&limit=500`);
  const records = [];
  for (const item of summary.items) {
    records.push(await api(`/api/resources/${encodeURIComponent(type)}/${encodeURIComponent(item.resource_id)}`));
  }
  return records;
}

async function renderOverview() {
  const data = await api("/api/dashboard");
  const counts = data.resource_counts;
  const cards = [
    [data.catalog.campuses, "院区映射", "访谈来源的四院区角色"],
    [data.catalog.portfolios, "战略组合", "运行对象与研究治理组合"],
    [data.catalog.rehab_metrics, "评估指标", `${data.catalog.rehab_axes} 个可配置轴`],
    [data.catalog.device_types, "设备类型", `${data.catalog.device_adapters} 个适配器`],
    [data.catalog.research_programs, "研究方向", "伦理/HGR/器械门控"],
    [data.catalog.dikwp_channels, "关系通道", "DIKWP×DIKWP 全部有向地址"],
  ];
  content.innerHTML = `
    <div class="grid cards">${cards.map(([value, label, note]) => `
      <article class="card metric-card"><small>${esc(label)}</small><div class="value">${esc(value)}</div><small>${esc(note)}</small></article>`).join("")}</div>
    <div class="section-title"><div><h3>战略组合运行态</h3><p>访谈表达、工程映射和本地对象保持来源状态分离。</p></div></div>
    <div class="table-wrap"><table><thead><tr><th>组合</th><th>来源限定成熟度</th><th>本地状态</th><th>修订</th></tr></thead><tbody>
      ${data.portfolio_runtime.map((p) => `<tr><td><strong>${esc(p.display_name)}</strong><br><span class="mono">${esc(p.initiative_id)}</span></td><td>${badge(p.maturity)}</td><td>${badge(p.runtime_status, statusKind(p.runtime_status))}</td><td>${esc(p.revision ?? "—")}</td></tr>`).join("")}
    </tbody></table></div>
    <div class="grid two" style="margin-top:18px">
      <article class="card"><div class="card-header"><h3>本地资源构成</h3>${badge(Object.values(counts).reduce((a,b)=>a+b,0)+" 条")}</div>
        <div class="kv">${Object.entries(counts).map(([k,v]) => `<div class="mono">${esc(k)}</div><div><strong>${esc(v)}</strong></div>`).join("")}</div>
      </article>
      <article class="card"><div class="card-header"><h3>安全门控与审计</h3>${badge(data.audit_chain.valid ? "审计链有效" : "审计链异常", data.audit_chain.valid ? "good" : "danger")}</div>
        <p>审计事件：<strong>${esc(data.audit_chain.event_count)}</strong></p>
        <p>当前 held/blocked 对象：<strong>${esc(data.safety_holds.length)}</strong></p>
        <ul class="list-clean">${data.safety_holds.slice(0,5).map((item) => `<li>${badge(item.status,"danger")} <strong>${esc(item.display_name)}</strong><br><span class="mono">${esc(item.resource_type)}/${esc(item.resource_id)}</span></li>`).join("") || "<li>当前未发现运行态阻断对象。</li>"}</ul>
      </article>
    </div>
    <div class="card" style="margin-top:18px"><strong>统计边界：</strong>${esc(data.boundary)}</div>`;
}

async function renderStrategy() {
  const data = await api("/api/strategy");
  const initiatives = new Map(data.runtime_initiatives.map((r) => [r.resource.resource_id, r]));
  content.innerHTML = `
    <div class="card"><div class="card-header"><div><h3>${esc(data.profile.display_name)}</h3><p class="muted">${esc(data.profile.definition_boundary)}</p></div>${badge(data.customization_status,"warn")}</div></div>
    <div class="section-title"><div><h3>四院区角色映射</h3><p>source_expression 为访谈表达；engineering_role 为本项目运行角色。</p></div></div>
    <div class="grid two">${data.profile.campuses.map((campus) => `
      <article class="card campus-card"><div class="card-header"><h3>${esc(campus.display_name)}</h3>${badge(campus.role_status)}</div>
        <p class="source-expression">“${esc(campus.source_expression)}”</p>
        <div class="kv"><div>工程角色</div><div class="mono">${esc(campus.engineering_role)}</div><div>来源</div><div class="mono">${esc(campus.source_id)}</div><div>能力句柄</div><div>${campus.capabilities.map((x)=>badge(x)).join(" ")}</div></div>
      </article>`).join("")}</div>
    <div class="section-title"><div><h3>七个关键组合</h3><p>系统模块、成熟度和运行态分开显示。</p></div></div>
    <div class="grid three">${data.profile.portfolios.map((p) => {
      const runtime = initiatives.get(p.initiative_id);
      return `<article class="card portfolio-card"><div class="card-header"><h3>${esc(p.display_name)}</h3>${badge(runtime?.resource?.status || "not_instantiated", statusKind(runtime?.resource?.status))}</div>
        <p>${esc(p.intent)}</p><p>${p.system_modules.map((x)=>badge(x)).join(" ")}</p>
        <div class="kv"><div>成熟度</div><div>${esc(p.maturity)}</div><div>来源</div><div>${p.source_ids.map((x)=>`<span class="mono">${esc(x)}</span>`).join("<br>")}</div><div>运行修订</div><div>${esc(runtime?.revision ?? "—")}</div></div></article>`;
    }).join("")}</div>
    <div class="section-title"><div><h3>组合依赖关系</h3></div></div>
    <div class="table-wrap"><table><thead><tr><th>起点</th><th>关系</th><th>终点</th><th>DIKWP通道</th></tr></thead><tbody>
      ${data.profile.portfolio_dependencies.map((d)=>`<tr><td class="mono">${esc(d.from)}</td><td>${esc(d.relation)}</td><td class="mono">${esc(d.to)}</td><td>${badge(d.dikwp_channel,"good")}</td></tr>`).join("")}
    </tbody></table></div>`;
}

async function renderRehab() {
  const [records, catalog] = await Promise.all([listRecords("rehab_episode"), api("/api/catalog/rehab")]);
  if (!records.length) { content.innerHTML = `<div class="card">没有康复病例运行对象。</div>`; return; }
  if (!records.some((r)=>r.resource.resource_id===state.rehabId)) state.rehabId = records[0].resource.resource_id;
  const record = records.find((r)=>r.resource.resource_id===state.rehabId) || records[0];
  const episode = record.resource;
  const analysis = episode.analysis || {};
  const sessions = await listRecords("rehab_session");
  const relatedSession = sessions.find((r)=>r.resource.parent_id===episode.resource_id) || sessions[0];
  let telemetry = [];
  if (relatedSession) telemetry = (await api(`/api/telemetry/${encodeURIComponent(relatedSession.resource.resource_id)}`)).items;
  const metricsByCode = new Map(catalog.metric_catalog.map((m)=>[m.code,m]));
  content.innerHTML = `
    <div class="toolbar">
      <label>康复运行对象<select id="rehab-select">${records.map((r)=>`<option value="${esc(r.resource.resource_id)}" ${r.resource.resource_id===episode.resource_id?"selected":""}>${esc(r.resource.display_name)}</option>`).join("")}</select></label>
      <button id="rehab-analyze">重新闭合分析</button>
      <button id="rehab-fhir">导出FHIR R4</button>
    </div>
    <div class="grid cards" style="margin-top:18px">
      <article class="card metric-card"><small>闭合状态</small><div class="value" style="font-size:24px">${esc(analysis.closure_status || "open")}</div><small>${esc(analysis.analysis_scope || "")}</small></article>
      <article class="card metric-card"><small>语义稳定性</small><div class="value">${esc(analysis.reliability?.semantic_stability || "—")}</div><small>不与证据可靠性合成</small></article>
      <article class="card metric-card"><small>网状检验</small><div class="value">${esc(analysis.reliability?.mesh_examination || "—")}</div><small>当前意图与运行子网</small></article>
      <article class="card metric-card"><small>证据可靠性</small><div class="value" style="font-size:25px">${esc(analysis.reliability?.evidence_reliability || "—")}</div><small>合成演示不形成临床证据</small></article>
    </div>
    <div class="section-title"><div><h3>六轴覆盖</h3><p>前四轴为ICF来源限定操作标签；后两轴为患者意图/体验与疗愈暴露/反应的本地工作流字段。</p></div></div>
    <div class="axis-grid">${(analysis.axis_coverage || []).map((a)=>`<div class="axis ${a.covered?"covered":""}"><strong>${esc(a.axis_id)} · ${esc(a.display_name)}</strong><span>${a.covered?"已记录":"待记录"}</span><small>${esc(a.observation_count)} 条 · ${esc(a.source_id || "local")}</small></div>`).join("")}</div>
    <div class="grid two" style="margin-top:18px">
      <article class="card"><div class="card-header"><h3>患者意图与问题核</h3>${badge(`kernel ${analysis.intent_conditioned_kernel?.kernel_size ?? 0}`)}</div>
        <ul class="list-clean">${(episode.intents || []).map((i)=>`<li><strong>${esc(i.source_text)}</strong><br>${badge(i.provenance_status,"good")} <span class="mono">${esc(i.intent_id)}</span></li>`).join("")}</ul>
        <h4 style="margin-top:18px">反事实关键节点</h4><ul class="list-clean">${(analysis.intent_conditioned_kernel?.critical_nodes || []).map((n)=>`<li><span class="mono">${esc(n.node_id)}</span> · ${esc(n.collection)}</li>`).join("") || "<li>当前未识别关键节点。</li>"}</ul>
      </article>
      <article class="card"><div class="card-header"><h3>主动采集队列</h3>${badge(`${analysis.active_questions?.length || 0} 项`)}</div>
        <ul class="list-clean">${(analysis.active_questions || []).map((q)=>`<li>${badge(`P${q.priority}`, q.priority===0?"danger":"warn")} <strong>${esc(q.text)}</strong><br><span class="mono">${esc(q.target)} · ${esc(q.dikwp_channel)}</span></li>`).join("") || "<li>当前队列为空。</li>"}</ul>
      </article>
    </div>
    <div class="grid two" style="margin-top:18px">
      <article class="card"><div class="card-header"><h3>记录一个六轴观察</h3><span class="mono">revision ${record.revision}</span></div>
        <form id="assessment-form" class="inline-form"><div class="form-grid">
          <label>指标<select id="assessment-metric">${catalog.metric_catalog.map((m)=>`<option value="${esc(m.code)}">${esc(m.axis_id)} · ${esc(m.display_name)} (${esc(m.code)})</option>`).join("")}</select></label>
          <label>值<input id="assessment-value" value="3"></label>
          <label>单位<input id="assessment-unit" value="${esc(catalog.metric_catalog[0]?.unit || "")}"></label>
          <label>观察者<input id="assessment-observer" value="${esc(state.principal.role)}"></label>
          <label class="full">原始表达<input id="assessment-raw" value="演示工作流录入"></label>
        </div><button type="submit" class="primary">写入观察并重新分析</button></form>
      </article>
      <article class="card"><div class="card-header"><h3>人形康复模拟会话</h3>${badge(relatedSession?.resource.status || "未创建", statusKind(relatedSession?.resource.status))}</div>
        <div class="kv"><div>设备</div><div class="mono">${esc(relatedSession?.resource.device_id || episode.session_plan?.device_id)}</div><div>运行范围</div><div>synthetic/simulator</div><div>临床执行</div><div>${badge("false","good")}</div><div>急停记录</div><div>${badge(String(relatedSession?.resource.emergency_stop_verified), relatedSession?.resource.emergency_stop_verified?"good":"danger")}</div></div>
        <button id="rehab-simulate" class="primary" style="margin-top:16px">运行确定性仿真并写入遥测</button>
      </article>
    </div>
    <div class="section-title"><div><h3>设备遥测</h3><p>${esc(relatedSession?.resource.resource_id || "无会话")} · 仅为工程仿真代理，不产生临床解释。</p></div></div>
    <div class="card"><canvas id="rehab-chart" class="telemetry" width="1200" height="300"></canvas><div class="legend"><span>joint_angle</span><span>assistance_force</span><span>balance_proxy</span><span>fatigue_proxy</span></div></div>
    <div class="section-title"><div><h3>观察与趋势账本</h3></div></div>
    <div class="table-wrap"><table><thead><tr><th>轴/指标</th><th>值</th><th>观察者/时间</th><th>原始表达</th><th>趋势</th></tr></thead><tbody>
      ${(episode.assessments || []).slice().reverse().map((a)=>{const t=analysis.metric_trends?.[a.metric_code];return `<tr><td>${badge(a.axis_id)}<br><span class="mono">${esc(a.metric_code)}</span></td><td><strong>${esc(a.value)}</strong> ${esc(a.unit || "")}</td><td>${esc(a.observer)}<br><span class="mono">${esc(a.recorded_at)}</span></td><td>${esc(a.raw_expression)}</td><td>${esc(t?.direction || "—")}<br>${esc(t?.numeric_change ?? "")}</td></tr>`}).join("")}
    </tbody></table></div>`;

  document.getElementById("rehab-select").addEventListener("change", (e)=>{state.rehabId=e.target.value;renderRehab();});
  document.getElementById("assessment-metric").addEventListener("change", (e)=>{
    document.getElementById("assessment-unit").value = metricsByCode.get(e.target.value)?.unit || "";
  });
  document.getElementById("assessment-form").addEventListener("submit", async (e)=>{
    e.preventDefault();
    try {
      const def = metricsByCode.get(document.getElementById("assessment-metric").value);
      let value = document.getElementById("assessment-value").value;
      if (def?.value_type === "number") value = Number(value);
      await api(`/api/rehab/${encodeURIComponent(episode.resource_id)}/assessments`, {method:"POST",body:JSON.stringify({expected_revision:record.revision,metric_code:def.code,value,unit:document.getElementById("assessment-unit").value,observer:document.getElementById("assessment-observer").value,raw_expression:document.getElementById("assessment-raw").value})});
      showToast("观察已写入并形成新的病例修订");
      renderRehab();
    } catch(error){showToast(error.message,true);}
  });
  document.getElementById("rehab-analyze").addEventListener("click", async()=>{
    try{await api(`/api/rehab/${encodeURIComponent(episode.resource_id)}/analyze`,{method:"POST",body:JSON.stringify({expected_revision:record.revision})});showToast("已重新执行意图条件化闭合");renderRehab();}catch(error){showToast(error.message,true);}
  });
  document.getElementById("rehab-simulate").addEventListener("click", async()=>{
    try{await api(`/api/rehab/${encodeURIComponent(episode.resource_id)}/simulate`,{method:"POST",body:JSON.stringify({expected_revision:record.revision,session_id:relatedSession?.resource.resource_id,expected_session_revision:relatedSession?.revision,sample_count:180})});showToast("仿真遥测已写入SQLite与审计链");renderRehab();}catch(error){showToast(error.message,true);}
  });
  document.getElementById("rehab-fhir").addEventListener("click",()=>downloadFHIR("rehab_episode",episode.resource_id));
  drawTelemetry(document.getElementById("rehab-chart"), telemetry, ["joint_angle","assistance_force","balance_proxy","fatigue_proxy"]);
}

async function renderDevices() {
  const [devices, sessions, catalog] = await Promise.all([listRecords("device"), listRecords("rehab_session"), api("/api/catalog/devices")]);
  content.innerHTML = `
    <div class="grid three">${devices.map((r)=>{const d=r.resource;return `<article class="card"><div class="card-header"><h3>${esc(d.display_name)}</h3>${badge(d.status,statusKind(d.status))}</div>
      <div class="kv"><div>类型</div><div class="mono">${esc(d.device_type)}</div><div>适配器</div><div class="mono">${esc(d.adapter_id)}</div><div>临床执行</div><div>${badge(String(d.clinical_execution_allowed),d.clinical_execution_allowed?"danger":"good")}</div><div>校准</div><div>${badge(d.calibration?.result || "未记录",statusKind(d.calibration?.result))}</div><div>急停</div><div>${badge(String(d.emergency_stop_verified),d.emergency_stop_verified?"good":"warn")}</div></div>
      <button class="secondary device-fhir" data-id="${esc(d.resource_id)}" style="margin-top:14px">FHIR Device</button></article>`}).join("")}</div>
    <div class="section-title"><div><h3>适配器边界</h3><p>厂商接口只作为占位描述；本发行包实际可运行的是 simulator 与 CSV/HTTP 数据容器。</p></div></div>
    <div class="table-wrap"><table><thead><tr><th>适配器</th><th>运行方式</th><th>临床执行</th><th>边界</th></tr></thead><tbody>${catalog.adapters.map((a)=>`<tr><td><strong>${esc(a.display_name)}</strong><br><span class="mono">${esc(a.adapter_id)}</span></td><td>${esc(a.connection_type)}</td><td>${badge(String(a.clinical_execution_allowed),a.clinical_execution_allowed?"danger":"good")}</td><td>${esc(a.boundary || a.security_boundary || "仅数据接入；不授权临床执行")}</td></tr>`).join("")}</tbody></table></div>
    <div class="section-title"><div><h3>会话门控快照</h3></div></div>
    <div class="table-wrap"><table><thead><tr><th>会话</th><th>对象</th><th>设备</th><th>状态</th><th>安全字段</th></tr></thead><tbody>${sessions.map((r)=>{const s=r.resource;return `<tr><td><strong>${esc(s.display_name)}</strong><br><span class="mono">rev ${r.revision}</span></td><td>${esc(s.subject_kind)}</td><td class="mono">${esc(s.device_id)}</td><td>${badge(s.status,statusKind(s.status))}</td><td>operator=${esc(s.operator_present)} · calibration=${esc(s.calibration_current)} · e-stop=${esc(s.emergency_stop_verified)}</td></tr>`}).join("")}</tbody></table></div>
    <div class="section-title"><div><h3>预检字段</h3></div></div><div class="grid cards">${catalog.session_preflight?.map((x)=>`<div class="card"><strong class="mono">${esc(x.check_id)}</strong><p>${esc(x.display_name)}</p>${badge((x.required_for||[]).join(", "))}</div>`).join("") || ""}</div>
    <div class="section-title"><div><h3>通用遥测接入</h3><p>可由设备工程或数据管理角色写入 synthetic/phantom 样本；接口不会授权真人临床执行。</p></div></div>
    <div class="grid two"><article class="card"><form id="device-ingest-form" class="inline-form"><label>设备<select id="ingest-device">${devices.map((r)=>`<option value="${esc(r.resource.resource_id)}">${esc(r.resource.display_name)}</option>`).join("")}</select></label><label>会话ID<input id="ingest-session" value="EXT-SYNTH-SESSION-001"></label><label>样本JSON<textarea id="ingest-samples">[{"sequence":0,"recorded_at":"T+0","channel":"joint_angle","numeric_value":30,"unit":"degree"},{"sequence":1,"recorded_at":"T+1","channel":"joint_angle","numeric_value":34,"unit":"degree"}]</textarea></label><button class="primary" type="submit">写入遥测批次</button></form></article><article class="card"><h3>接入契约</h3><div class="kv"><div>对象范围</div><div>synthetic / phantom</div><div>临床执行</div><div>${badge("false","good")}</div><div>幂等策略</div><div>session_id + sequence + channel</div><div>追溯</div><div>批次资源 + payload SHA-256 + 审计链</div></div><div id="ingest-output" class="fineprint" style="margin-top:14px">尚未写入。</div></article></div>`;
  document.querySelectorAll(".device-fhir").forEach((button)=>button.addEventListener("click",()=>downloadFHIR("device",button.dataset.id)));
  document.getElementById("device-ingest-form").addEventListener("submit",async(e)=>{e.preventDefault();try{const samples=JSON.parse(document.getElementById("ingest-samples").value);const result=await api(`/api/device-ingest/${encodeURIComponent(document.getElementById("ingest-device").value)}`,{method:"POST",body:JSON.stringify({session_id:document.getElementById("ingest-session").value,subject_kind:"synthetic",clinical_execution:false,samples})});document.getElementById("ingest-output").innerHTML=`已写入 <strong>${esc(result.telemetry.sample_count)}</strong> 个样本；批次 <span class="mono">${esc(result.batch.resource.resource_id)}</span>`;showToast("通用设备遥测批次已写入");}catch(error){showToast(error.message,true);}});
}

async function renderTechniques() {
  const records = await listRecords("technique_capture");
  if (!records.length) { content.innerHTML = `<div class="card">没有手法数字化记录。</div>`; return; }
  if (!records.some((r)=>r.resource.resource_id===state.techniqueId)) state.techniqueId=records[0].resource.resource_id;
  const record=records.find((r)=>r.resource.resource_id===state.techniqueId)||records[0];
  const capture=record.resource;
  const telemetry=(await api(`/api/telemetry/${encodeURIComponent(capture.resource_id)}`)).items;
  content.innerHTML=`
    <div class="toolbar"><label>轨迹包<select id="technique-select">${records.map((r)=>`<option value="${esc(r.resource.resource_id)}" ${r.resource.resource_id===capture.resource_id?"selected":""}>${esc(r.resource.display_name)}</option>`).join("")}</select></label><button id="technique-simulate">重新生成仿真采集</button><button id="technique-fhir">FHIR导出</button></div>
    <div class="grid two" style="margin-top:18px">
      <article class="card"><div class="card-header"><h3>${esc(capture.technique_label)}</h3>${badge(capture.review_status||capture.status,statusKind(capture.status))}</div>
      <div class="kv"><div>对象</div><div>${esc(capture.subject_kind)}</div><div>设备</div><div class="mono">${esc(capture.device_id)}</div><div>采集目的</div><div>${esc(capture.capture_purpose)}</div><div>回放范围</div><div>${(capture.playback_scope||[]).map((x)=>badge(x)).join(" ")}</div><div>患者执行</div><div>${badge(String(capture.patient_execution_allowed),"good")}</div><div>力上限</div><div>${esc(capture.force_limit_newton)} N</div></div></article>
      <article class="card"><div class="card-header"><h3>工程指标</h3><span class="mono">rev ${record.revision}</span></div><div class="kv">${Object.entries(capture.metrics||{}).map(([k,v])=>`<div class="mono">${esc(k)}</div><div>${esc(v)}</div>`).join("")}</div></article>
    </div>
    <div class="section-title"><div><h3>力—位—时轨迹</h3><p>仿真或假体范围；RMSE 仅作为工程相似性信号，不形成大师水平评分。</p></div></div>
    <div class="card"><canvas id="technique-chart" class="telemetry" width="1200" height="300"></canvas><div class="legend"><span>force_z</span><span>position_x</span><span>position_y</span><span>velocity</span></div></div>
    <div class="grid two" style="margin-top:18px"><article class="card"><h3>两轨迹包对照</h3><form id="compare-form" class="inline-form"><label>左侧<select id="compare-left">${records.map((r)=>`<option value="${esc(r.resource.resource_id)}">${esc(r.resource.display_name)}</option>`).join("")}</select></label><label>右侧<select id="compare-right">${records.map((r,i)=>`<option value="${esc(r.resource.resource_id)}" ${i===1?"selected":""}>${esc(r.resource.display_name)}</option>`).join("")}</select></label><button class="primary" type="submit">执行重采样与RMSE对照</button></form></article><article class="card"><h3>对照输出</h3><div id="compare-output" class="muted">尚未执行。</div></article></div>`;
  document.getElementById("technique-select").addEventListener("change",(e)=>{state.techniqueId=e.target.value;renderTechniques();});
  document.getElementById("technique-simulate").addEventListener("click",async()=>{try{await api(`/api/techniques/${encodeURIComponent(capture.resource_id)}/simulate`,{method:"POST",body:JSON.stringify({expected_revision:record.revision,sample_count:200})});showToast("仿真手法轨迹已重新生成");renderTechniques();}catch(error){showToast(error.message,true);}});
  document.getElementById("technique-fhir").addEventListener("click",()=>downloadFHIR("technique_capture",capture.resource_id));
  document.getElementById("compare-form").addEventListener("submit",async(e)=>{e.preventDefault();try{const result=await api("/api/techniques/compare",{method:"POST",body:JSON.stringify({left_id:document.getElementById("compare-left").value,right_id:document.getElementById("compare-right").value})});document.getElementById("compare-output").innerHTML=`<div class="kv">${result.channel_comparison.map((x)=>`<div class="mono">${esc(x.channel)}</div><div>RMSE ${esc(x.resampled_rmse)}</div>`).join("")}</div><p class="fineprint">${esc(result.interpretation_boundary)}</p>`;}catch(error){showToast(error.message,true);}});
  drawTelemetry(document.getElementById("technique-chart"),telemetry,["force_z","position_x","position_y","velocity"]);
}

async function renderEras() {
  const [records,catalog]=await Promise.all([listRecords("eras_episode"),api("/api/catalog/eras")]);
  if(!records.length){content.innerHTML=`<div class="card">没有CM-ERAS运行对象。</div>`;return;}
  if(!records.some((r)=>r.resource.resource_id===state.erasId))state.erasId=records[0].resource.resource_id;
  const record=records.find((r)=>r.resource.resource_id===state.erasId)||records[0];
  const episode=record.resource, analysis=episode.analysis||{};
  const template=catalog.templates.find((t)=>t.template_id===episode.template_id);
  const open=[];
  for(const phase of template?.phases||[])for(const code of phase.checkpoints||[]){if(!(episode.checkpoints||[]).some((c)=>c.code===code&&["complete","not_applicable_with_reason"].includes(c.status)))open.push({phase_id:phase.phase_id,code});}
  content.innerHTML=`
    <div class="toolbar"><label>CM-ERAS对象<select id="eras-select">${records.map((r)=>`<option value="${esc(r.resource.resource_id)}" ${r.resource.resource_id===episode.resource_id?"selected":""}>${esc(r.resource.display_name)}</option>`).join("")}</select></label><button id="eras-analyze">重新分析</button><button id="eras-fhir">FHIR导出</button></div>
    <div class="grid cards" style="margin-top:18px"><article class="card metric-card"><small>完成检查点</small><div class="value">${esc(analysis.checkpoint_completion?.completed||0)}/${esc(analysis.checkpoint_completion?.total||0)}</div><small>${esc(analysis.closure_status||"")}</small></article><article class="card metric-card"><small>语义稳定性</small><div class="value">${esc(analysis.reliability?.semantic_stability||"—")}</div></article><article class="card metric-card"><small>网状检验</small><div class="value">${esc(analysis.reliability?.mesh_examination||"—")}</div></article><article class="card metric-card"><small>自动医嘱</small><div class="value" style="font-size:25px">false</div><small>系统不生成处方、穴位或出院决定</small></article></div>
    <div class="section-title"><div><h3>阶段检查点</h3><p>历史访谈中的出院时间和成本表述仅保存在来源层，不被编码为当前患者保证目标。</p></div></div>
    <div class="grid two">${(analysis.phase_completion||[]).map((p)=>`<article class="phase"><div class="phase-title"><span>${esc(p.display_name)}</span>${badge(`${p.completed}/${p.total}`,p.completed===p.total?"good":"warn")}</div>${p.items.map((i)=>`<div class="checkpoint">${badge(i.complete?"完成":"开放",i.complete?"good":"warn")}<div><strong class="mono">${esc(i.code)}</strong><br><small>${esc(i.record?.raw_expression||i.record?.recorded_by||"")}</small></div></div>`).join("")}</article>`).join("")}</div>
    <div class="grid two" style="margin-top:18px"><article class="card"><h3>记录检查点</h3><form id="checkpoint-form" class="inline-form"><label>开放项<select id="checkpoint-open">${open.map((x)=>`<option value="${esc(x.phase_id)}|${esc(x.code)}">${esc(x.phase_id)} · ${esc(x.code)}</option>`).join("")}</select></label><label>原始记录<input id="checkpoint-raw" value="人工工作流记录"></label><button class="primary" type="submit" ${open.length?"":"disabled"}>写入完成状态</button></form></article><article class="card"><h3>结局字段存在性</h3><div class="kv">${Object.entries(analysis.outcome_presence||{}).map(([k,v])=>`<div class="mono">${esc(k)}</div><div>${badge(String(v),v?"good":"warn")}</div>`).join("")}</div></article></div>`;
  document.getElementById("eras-select").addEventListener("change",(e)=>{state.erasId=e.target.value;renderEras();});
  document.getElementById("eras-analyze").addEventListener("click",async()=>{try{await api(`/api/eras/${encodeURIComponent(episode.resource_id)}/analyze`,{method:"POST",body:JSON.stringify({expected_revision:record.revision})});showToast("CM-ERAS闭合已更新");renderEras();}catch(error){showToast(error.message,true);}});
  document.getElementById("eras-fhir").addEventListener("click",()=>downloadFHIR("eras_episode",episode.resource_id));
  document.getElementById("checkpoint-form").addEventListener("submit",async(e)=>{e.preventDefault();if(!open.length)return;const [phase_id,code]=document.getElementById("checkpoint-open").value.split("|");try{await api(`/api/eras/${encodeURIComponent(episode.resource_id)}/checkpoints`,{method:"POST",body:JSON.stringify({expected_revision:record.revision,phase_id,code,status:"complete",raw_expression:document.getElementById("checkpoint-raw").value})});showToast("检查点已写入");renderEras();}catch(error){showToast(error.message,true);}});
}

async function renderResearch() {
  const [records,catalog]=await Promise.all([listRecords("research_protocol"),api("/api/catalog/research")]);
  if(!records.length){content.innerHTML=`<div class="card">没有研究治理对象。</div>`;return;}
  if(!records.some((r)=>r.resource.resource_id===state.researchId))state.researchId=records[0].resource.resource_id;
  const record=records.find((r)=>r.resource.resource_id===state.researchId)||records[0];
  const protocol=record.resource, analysis=protocol.analysis||{};
  const next=(analysis.allowed_next_states||[]).filter((x)=>!["recruiting","active_followup"].includes(x));
  content.innerHTML=`
    <div class="toolbar"><label>研究对象<select id="research-select">${records.map((r)=>`<option value="${esc(r.resource.resource_id)}" ${r.resource.resource_id===protocol.resource_id?"selected":""}>${esc(r.resource.display_name)}</option>`).join("")}</select></label><button id="research-analyze">重新分析</button><button id="research-fhir">FHIR ResearchStudy</button></div>
    <div class="grid two" style="margin-top:18px"><article class="card"><div class="card-header"><h3>${esc(protocol.display_name)}</h3>${badge(protocol.status,statusKind(protocol.status))}</div><div class="kv"><div>项目</div><div class="mono">${esc(protocol.program_id)}</div><div>版本</div><div>${esc(protocol.protocol_version)}</div><div>研究类型</div><div>${esc(protocol.study_type)}</div><div>负责人标签</div><div>${esc(protocol.principal_investigator)}</div><div>HGR适用性</div><div>${esc(protocol.hgr?.applicability)}</div><div>真人招募</div><div>${badge(String(protocol.human_recruitment),"good")}</div></div><p class="fineprint">${esc(protocol.hypothesis_expression)}</p></article>
    <article class="card"><div class="card-header"><h3>当前闭合</h3>${badge(analysis.closure_status||"open",statusKind(analysis.closure_status))}</div><div class="kv"><div>语义稳定性</div><div>${esc(analysis.reliability?.semantic_stability)}</div><div>网状检验</div><div>${esc(analysis.reliability?.mesh_examination)}</div><div>证据可靠性</div><div>${esc(analysis.reliability?.evidence_reliability)}</div><div>真人招募授权</div><div>${badge(String(analysis.human_recruitment_authorized_by_system),"good")}</div></div><h4 style="margin-top:16px">残差</h4><ul class="list-clean">${(analysis.residuals||[]).map((r)=>`<li>${esc(r.type)} ${r.gate?`· ${esc(r.gate)}`:""}</li>`).join("")||"<li>当前治理字段无残差。</li>"}</ul></article></div>
    <div class="section-title"><div><h3>门控矩阵</h3><p>系统保存审查状态，不替代科学、伦理、监管、HGR或器械临床试验判断。</p></div></div><div class="gate-matrix">${Object.entries(protocol.gates||{}).map(([k,v])=>`<div class="gate ${v?"pass":"fail"}"><strong class="mono">${esc(k)}</strong><br>${v?"已记录通过":"未记录通过"}</div>`).join("")}</div>
    <div class="grid three" style="margin-top:18px"><article class="card"><h3>工作流迁移</h3><form id="transition-form" class="inline-form"><label>目标状态<select id="transition-target">${next.map((x)=>`<option value="${esc(x)}">${esc(x)}</option>`).join("")}</select></label><label>人工原因<input id="transition-reason" value="工作流人工记录"></label><button class="primary" type="submit" ${next.length?"":"disabled"}>记录迁移</button></form></article><article class="card"><h3>伦理决定记录</h3><form id="ethics-form" class="inline-form"><label>决定<select id="ethics-decision"><option>approved</option><option>approved_with_conditions</option><option>deferred</option><option>rejected</option><option>suspended</option></select></label><label>委员会引用<input id="ethics-ref" value="SYNTH-IRB-DEMO"></label><button class="primary" type="submit">创建伦理记录容器</button></form></article><article class="card"><h3>合成样本链</h3><form id="biospecimen-form" class="inline-form"><label>样本类型<input id="specimen-type" value="synthetic_organoid_material"></label><label>存储位置<input id="specimen-location" value="SIM-BANK-A01"></label><button class="primary" type="submit">登记合成样本</button></form></article></div>
    <div class="section-title"><div><h3>研究方向目录</h3></div></div><div class="grid two">${catalog.programs.map((p)=>`<article class="card"><div class="card-header"><h3>${esc(p.display_name)}</h3>${badge(p.maturity)}</div><p>${esc(p.hypothesis_expression)}</p><div class="kv"><div>program_id</div><div class="mono">${esc(p.program_id)}</div><div>治理范围</div><div>${(p.mandatory_determinations||[]).map((x)=>badge(x)).join(" ")}</div></div></article>`).join("")}</div>`;
  document.getElementById("research-select").addEventListener("change",(e)=>{state.researchId=e.target.value;renderResearch();});
  document.getElementById("research-analyze").addEventListener("click",async()=>{try{await api(`/api/research/${encodeURIComponent(protocol.resource_id)}/analyze`,{method:"POST",body:JSON.stringify({expected_revision:record.revision})});showToast("研究治理闭合已更新");renderResearch();}catch(error){showToast(error.message,true);}});
  document.getElementById("research-fhir").addEventListener("click",()=>downloadFHIR("research_protocol",protocol.resource_id));
  document.getElementById("transition-form").addEventListener("submit",async(e)=>{e.preventDefault();if(!next.length)return;try{await api(`/api/research/${encodeURIComponent(protocol.resource_id)}/transition`,{method:"POST",body:JSON.stringify({expected_revision:record.revision,target_state:document.getElementById("transition-target").value,reason:document.getElementById("transition-reason").value})});showToast("研究状态迁移已记录");renderResearch();}catch(error){showToast(error.message,true);}});
  document.getElementById("ethics-form").addEventListener("submit",async(e)=>{e.preventDefault();try{await api(`/api/research/${encodeURIComponent(protocol.resource_id)}/ethics`,{method:"POST",body:JSON.stringify({expected_revision:record.revision,decision:document.getElementById("ethics-decision").value,committee_reference:document.getElementById("ethics-ref").value,synthetic_only:true})});showToast("伦理决定容器已记录");renderResearch();}catch(error){showToast(error.message,true);}});
  document.getElementById("biospecimen-form").addEventListener("submit",async(e)=>{e.preventDefault();try{await api(`/api/research/${encodeURIComponent(protocol.resource_id)}/biospecimens`,{method:"POST",body:JSON.stringify({expected_revision:record.revision,subject_kind:"synthetic",specimen_type:document.getElementById("specimen-type").value,storage_location:document.getElementById("specimen-location").value,synthetic_only:true})});showToast("合成样本链已登记");}catch(error){showToast(error.message,true);}});
}

async function renderMesh(intent = "围绕人形康复智慧港，哪些关系改变会使当前闭环失效？") {
  const mesh=await api(`/api/mesh?intent=${encodeURIComponent(intent)}`);
  content.innerHTML=`
    <div class="card"><form id="mesh-form" class="inline-form"><label>当前分析意图<textarea id="mesh-intent">${esc(mesh.analysis_intent.source_text)}</textarea></label><button class="primary" type="submit">重建意图激活子网与反事实问题核</button></form></div>
    <div class="grid cards" style="margin-top:18px"><article class="card metric-card"><small>激活节点</small><div class="value">${mesh.nodes.length}</div></article><article class="card metric-card"><small>激活关系</small><div class="value">${mesh.edges.length}</div></article><article class="card metric-card"><small>激活通道</small><div class="value">${mesh.channels_activated.length}</div><small>全部目录25</small></article><article class="card metric-card"><small>问题核规模</small><div class="value">${mesh.intent_conditioned_kernel.kernel_size}</div><small>节点/边删除可达性测试</small></article></div>
    <div class="section-title"><div><h3>DIKWP×DIKWP通道矩阵</h3><p>字母仅作为运行时关系地址，不对外部概念作普遍定义。</p></div></div><div class="channel-grid">${mesh.channel_catalog.map((c)=>`<div class="channel ${mesh.channels_activated.includes(c)?"active":""}">${esc(c)}</div>`).join("")}</div>
    <div class="mesh-columns" style="margin-top:18px"><article class="card"><div class="card-header"><h3>意图条件化问题核</h3>${badge(`size ${mesh.intent_conditioned_kernel.kernel_size}`)}</div><h4>关键节点</h4><ul class="list-clean node-list">${mesh.intent_conditioned_kernel.critical_nodes.map((n)=>`<li><strong>${esc(n.label||n.node_id)}</strong><br><span class="mono">${esc(n.node_id)}</span></li>`).join("")||"<li>当前未识别关键节点。</li>"}</ul><h4 style="margin-top:16px">关键边</h4><ul class="list-clean">${mesh.intent_conditioned_kernel.critical_edges.map((e)=>`<li>${badge(e.dikwp_channel,"good")} ${esc(e.relation)}<br><span class="mono">${esc(e.source)} → ${esc(e.target)}</span></li>`).join("")||"<li>当前未识别关键边。</li>"}</ul></article>
    <article class="card"><div class="card-header"><h3>激活关系路径</h3>${badge(mesh.reliability.mesh_examination)}</div><div class="table-wrap edge-list"><table><thead><tr><th>通道</th><th>起点</th><th>关系</th><th>终点</th></tr></thead><tbody>${mesh.edges.map((e)=>`<tr><td>${badge(e.dikwp_channel,"good")}</td><td class="mono">${esc(e.source)}</td><td>${esc(e.relation)}</td><td class="mono">${esc(e.target)}</td></tr>`).join("")}</tbody></table></div></article></div>
    <div class="card" style="margin-top:18px"><strong>边界：</strong>${esc(mesh.definition_boundary)}</div>`;
  document.getElementById("mesh-form").addEventListener("submit",(e)=>{e.preventDefault();renderMesh(document.getElementById("mesh-intent").value);});
}

async function renderGovernance() {
  const [sources,governance,audit,verify]=await Promise.all([api("/api/catalog/sources"),api("/api/catalog/governance"),api("/api/audit?limit=100"),api("/api/audit/verify")]);
  content.innerHTML=`
    <div class="grid cards"><article class="card metric-card"><small>来源登记</small><div class="value">${sources.sources.length}</div></article><article class="card metric-card"><small>禁止自治项</small><div class="value">${governance.prohibited_autonomy.length}</div></article><article class="card metric-card"><small>审计事件</small><div class="value">${verify.event_count}</div></article><article class="card metric-card"><small>审计链</small><div class="value" style="font-size:26px">${verify.valid?"VALID":"INVALID"}</div><small class="mono">${esc(verify.last_hash||"")}</small></article></div>
    <div class="section-title"><div><h3>来源登记簿</h3><p>来源陈述、权威框架、法规与本地工程映射不互相替代。</p></div></div><div class="table-wrap"><table><thead><tr><th>来源</th><th>状态</th><th>适用对象</th><th>边界</th></tr></thead><tbody>${sources.sources.map((s)=>`<tr><td><strong>${esc(s.title)}</strong><br><span class="mono">${esc(s.source_id)}</span></td><td>${badge(s.source_status)}</td><td>${(s.applies_to||[]).map((x)=>badge(x)).join(" ")}</td><td>${esc(s.boundary)}</td></tr>`).join("")}</tbody></table></div>
    <div class="grid two" style="margin-top:18px"><article class="card"><h3>硬边界</h3><ul class="list-clean">${governance.prohibited_autonomy.map((x)=>`<li>${badge("BLOCKED","danger")} <span class="mono">${esc(x)}</span></li>`).join("")}</ul></article><article class="card"><h3>可靠性维度</h3><div class="kv"><div>Semantic Stability</div><div>${governance.semantic_stability_values.map((x)=>badge(x)).join(" ")}</div><div>Mesh Examination</div><div>${governance.mesh_examination_values.map((x)=>badge(x)).join(" ")}</div><div>Evidence Reliability</div><div>${governance.evidence_reliability_values.map((x)=>badge(x)).join(" ")}</div><div>合成总分</div><div>${badge(String(governance.no_scalar_without_weights),"good")}</div></div></article></div>
    <div class="section-title"><div><h3>最近审计事件</h3></div><div class="toolbar"><button id="verify-audit">重新校验链</button></div></div><div class="table-wrap"><table><thead><tr><th>序号/时间</th><th>主体</th><th>动作</th><th>资源</th><th>哈希</th></tr></thead><tbody>${audit.items.map((a)=>`<tr><td>${esc(a.sequence)}<br><span class="mono">${esc(a.recorded_at)}</span></td><td>${esc(a.actor)}<br>${badge(a.actor_role)}</td><td class="mono">${esc(a.action)}</td><td class="mono">${esc(a.resource_type||"")}/${esc(a.resource_id||"")}</td><td class="mono">${esc(String(a.event_hash).slice(0,18))}…</td></tr>`).join("")}</tbody></table></div>`;
  document.getElementById("verify-audit").addEventListener("click",async()=>{try{const result=await api("/api/audit/verify");showToast(result.valid?`审计链有效，共${result.event_count}项`:`审计链异常：${result.reason}`,!result.valid);}catch(error){showToast(error.message,true);}});
}

function drawTelemetry(canvas, samples, channels) {
  if (!canvas) return;
  const ctx=canvas.getContext("2d");
  const width=canvas.width,height=canvas.height,pad=42;
  ctx.clearRect(0,0,width,height);ctx.fillStyle="#fbfcfb";ctx.fillRect(0,0,width,height);
  ctx.strokeStyle="#dbe2dc";ctx.lineWidth=1;
  for(let i=0;i<=5;i++){const y=pad+(height-pad*2)*i/5;ctx.beginPath();ctx.moveTo(pad,y);ctx.lineTo(width-pad,y);ctx.stroke();}
  const palette=["#0e6d5f","#c36a32","#375d8d","#8a4a78"];
  channels.forEach((channel,index)=>{
    const values=samples.filter((s)=>s.channel===channel&&Number.isFinite(Number(s.numeric_value))).map((s)=>Number(s.numeric_value));
    if(values.length<2)return;
    const min=Math.min(...values),max=Math.max(...values),span=max-min||1;
    ctx.strokeStyle=palette[index%palette.length];ctx.lineWidth=2;ctx.beginPath();
    values.forEach((value,i)=>{const x=pad+(width-pad*2)*i/(values.length-1);const y=height-pad-(height-pad*2)*(value-min)/span;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);});ctx.stroke();
    ctx.fillStyle=palette[index%palette.length];ctx.font="12px sans-serif";ctx.fillText(channel,pad+index*170,20);
  });
  if(!samples.length){ctx.fillStyle="#66747b";ctx.font="18px sans-serif";ctx.fillText("当前会话没有遥测样本",pad,height/2);}
}

async function downloadFHIR(type,id){
  try{const bundle=await api(`/api/fhir/${encodeURIComponent(type)}/${encodeURIComponent(id)}`);downloadJson(`${type}_${id}_fhir_r4.json`,bundle);showToast("FHIR R4 Collection Bundle 已生成");}catch(error){showToast(error.message,true);}
}

function downloadJson(filename,value){
  const blob=new Blob([JSON.stringify(value,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
}

document.getElementById("login-form").addEventListener("submit",async(e)=>{
  e.preventDefault();
  const errorBox=document.getElementById("login-error");errorBox.classList.add("hidden");
  try{await login(document.getElementById("login-username").value,document.getElementById("login-password").value);}catch(error){errorBox.textContent=error.message;errorBox.classList.remove("hidden");}
});
document.getElementById("logout-button").addEventListener("click",logout);
document.getElementById("main-nav").addEventListener("click",(e)=>{const button=e.target.closest("button[data-view]");if(button)renderView(button.dataset.view);});

restoreSession();
