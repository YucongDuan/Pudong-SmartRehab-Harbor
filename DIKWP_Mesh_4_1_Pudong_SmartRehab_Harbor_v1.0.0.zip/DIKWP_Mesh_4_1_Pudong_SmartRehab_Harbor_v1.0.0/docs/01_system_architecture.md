# 系统架构

## 1. 逻辑分层

```text
浏览器工作台（原生 HTML/CSS/JavaScript）
        │ Bearer token / JSON
Python 标准库 HTTP API
        │
应用服务层
├─ 战略与院区组合
├─ 六轴康复与设备会话
├─ 手法数字化
├─ CM‑ERAS
├─ 转化研究治理
├─ DIKWP 关系网 / 反事实问题核
├─ FHIR R4 导出
└─ 安全、权限与来源边界
        │
SQLite 事务存储
├─ resources
├─ telemetry_samples
└─ audit_events（哈希链）
        │
JSON 目录和来源登记
```

## 2. 运行组件

| 组件 | 文件 | 责任 |
|---|---|---|
| HTTP 应用 | `smart_harbor/app.py` | 路由、认证边界、请求校验、静态页面 |
| 认证授权 | `smart_harbor/auth.py` | 演示账户、HMAC 令牌、能力检查 |
| 存储 | `smart_harbor/db.py` | SQLite、修订控制、遥测、审计链 |
| 安全校验 | `smart_harbor/safety.py` | 医疗自治、人体执行、研究招募等硬阻断 |
| 康复 | `smart_harbor/rehab.py` | 评估、Goal、覆盖分析、仿真和反事实核 |
| 手法数字化 | `smart_harbor/techniques.py` | 力—位—时仿真、指标和轨迹比较 |
| CM‑ERAS | `smart_harbor/eras.py` | 检查点、阶段覆盖、结局和残差 |
| 研究治理 | `smart_harbor/research.py` | 状态迁移、伦理引用、样本登记、门控 |
| 关系网 | `smart_harbor/mesh.py` | 25 通道、激活子图、节点/边反事实 |
| 互操作 | `smart_harbor/fhir.py` | FHIR R4 Collection Bundle 原型 |
| CLI | `smart_harbor/cli.py` | 服务、种子、健康、审计、FHIR、CSV 导入 |

## 3. 数据模型

系统采用统一资源包络：

```json
{
  "resource_type": "rehab_episode",
  "resource_id": "REHAB-STROKE-001",
  "schema_version": "1.0.0",
  "display_name": "合成脑卒中康复闭环",
  "campus_code": "guangming-xinchang",
  "status": "active",
  "source_status": "synthetic_demo",
  "definition_boundary": "source_scoped_operational_label_not_universal_definition",
  "human_review_required": true
}
```

存储层在包络之外维护：

```text
revision
payload_sha256
created_at
updated_at
```

写操作必须携带 `expected_revision`。当前修订不匹配时返回 HTTP 409。

## 4. 设备数据流

```text
设备/仿真器
 → adapter_id
 → 批次校验（对象类型、通道、有限数值、数量上限）
 → telemetry_samples
 → device_ingest_batch
 → 分析/界面
 → 审计事件
```

内置适配器只接受 `synthetic` 或 `phantom`。`clinical_execution=true` 会被服务端拒绝，客户端不能覆盖这一门控。

## 5. 研究数据流

```text
来源限定研究方向
 → research_protocol
 → 科学审查状态
 → 伦理工作流引用
 → 监管/HGR适用性判断字段
 → 合成样本链
 → 分析与关闭条件
```

发行包阻断 `recruiting` 和 `active_followup` 的真实执行，并阻断非合成样本登记。

## 6. 可用性和故障边界

- SQLite 开启 WAL，以支持单机并发读和串行写；
- HTTP 使用 `ThreadingHTTPServer`；
- 无消息队列、分布式锁或多节点一致性协议；
- 默认定位为单机试点和接口验证；
- 数据库文件、备份、密钥和日志均需由部署环境治理；
- 服务器进程故障不会自动重启，本地可由 systemd/Docker restart policy 管理。

## 7. 互操作边界

FHIR 导出用于显示资源可映射性，包含适用时的 Patient、Condition、Observation、Goal、CarePlan、ClinicalImpression 和 Provenance。项目没有绑定医院正式患者主索引、术语服务器、国家编码或院内接口规范，也没有完成互联互通一致性测评。
