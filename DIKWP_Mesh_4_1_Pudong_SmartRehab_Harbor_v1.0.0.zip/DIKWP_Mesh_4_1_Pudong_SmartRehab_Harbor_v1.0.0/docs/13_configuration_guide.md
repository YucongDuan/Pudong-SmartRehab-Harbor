# 配置指南

## 1. 目录文件

| 文件 | 可配置内容 |
|---|---|
| `data/strategy_profile.json` | 院区角色、战略组合、来源和依赖 |
| `data/rehab_profiles.json` | 六轴、指标、单位、观察者、疗愈方式、前置检查 |
| `data/device_catalog.json` | 适配器、设备类型、通道和生命周期 |
| `data/eras_templates.json` | 围手术期模板和结局字段 |
| `data/research_programs.json` | 研究方向、状态、文件和门控 |
| `data/governance_rules.json` | 禁止自治项、可靠性值、25 通道 |
| `data/source_register.json` | 来源、状态、适用范围和边界 |
| `data/demo_resources.json` | 合成演示资源 |

## 2. 修改原则

- 每个外部来源表达保留 `source_id`；
- 工程字段使用 `engineering_configuration` 或相应状态；
- 不以同名标签推定语义相同；
- 新指标必须声明单位、观察者和适用轴；
- 新设备适配器必须声明通道和对象类型；
- 新研究门控不能以代码默认值代替人工判断；
- 修改后运行 `python tools/run_qa.py`。

## 3. 添加康复指标

在 `metric_catalog` 中添加唯一 `code`，至少包含 display_name、axis_id、value_type、allowed_units、observer_roles 和 source_status。后端会拒绝不在目录的指标。

## 4. 添加设备适配器

适配器声明 `adapter_id`、连接类型、允许通道和边界。若允许任意通道，使用 `supported_channels: ["configurable"]`；这只放宽数据接入，不放宽人体执行门控。

## 5. 添加研究方向

新增 `program_id`、来源限定假设、所需判定、证据状态和边界。协议仍需完整门控，不能因目录存在而自动进入后续状态。
