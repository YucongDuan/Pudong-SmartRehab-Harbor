# 设备与人机交互接入契约

## 1. 当前适配器

| adapter_id | 连接形式 | 当前能力 |
|---|---|---|
| `simulator-v1` | 进程内 | 确定性康复/手法仿真 |
| `csv-import-v1` | CSV | 批量导入合成或仿体遥测 |
| `generic-http-push-v1` | HTTP JSON | 通用推送接口 |
| `fourier-placeholder-v1` | 接口占位 | 仅保留厂商场景映射，无真实厂商接入 |

目录不是采购清单，也不表示设备注册证、适用范围或医院准入状态。

## 2. HTTP 接入

```http
POST /api/device-ingest/{device_id}
Authorization: Bearer <token>
Content-Type: application/json
```

示例：

```json
{
  "session_id": "EXT-SYN-001",
  "subject_kind": "phantom",
  "replace": true,
  "clinical_execution": false,
  "samples": [
    {"sequence": 0, "recorded_at": "T+0", "channel": "assistance_force", "numeric_value": 8.2, "unit": "N"},
    {"sequence": 0, "recorded_at": "T+0", "channel": "phase", "text_value": "stance"}
  ]
}
```

服务端强制：

- `clinical_execution` 不能为 true；
- `subject_kind` 只能为 `synthetic` 或 `phantom`；
- 每批最多 100,000 个样本；
- 数值必须有限；
- 每条样本必须有数值或文本；
- 固定通道适配器拒绝未知通道；
- 写入生成 `device_ingest_batch` 和审计事件。

## 3. CSV 格式

文件头：

```csv
sequence,recorded_at,channel,numeric_value,text_value,unit
0,T+0,assistance_force,8.2,,N
0,T+0,phase,,stance,
1,T+0.1,assistance_force,8.5,,N
```

导入：

```bash
python run.py import-telemetry-csv DEV-HUMANOID-001 examples/device_telemetry.csv \
  --session-id CSV-DEMO-001 --subject-kind phantom
```

## 4. 生产设备适配所需字段

一个院内设备适配器应显式提供：

```text
device identity / model / serial
software and firmware version
registered scope reference
adapter version
clock source and synchronization
channel dictionary and units
sampling frequency and loss handling
calibration record and expiry
operator identity reference
patient/session pseudonymous binding
consent and order reference
emergency stop / stop condition state
raw payload hash and transformation log
```

当前发行包只实现数据契约与门控，不实现生产厂商协议、实时控制回路或医疗设备网络安全认证。

## 5. 力反馈手法实验边界

- 对象只能为仿体或合成数据；
- 力阈值来自设备工程配置，不是临床治疗阈值；
- 比较指标按力、位置、节律分开报告；
- 不合成为“技术优劣”“名家相似度”或疗效评分；
- 不含针刺深度、角度、穴位或患者回放控制；
- `patient_execution_allowed` 必须为 false。
