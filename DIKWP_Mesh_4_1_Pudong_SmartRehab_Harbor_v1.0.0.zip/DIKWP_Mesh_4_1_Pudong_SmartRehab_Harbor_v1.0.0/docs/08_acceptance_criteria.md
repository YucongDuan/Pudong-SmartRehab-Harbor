# 验收标准

## 1. 发行包级验收

| 编号 | 条件 | 验证方式 |
|---|---|---|
| PKG-01 | ZIP 完整可解压 | `unzip -t` 或 Python `zipfile.testzip()` |
| PKG-02 | 清单中文件哈希一致 | `SHA256SUMS` / `manifest.json` |
| PKG-03 | 不包含 SQLite、WAL、SHM、pyc 或真实数据 | 打包静态检查 |
| PKG-04 | Python 3.10+ 可启动 | `python run.py serve` |

## 2. 功能验收

| 编号 | 条件 |
|---|---|
| FUN-01 | 空库首次启动装载 19 个合成资源，重启不重复装载 |
| FUN-02 | 健康检查返回 25 个 DIKWP 通道和有效审计链 |
| FUN-03 | 11 个工作流账户可按能力登录，未认证 API 返回 401 |
| FUN-04 | 康复评估、目标、分析、仿真会话和遥测可运行 |
| FUN-05 | 手法仿真和两轨迹 RMSE 比较可运行 |
| FUN-06 | CM‑ERAS 检查点写入和阶段分析可运行 |
| FUN-07 | 研究状态、伦理记录和合成样本登记可运行 |
| FUN-08 | 四院区战略组合和转诊资源可读取/审计 |
| FUN-09 | FHIR R4 Collection Bundle 可导出 |
| FUN-10 | 审计链校验 `valid=true` |

## 3. 安全边界验收

| 编号 | 必须被拒绝的行为 |
|---|---|
| SAFE-01 | `clinical_execution=true` 的设备遥测 |
| SAFE-02 | human/patient 对象使用内置设备适配器 |
| SAFE-03 | 自治诊断、处方、药物剂量、穴位、针刺深度等字段 |
| SAFE-04 | `human_review_required=false` |
| SAFE-05 | 真实受试者 `recruiting` / `active_followup` |
| SAFE-06 | 非合成生物样本登记 |
| SAFE-07 | 患者代理读取不属于允许范围的资源 |
| SAFE-08 | 缺失或错误 `expected_revision` 的覆盖写入 |

## 4. 数据和互操作验收

- JSON 目录可解析；
- JSON Schema 为 Draft 2020‑12；
- 演示资源和示例输出通过模式校验；
- FHIR Bundle 至少包含 `Bundle.type=collection` 和 `Provenance`；
- 遥测主键不产生同一 session/sequence/channel 的静默重复；
- 每次写入产生资源哈希和审计事件。

## 5. 不在当前验收范围

真实医院身份、HIS/EMR/LIS/PACS 接口、厂商设备、真实患者、临床有效性、人体研究、医疗器械注册、网络安全等级保护、性能容量、无障碍、人因和灾备不在当前发行包验收范围。
