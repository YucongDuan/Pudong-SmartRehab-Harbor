# 转化研究治理

## 1. 范围

本模块承接访谈中的四类研究方向：甲状腺类器官、胰岛类器官、自体神经束脑机接口、肝硬化自体细胞研究。系统仅将其处理为**来源限定研究假设和治理对象**。

## 2. 研究协议最小字段

```text
program_id
protocol_version
study_type
hypothesis_expression
principal_investigator（工作流引用）
scientific review status
ethics reference and decision
HGR applicability and route
medical-device determination
biosafety determination
data management plan
statistical analysis plan
stop rules / adverse-event plan
documents and version history
```

## 3. 状态迁移

每次迁移保存来源状态、操作者、理由、时间和前后状态。未满足目录中门控时不能进入 `ready_for_recruitment`。本发行包对 `recruiting` 和 `active_followup` 进行额外硬阻断，确保演示系统不能被用作真实招募工具。

## 4. 伦理工作流

伦理决定值：

```text
pending
approved
approved_with_conditions
deferred
rejected
suspended
```

系统记录伦理委员会引用、提交版本、决定、条件、日期和持续审查日期。系统不判断风险—获益、受试者选择、公平性、同意有效性或伦理可接受性。

## 5. HGR 和样本

`hgr.applicability` 必须由人工明确记录；系统不会根据样本类型自动作法律判断。采集、保藏、利用、对外提供或开放使用所需许可、备案或事先报告仍在正式制度和平台中完成。

合成样本对象用于验证 custody、版本和权限路径；任何非合成 `subject_kind` 被后端拒绝。

## 6. 医疗器械研究

涉及机器人、脑机接口或其他器械的协议需记录器械适用性判断、设备台账、版本、校准、责任、监查和数据可追溯字段。系统不代表已满足医疗器械临床试验质量管理规范，也不替代注册、备案或机构准入。

## 7. 数据隔离

研究协议、伦理记录、样本记录和设备记录通过 `parent_id` 和显式关系连接，不将患者临床数据默认为研究可用数据。真实部署需要独立的数据授权、脱敏/假名化、访问审批、导出审查和撤回机制。
