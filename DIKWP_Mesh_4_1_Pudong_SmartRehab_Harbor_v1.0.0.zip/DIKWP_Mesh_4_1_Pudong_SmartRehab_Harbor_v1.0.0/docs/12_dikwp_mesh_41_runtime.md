# DIKWP‑Mesh 4.1 在本系统中的运行

## 1. 运行对象

本系统不以模型自建概念词典作为主要对象，而记录：

```text
expression
source
observer
recorded_at
scope
unit
constraint
intent provenance
relation edge
residual
```

D、I、K、W、P 保持为运行角色标签和关系地址，不在本项目中重新定义。

## 2. 25 个有向通道

系统生成全部源角色×目标角色通道，并允许同类回环、逆向和多路径。通道只在实际有关系时激活，不机械填充。

## 3. 意图来源

```text
explicit
user_stipulated
context_inferred
contested
absent
```

用户明确意图不被语境推断覆盖。多个意图改变闭合时，系统保留并行子图。

## 4. 问题核

```text
当前意图
 → 相关资源/关系子图
 → 当前闭合签名
 → 删除节点重新计算
 → 删除关系重新计算
 → 识别会改变安全、路径、目标或残差的最小依赖
 → intent_conditioned_kernel
```

问题核是当前条件下的结构依赖，不是概念的普遍本质。

## 5. 可靠性

- `Semantic Stability`：当前表达和关系是否在范围内稳定；
- `Mesh Examination`：当前子图是否完成必要正向、逆向、循环和反事实检查；
- `Evidence Reliability`：来源和证据状态。

三者分别输出。`no_scalar_without_weights=true`。

## 6. 典型阻断

- 设备会话同意缺失：P→D 路径存在，但 W 侧安全门控阻断执行；
- HGR 适用性缺失：研究 I→K 不可进入后续 W；
- 轨迹来源不明：D→I 可记录，但不能形成稳定的 K；
- 患者目标与临床方案冲突：保留 P→P contested，不强行合并。
