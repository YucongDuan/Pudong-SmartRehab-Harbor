# API 参考

基础地址：`http://127.0.0.1:8791`。除 `/api/health` 和 `/api/auth/login` 外，API 需要 Bearer token。

## 1. 认证

### `POST /api/auth/login`

```json
{"username":"admin","password":"mesh41-demo"}
```

返回令牌、工作流主体和有效期。

### `GET /api/auth/me`

返回当前主体。

## 2. 系统和目录

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/health` | 健康、版本、目录计数、审计链 |
| GET | `/api/bootstrap` | 当前主体、资源类型和目录摘要 |
| GET | `/api/dashboard` | 本地运行对象总览 |
| GET | `/api/strategy` | 四院区和七组合映射 |
| GET | `/api/catalog/{name}` | `strategy/rehab/devices/eras/research/governance/sources` |

## 3. 通用资源

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/resources?type=&parent_id=&campus_code=&status=&limit=` | 资源摘要列表 |
| POST | `/api/resources` | 创建资源 |
| GET | `/api/resources/{type}/{id}` | 读取资源与修订 |
| PUT | `/api/resources/{type}/{id}` | 用 `expected_revision` 替换 |
| DELETE | `/api/resources/{type}/{id}` | 管理员删除并审计 |
| POST | `/api/resources/{type}/{id}/analyze` | 支持专项分析的资源 |

写入示例：

```json
{
  "expected_revision": 2,
  "resource": {
    "resource_type": "strategy_initiative",
    "resource_id": "PORT-SMART-REHAB",
    "display_name": "人形康复智慧港",
    "campus_code": "guangming-xinchang",
    "status": "pilot",
    "source_status": "interview_derived_engineering_mapping",
    "human_review_required": true
  }
}
```

## 4. 康复

| 方法 | 路径 |
|---|---|
| POST | `/api/rehab/{episode_id}/assessments` |
| POST | `/api/rehab/{episode_id}/goals` |
| POST | `/api/rehab/{episode_id}/analyze` |
| POST | `/api/rehab/{episode_id}/simulate` |
| GET | `/api/telemetry/{session_id}` |

所有 POST 需要 `expected_revision`。仿真请求可包含 `session_id`、`sample_count`、`duration_seconds`、`simulation_seed` 和前置门控字段。

## 5. 设备和手法

| 方法 | 路径 |
|---|---|
| POST | `/api/device-ingest/{device_id}` |
| POST | `/api/techniques/{capture_id}/simulate` |
| POST | `/api/techniques/compare` |

比较请求：

```json
{"left_id":"TECH-TUINA-001","right_id":"TECH-TUINA-002"}
```

## 6. CM‑ERAS

| 方法 | 路径 |
|---|---|
| POST | `/api/eras/{episode_id}/checkpoints` |
| POST | `/api/eras/{episode_id}/analyze` |

检查点请求包含 `expected_revision`、`code`、`status`、`raw_expression`、`observer_role`、`recorded_at` 和人工审签引用。

## 7. 研究治理

| 方法 | 路径 |
|---|---|
| POST | `/api/research/{protocol_id}/transition` |
| POST | `/api/research/{protocol_id}/ethics` |
| POST | `/api/research/{protocol_id}/biospecimens` |
| POST | `/api/research/{protocol_id}/analyze` |

真实招募和非合成样本会返回 422。

## 8. Mesh、FHIR 和审计

| 方法 | 路径 |
|---|---|
| GET | `/api/mesh?intent=...` |
| GET | `/api/fhir/{resource_type}/{resource_id}` |
| GET | `/api/audit?resource_type=&resource_id=&limit=` |
| GET | `/api/audit/verify` |
| POST | `/api/demo/reset` |

详细机器可读契约见根目录 `openapi.yaml`。
