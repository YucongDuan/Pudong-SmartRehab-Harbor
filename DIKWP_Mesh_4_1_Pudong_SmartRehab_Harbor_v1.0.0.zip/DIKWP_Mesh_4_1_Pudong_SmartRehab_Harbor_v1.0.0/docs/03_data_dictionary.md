# 数据字典

## 1. 通用字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `resource_type` | string | 系统资源类别 |
| `resource_id` | string | 资源唯一标识 |
| `schema_version` | string | 当前数据模式版本 |
| `display_name` | string | 人工可读名称 |
| `campus_code` | string | 来源限定院区句柄 |
| `status` | string | 当前工作流状态 |
| `source_status` | string | 来源/工程/演示状态 |
| `definition_boundary` | string | 概念与使用范围边界 |
| `human_review_required` | boolean | 必须保持为 true |
| `parent_id` | string/null | 父级运行对象 |
| `created_at` / `updated_at` | date-time | 服务器时间 |

## 2. 资源类型

| 资源类型 | 关键字段 | 使用范围 |
|---|---|---|
| `strategy_initiative` | `owner_role`, `intents`, `milestones`, `risks`, `relations` | 战略组合运行态 |
| `device` | `device_type`, `adapter_id`, `calibration`, `emergency_stop_verified`, `clinical_execution_allowed` | 设备登记与安全状态 |
| `rehab_episode` | `patient`, `consent`, `intents`, `assessments`, `goals`, `session_plan`, `analysis` | 康复连续闭环 |
| `rehab_session` | `device_id`, `subject_kind`, preflight 字段、`metrics` | 单次设备/康复会话 |
| `technique_capture` | `technique_label`, `practitioner`, `force_limit_newton`, `review_status`, `metrics` | 手法轨迹版本 |
| `eras_episode` | `template_id`, `procedure_context`, `clinician_approval`, `checkpoints`, `outcomes`, `analysis` | 围手术期跟踪 |
| `research_protocol` | `program_id`, `protocol_version`, `gates`, `hgr`, `documents`, `transition_history`, `analysis` | 转化研究治理 |
| `ethics_review` | `committee_reference`, `submission_version`, `decision`, `conditions` | 伦理工作流记录 |
| `biospecimen` | `subject_kind`, `specimen_type`, `storage_location`, `hgr_applicability`, `chain_of_custody` | 合成样本演示 |
| `referral` | `source_campus`, `target_campus`, `service_requested`, `patient_consent`, `automatic_routing` | 多院区转诊记录 |
| `healing_exposure` | modality、duration、environment、response | 疗愈环境暴露/反应记录 |
| `adverse_event` | severity、relatedness、action、review | 质量/研究不良事件容器 |
| `device_ingest_batch` | `device_id`, `session_id`, `sample_count`, `channel_counts`, `payload_sha256` | 遥测接入批次 |

## 3. 遥测样本

SQLite 表 `telemetry_samples`：

| 字段 | 说明 |
|---|---|
| `session_id` | 会话、采集或批次标识 |
| `sequence` | 样本顺序 |
| `recorded_at` | 时间或相对时间标签 |
| `channel` | 通道名 |
| `numeric_value` | 有限数值 |
| `text_value` | 文本状态 |
| `unit` | 单位 |
| `payload_json` | 完整规范化样本 |

主键为 `(session_id, sequence, channel)`。

## 4. 审计事件

| 字段 | 说明 |
|---|---|
| `sequence` | 单调递增序号 |
| `event_id` | 事件 UUID 句柄 |
| `resource_type/resource_id` | 关联资源 |
| `actor/actor_role` | 工作流标签 |
| `action` | 操作类型 |
| `detail_json` | 修订、哈希和操作细节 |
| `previous_hash` | 前一事件哈希 |
| `event_hash` | 当前事件 SHA‑256 |

审计链提供篡改检测，不替代合格电子签名或 WORM 存储。

## 5. 来源与可靠性字段

```text
source_status:
source_stated / official_public_statement / official_rule /
authoritative_framework / authoritative_specification /
engineering_configuration / workflow_record / synthetic_demo

evidence_reliability:
Solid / Supported / Provisional / Borrowed / Hollow / Contested / Blocked

semantic_stability:
S4 / S3 / S2 / S1 / S0

mesh_examination:
M4 / M3 / M2 / M1 / M0

intent_provenance:
explicit / user_stipulated / context_inferred / contested / absent
```

系统不把三类可靠性压缩为没有明确权重来源的单一分数。
