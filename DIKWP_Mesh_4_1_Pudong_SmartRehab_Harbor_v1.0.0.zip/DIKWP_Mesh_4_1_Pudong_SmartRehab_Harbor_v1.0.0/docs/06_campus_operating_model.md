# 四院区协同运行模型

## 1. 来源限定院区角色

| 院区句柄 | 访谈表达 | 系统运行角色 | 主要资源 |
|---|---|---|---|
| `luoshan` | 精品中医名医诊疗中心 | 名医服务、会诊、传承与手法教学枢纽 | referral、technique_capture、strategy_initiative |
| `chuansha` | 纯中医医院 | 中医服务与康复连续照护枢纽 | referral、rehab_episode、strategy_initiative |
| `guangming-huinan` | 中西医结合医院 | 手术/内科协同与 CM‑ERAS 枢纽 | eras_episode、referral |
| `guangming-xinchang` | 高科技、人形康复智慧港 | 智慧康复、设备验证、六轴评估和转化研究枢纽 | device、rehab_session、research_protocol |

## 2. 协同对象

### 2.1 转诊

```text
source_campus
→ reason_expression
→ requested_service
→ patient_consent
→ clinical_routing_confirmed_by
→ target_campus
→ accepted/closed status
```

### 2.2 技法传承

罗山名医/专家工作流记录可以与新场仿体手法实验关联，但操作者、版本、设备和复核意见分开保存。

### 2.3 围手术期—康复连续性

惠南 CM‑ERAS 对象可以通过显式关系连接新场康复 Episode；系统不以院区角色自动推导患者适用路径。

### 2.4 研究—设备共享治理

类器官、脑机接口和细胞研究共享伦理、HGR、样本、设备和审计基础设施，但每个协议有独立状态和门控，不能因共享平台而继承审批。

## 3. 运行总览字段

总览只统计本地 SQLite 中的演示对象数量、状态、院区分布、阻断对象和审计链，不代表医院真实业务量、绩效、床位、患者量或科研产出。
