# 部署与运行运维

## 1. 单机目录

```text
/app
├─ code and catalogs
├─ var/pudong_smartrehab_harbor.db
└─ outputs/
```

默认数据库由进程首次启动创建，空库时装载演示数据。删除数据库会重新生成演示数据；运行中不应直接修改 JSON 或 SQLite 文件。

## 2. 环境变量

| 变量 | 默认值 | 说明 |
|---|---|---|
| `SMART_HARBOR_HOST` | `127.0.0.1` | 监听地址 |
| `SMART_HARBOR_PORT` | `8791` | HTTP 端口 |
| `SMART_HARBOR_DB` | `var/pudong_smartrehab_harbor.db` | SQLite 路径 |
| `SMART_HARBOR_TOKEN_SECRET` | 演示值 | HMAC 密钥 |
| `SMART_HARBOR_DEMO_PASSWORD` | `mesh41-demo` | 演示密码 |
| `SMART_HARBOR_TOKEN_TTL_SECONDS` | `28800` | 令牌有效期 |
| `SMART_HARBOR_MAX_BODY_BYTES` | `8388608` | 请求体上限 |

## 3. 启动和健康检查

```bash
python run.py serve
python run.py health
curl http://127.0.0.1:8791/api/health
```

健康响应包含版本、目录计数、资源计数和审计链状态。

## 4. 备份与恢复

SQLite 在线备份应使用 SQLite backup API、`VACUUM INTO` 或在受控停机后复制数据库及 WAL/SHM 文件。恢复前应校验文件权限、版本、审计链和输出目录。项目没有内置远程备份、密钥托管或灾备编排。

## 5. 数据清理

`POST /api/demo/reset` 仅限管理员；它删除本地资源并重新装载合成数据，但保留审计链。发布包本身不包含运行数据库。

## 6. 日志

HTTP 访问日志默认输出到标准错误，可由 systemd、Docker 或平台日志采集。审计事件保存于 SQLite。当前实现没有集中日志、SIEM、告警升级或长周期归档。

## 7. 版本升级

本版 schema 为 `1.0.0`。未来升级需提供：数据库备份、迁移脚本、目录版本对比、回滚规则和迁移后审计验证。当前没有自动数据库迁移框架，因此不得直接用新代码覆盖不可恢复的真实数据库。

## 8. 反向代理

非本地网络环境应由受控反向代理提供 TLS、访问控制、请求限速和安全头。应用当前提供基础安全响应头，但不替代网络边界防护。
