from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

from .app import SmartHarborApplication, serve
from .config import db_path, host as default_host, port as default_port
from .db import SmartHarborStore


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="DIKWP-Mesh 4.1 Pudong SmartRehab Harbor")
    sub = parser.add_subparsers(dest="command", required=True)

    serve_parser = sub.add_parser("serve", help="run the local HTTP server")
    serve_parser.add_argument("--host", default=default_host())
    serve_parser.add_argument("--port", type=int, default=default_port())
    serve_parser.add_argument("--no-seed", action="store_true", help="do not seed bundled synthetic records")

    sub.add_parser("seed", help="seed bundled synthetic demo records if the database is empty")
    sub.add_parser("verify-audit", help="verify the SQLite SHA-256 audit chain")
    sub.add_parser("health", help="print the application health payload")
    sub.add_parser("catalog-summary", help="print catalog counts")

    export_parser = sub.add_parser("export-fhir", help="export one local resource as a FHIR R4 collection bundle")
    export_parser.add_argument("resource_type")
    export_parser.add_argument("resource_id")
    export_parser.add_argument("--output", type=Path)

    import_parser = sub.add_parser("import-telemetry-csv", help="ingest synthetic/phantom telemetry from a CSV file")
    import_parser.add_argument("--device-id", required=True)
    import_parser.add_argument("--session-id", required=True)
    import_parser.add_argument("--input", type=Path, required=True)
    import_parser.add_argument("--subject-kind", choices=["synthetic", "phantom"], default="synthetic")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "serve":
        serve(args.host, args.port, seed_demo=not args.no_seed)
        return 0

    app = SmartHarborApplication(SmartHarborStore(db_path()))
    if args.command == "seed":
        print(json.dumps(app.seed_demos_if_empty(), ensure_ascii=False, indent=2))
        return 0
    if args.command == "verify-audit":
        result = app.store.verify_audit_chain()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("valid") else 2
    if args.command == "health":
        print(json.dumps(app.health(), ensure_ascii=False, indent=2))
        return 0
    if args.command == "catalog-summary":
        from .catalog import catalog_summary

        print(json.dumps(catalog_summary(app.catalogs), ensure_ascii=False, indent=2))
        return 0
    if args.command == "import-telemetry-csv":
        from .auth import DEMO_USERS
        samples = []
        with args.input.open("r", encoding="utf-8-sig", newline="") as handle:
            for index, row in enumerate(csv.DictReader(handle)):
                numeric_raw = row.get("numeric_value")
                samples.append({
                    "sequence": int(row.get("sequence") or index),
                    "recorded_at": row.get("recorded_at") or f"T+{index}",
                    "channel": row.get("channel"),
                    "numeric_value": float(numeric_raw) if numeric_raw not in (None, "") else None,
                    "text_value": row.get("text_value") or None,
                    "unit": row.get("unit") or None,
                })
        result = app.ingest_device_telemetry(args.device_id, {
            "session_id": args.session_id, "subject_kind": args.subject_kind, "samples": samples, "replace": True
        }, DEMO_USERS["data"])
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.command == "export-fhir":
        record = app.store.get_resource(args.resource_type, args.resource_id)
        from .fhir import export_fhir_bundle

        bundle = export_fhir_bundle(record["resource"])
        raw = json.dumps(bundle, ensure_ascii=False, indent=2)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(raw + "\n", encoding="utf-8")
            print(str(args.output))
        else:
            print(raw)
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
