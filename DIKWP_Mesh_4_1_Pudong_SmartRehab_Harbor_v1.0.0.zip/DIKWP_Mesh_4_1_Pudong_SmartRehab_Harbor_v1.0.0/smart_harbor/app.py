from __future__ import annotations

import json
import mimetypes
import os
import re
import traceback
from collections import Counter, defaultdict
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import parse_qs, unquote, urlparse

from . import PROJECT_NAME, PROJECT_NAME_ZH, __version__
from .auth import (
    AuthenticationError,
    AuthorizationError,
    Principal,
    authenticate,
    bearer_token,
    issue_token,
    require_any_capability,
    require_capability,
    verify_token,
)
from .catalog import catalog_summary, load_catalogs
from .config import DEMO_RESOURCES_PATH, WEB_DIR, max_body_bytes, token_ttl_seconds
from .db import ResourceNotFound, RevisionConflict, SmartHarborStore
from .domain import deep_copy, ensure_resource_shape, finite_number, new_id, sha256_json, utc_now
from .eras import add_checkpoint, analyze_eras_episode
from .fhir import export_fhir_bundle
from .mesh import build_relation_mesh
from .rehab import add_assessment, add_goal, analyze_rehab_episode, merge_session_metrics, simulate_rehab_session
from .research import add_biospecimen, analyze_protocol, record_ethics_decision, transition_protocol
from .safety import (
    SafetyValidationError,
    validate_common,
    validate_device,
    validate_eras_episode,
    validate_rehab_episode,
    validate_rehab_session,
    validate_research_protocol,
    validate_technique_capture,
)
from .techniques import compare_captures, merge_capture_result, simulate_capture


class ApplicationValidationError(ValueError):
    def __init__(self, message: str, details: Mapping[str, Any] | None = None) -> None:
        super().__init__(message)
        self.details = dict(details or {})


WRITE_CAPABILITY_BY_TYPE: dict[str, str] = {
    "strategy_initiative": "strategy.write",
    "device": "device.write",
    "rehab_episode": "rehab.write",
    "rehab_session": "device_session.run",
    "technique_capture": "technique.capture",
    "eras_episode": "eras.write",
    "research_protocol": "research.write",
    "ethics_review": "ethics.write",
    "biospecimen": "biospecimen.write",
    "referral": "referral.write",
    "healing_exposure": "rehab.write",
    "adverse_event": "quality.review",
    "device_ingest_batch": "telemetry.write",
}

RESOURCE_TYPES = tuple(WRITE_CAPABILITY_BY_TYPE)


class SmartHarborApplication:
    """Application service for the public-information-customized runnable prototype."""

    def __init__(self, store: SmartHarborStore | None = None) -> None:
        self.store = store or SmartHarborStore()
        self.catalogs = load_catalogs()

    def health(self) -> dict[str, Any]:
        return {
            "status": "ok",
            "project": PROJECT_NAME,
            "project_zh": PROJECT_NAME_ZH,
            "version": __version__,
            "runtime": "Python standard library / SQLite / vanilla JavaScript / offline-first",
            "catalog": catalog_summary(self.catalogs),
            "resource_counts": self.store.count_resources(),
            "audit_chain": self.store.verify_audit_chain(),
            "medical_boundary": "human-in-the-loop synthetic/public-information customized prototype; no autonomous clinical or research execution",
            "dikwp_mesh": {
                "version": "4.1",
                "channel_count": 25,
                "no_universal_external_concept_definition": True,
                "no_scalar_without_source_weights": True,
            },
        }

    def seed_demos_if_empty(self) -> dict[str, Any]:
        if self.store.list_resources(limit=1):
            return {"seeded": False, "reason": "resource_store_not_empty", "count": 0}
        payload = self._load_json(DEMO_RESOURCES_PATH)
        resources = payload.get("resources", [])
        saved: list[dict[str, Any]] = []
        # Preserve source order so parent/device records exist before workflow records.
        for raw in resources:
            item = self._prepare_resource(str(raw.get("resource_type")), deep_copy(raw), actor_role="admin")
            result = self.store.save_resource(
                item["resource_type"],
                item,
                actor="system.seed",
                actor_role="system",
                action="demo.seed",
                expected_revision=0,
                audit_detail={"synthetic_only": True},
            )
            saved.append(result)
        # Create deterministic telemetry so the interface is useful immediately.
        try:
            self._seed_session_telemetry("SESSION-REHAB-001")
            self._seed_technique_telemetry("TECH-TUINA-001")
            self._seed_technique_telemetry("TECH-TUINA-002")
        except Exception as exc:  # seed remains usable even when optional telemetry fails
            self.store.append_audit(
                resource_type="system",
                resource_id="demo-seed",
                actor="system.seed",
                actor_role="system",
                action="demo.optional_telemetry_failed",
                detail={"error": str(exc)},
            )
        return {
            "seeded": True,
            "count": len(saved),
            "resource_ids": [item["resource"]["resource_id"] for item in saved],
            "synthetic_only": True,
        }

    def reset_demo(self, principal: Principal) -> dict[str, Any]:
        require_capability(principal, "*")
        # Delete every local resource, including dynamically created synthetic batches, while preserving the audit chain.
        deleted = 0
        for record in self.store.list_resource_payloads(limit=5000):
            item = record["resource"]
            if self.store.delete_resource(
                str(item.get("resource_type")),
                str(item.get("resource_id")),
                actor=principal.username,
                actor_role=principal.role,
                reason="explicit_demo_reset",
            ):
                deleted += 1
        seeded = self.seed_demos_if_empty()
        return {"deleted": deleted, **seeded}

    def dashboard(self, principal: Principal) -> dict[str, Any]:
        require_capability(principal, "dashboard.read")
        records = self.store.list_resource_payloads(limit=5000)
        counts = Counter(record["resource"]["resource_type"] for record in records)
        status_counts = Counter(str(record["resource"].get("status", "unknown")) for record in records)
        campus_counts = Counter(str(record["resource"].get("campus_code", "unknown")) for record in records)
        safety_holds: list[dict[str, Any]] = []
        for record in records:
            item = record["resource"]
            if item.get("status") == "held" or (item.get("analysis") or {}).get("safety_gate", {}).get("gate_status") == "blocked":
                safety_holds.append(
                    {
                        "resource_type": item.get("resource_type"),
                        "resource_id": item.get("resource_id"),
                        "display_name": item.get("display_name"),
                        "status": item.get("status"),
                    }
                )
        portfolios = []
        initiatives = {record["resource"]["resource_id"]: record for record in records if record["resource"]["resource_type"] == "strategy_initiative"}
        for portfolio in self.catalogs["strategy"].get("portfolios", []):
            record = initiatives.get(portfolio["initiative_id"])
            portfolios.append(
                {
                    "initiative_id": portfolio["initiative_id"],
                    "display_name": portfolio["display_name"],
                    "maturity": portfolio.get("maturity"),
                    "runtime_status": record["resource"].get("status") if record else "not_instantiated",
                    "revision": record.get("revision") if record else None,
                }
            )
        return {
            "resource_counts": dict(sorted(counts.items())),
            "status_counts": dict(sorted(status_counts.items())),
            "campus_counts": dict(sorted(campus_counts.items())),
            "portfolio_runtime": portfolios,
            "safety_holds": safety_holds,
            "audit_chain": self.store.verify_audit_chain(),
            "catalog": catalog_summary(self.catalogs),
            "boundary": "Counts describe only records in this local SQLite instance; they are not hospital operational performance data.",
            "generated_at": utc_now(),
        }

    def strategy_view(self, principal: Principal) -> dict[str, Any]:
        require_capability(principal, "strategy.read")
        runtime = self.store.list_resource_payloads(resource_type="strategy_initiative", limit=200)
        return {
            "profile": self.catalogs["strategy"],
            "runtime_initiatives": runtime,
            "source_register": self.catalogs["sources"],
            "customization_status": "public_information_customized_not_hospital_commissioned_or_endorsed",
        }

    def list_resources(self, principal: Principal, **filters: Any) -> dict[str, Any]:
        require_any_capability(principal, ("resource.read", "resource.read_own"))
        if principal.role == "patient_proxy":
            # Patient proxy does not receive unrestricted cross-resource lists in this prototype.
            return {"items": [], "boundary": "patient_proxy generic cross-resource listing is disabled"}
        return {"items": self.store.list_resources(**filters)}

    def get_resource(self, resource_type: str, resource_id: str, principal: Principal) -> dict[str, Any]:
        require_any_capability(principal, ("resource.read", "resource.read_own"))
        record = self.store.get_resource(resource_type, resource_id)
        if principal.role == "patient_proxy":
            patient_id = str((record["resource"].get("patient") or {}).get("patient_id", ""))
            if patient_id not in {principal.username, "SYN-P-001", "SYN-P-002"}:
                raise AuthorizationError("patient_proxy cannot read this resource")
        return record

    def create_resource(self, resource_type: str, payload: dict[str, Any], principal: Principal) -> dict[str, Any]:
        self._require_write(principal, resource_type)
        item = self._prepare_resource(resource_type, deep_copy(payload), actor_role=principal.role)
        return self.store.save_resource(
            resource_type,
            item,
            actor=principal.username,
            actor_role=principal.role,
            action="resource.create",
            expected_revision=0,
        )

    def replace_resource(
        self,
        resource_type: str,
        resource_id: str,
        payload: dict[str, Any],
        expected_revision: int | None,
        principal: Principal,
    ) -> dict[str, Any]:
        self._require_write(principal, resource_type)
        if expected_revision is None:
            raise ApplicationValidationError("expected_revision is required for write operations")
        item = deep_copy(payload)
        item["resource_id"] = resource_id
        item = self._prepare_resource(resource_type, item, actor_role=principal.role)
        return self.store.save_resource(
            resource_type,
            item,
            actor=principal.username,
            actor_role=principal.role,
            action="resource.replace",
            expected_revision=expected_revision,
        )

    def delete_resource(self, resource_type: str, resource_id: str, principal: Principal, reason: str) -> dict[str, Any]:
        require_capability(principal, "*")
        return {
            "deleted": self.store.delete_resource(
                resource_type,
                resource_id,
                actor=principal.username,
                actor_role=principal.role,
                reason=reason or "explicit_administrative_delete",
            )
        }

    def analyze_resource(self, resource_type: str, resource_id: str, expected_revision: int | None, principal: Principal) -> dict[str, Any]:
        require_any_capability(principal, ("resource.read", "mesh.read"))
        record = self.store.get_resource(resource_type, resource_id)
        self._check_revision(record, expected_revision)
        item = record["resource"]
        if resource_type == "rehab_episode":
            item["analysis"] = analyze_rehab_episode(item, self.catalogs)
        elif resource_type == "eras_episode":
            item["analysis"] = analyze_eras_episode(item, self.catalogs)
        elif resource_type == "research_protocol":
            item["analysis"] = analyze_protocol(item, self.catalogs)
        else:
            raise ApplicationValidationError("resource type has no specialized analyzer", {"resource_type": resource_type})
        return self.store.save_resource(
            resource_type,
            item,
            actor=principal.username,
            actor_role=principal.role,
            action=f"{resource_type}.analyze",
            expected_revision=record["revision"],
        )

    def add_rehab_assessment(
        self, episode_id: str, payload: dict[str, Any], expected_revision: int | None, principal: Principal
    ) -> dict[str, Any]:
        require_any_capability(principal, ("rehab.write", "rehab.checkin"))
        record = self.store.get_resource("rehab_episode", episode_id)
        self._check_revision(record, expected_revision)
        episode = record["resource"]
        item = add_assessment(episode, payload, actor_role=principal.role, catalogs=self.catalogs)
        saved = self.store.save_resource(
            "rehab_episode",
            episode,
            actor=principal.username,
            actor_role=principal.role,
            action="rehab.assessment.add",
            expected_revision=record["revision"],
            audit_detail={"assessment_id": item["assessment_id"], "metric_code": item["metric_code"]},
        )
        saved["added_assessment"] = item
        return saved

    def add_rehab_goal(
        self, episode_id: str, payload: dict[str, Any], expected_revision: int | None, principal: Principal
    ) -> dict[str, Any]:
        require_any_capability(principal, ("rehab.write", "goal.write"))
        record = self.store.get_resource("rehab_episode", episode_id)
        self._check_revision(record, expected_revision)
        episode = record["resource"]
        goal = add_goal(episode, payload, actor_role=principal.role)
        episode["analysis"] = analyze_rehab_episode(episode, self.catalogs)
        saved = self.store.save_resource(
            "rehab_episode",
            episode,
            actor=principal.username,
            actor_role=principal.role,
            action="rehab.goal.add",
            expected_revision=record["revision"],
            audit_detail={"goal_id": goal["goal_id"]},
        )
        saved["added_goal"] = goal
        return saved

    def simulate_rehab(
        self, episode_id: str, payload: dict[str, Any], expected_revision: int | None, principal: Principal
    ) -> dict[str, Any]:
        require_capability(principal, "device_session.run")
        episode_record = self.store.get_resource("rehab_episode", episode_id)
        self._check_revision(episode_record, expected_revision)
        episode = episode_record["resource"]
        session_id = str(payload.get("session_id") or new_id("rehab-session"))
        try:
            session_record = self.store.get_resource("rehab_session", session_id)
            session = session_record["resource"]
            expected_session_revision = payload.get("expected_session_revision", session_record["revision"])
            if int(expected_session_revision) != int(session_record["revision"]):
                raise RevisionConflict(
                    f"rehab_session/{session_id} revision is {session_record['revision']}, expected {expected_session_revision}"
                )
        except ResourceNotFound:
            subject_kind = str((episode.get("patient") or {}).get("subject_kind") or "synthetic")
            plan = episode.get("session_plan") or {}
            session = ensure_resource_shape(
                "rehab_session",
                {
                    "resource_id": session_id,
                    "parent_id": episode_id,
                    "display_name": payload.get("display_name") or f"{episode.get('display_name')} - 模拟训练会话",
                    "campus_code": episode.get("campus_code"),
                    "status": "planned",
                    "subject_kind": subject_kind,
                    "device_id": payload.get("device_id") or plan.get("device_id"),
                    "adapter_id": payload.get("adapter_id") or "simulator-v1",
                    "approved_session": bool(payload.get("approved_session", plan.get("status") == "approved")),
                    "operator_present": bool(payload.get("operator_present", True)),
                    "operator_id": principal.username,
                    "consent_current": bool(payload.get("consent_current", (episode.get("consent") or {}).get("device_session", False))),
                    "calibration_current": bool(payload.get("calibration_current", True)),
                    "emergency_stop_verified": bool(payload.get("emergency_stop_verified", True)),
                    "stop_conditions_recorded": bool(payload.get("stop_conditions_recorded", bool(plan.get("stop_conditions")))),
                    "duration_seconds": payload.get("duration_seconds", 180),
                    "simulation_seed": payload.get("simulation_seed", 41),
                    "clinical_execution": False,
                    "source_status": "engineering_configuration",
                    "human_review_required": True,
                },
            )
            expected_session_revision = 0
        device_id = str(session.get("device_id") or "")
        device = self.store.get_resource("device", device_id)["resource"] if device_id else None
        simulation = simulate_rehab_session(
            session,
            device=device,
            sample_count=int(payload.get("sample_count", 160)),
        )
        merge_session_metrics(session, simulation)
        session_saved = self.store.save_resource(
            "rehab_session",
            session,
            actor=principal.username,
            actor_role=principal.role,
            action="rehab_session.simulate",
            expected_revision=int(expected_session_revision),
            audit_detail={"simulation_executed": simulation["simulation_executed"], "sample_count": len(simulation["samples"])},
        )
        if simulation["samples"]:
            self.store.add_telemetry(
                session_id,
                simulation["samples"],
                actor=principal.username,
                actor_role=principal.role,
                replace=True,
            )
        refs = [item for item in episode.get("session_refs", []) if item.get("session_id") != session_id]
        refs.append(
            {
                "session_id": session_id,
                "status": session.get("status"),
                "recorded_at": utc_now(),
                "metrics": simulation.get("metrics", {}),
            }
        )
        episode["session_refs"] = refs
        episode["analysis"] = analyze_rehab_episode(episode, self.catalogs)
        episode_saved = self.store.save_resource(
            "rehab_episode",
            episode,
            actor=principal.username,
            actor_role=principal.role,
            action="rehab.session.link",
            expected_revision=episode_record["revision"],
            audit_detail={"session_id": session_id},
        )
        return {
            "episode": episode_saved,
            "session": session_saved,
            "simulation": {k: v for k, v in simulation.items() if k != "samples"},
            "telemetry_sample_count": len(simulation["samples"]),
        }

    def simulate_technique(
        self, capture_id: str, payload: dict[str, Any], expected_revision: int | None, principal: Principal
    ) -> dict[str, Any]:
        require_capability(principal, "technique.capture")
        record = self.store.get_resource("technique_capture", capture_id)
        self._check_revision(record, expected_revision)
        capture = record["resource"]
        result = simulate_capture(capture, sample_count=int(payload.get("sample_count", 180)))
        merge_capture_result(capture, result)
        saved = self.store.save_resource(
            "technique_capture",
            capture,
            actor=principal.username,
            actor_role=principal.role,
            action="technique.capture.simulate",
            expected_revision=record["revision"],
            audit_detail={"sample_count": len(result["samples"]), "subject_kind": capture.get("subject_kind")},
        )
        self.store.add_telemetry(
            capture_id,
            result["samples"],
            actor=principal.username,
            actor_role=principal.role,
            replace=True,
        )
        return {
            "capture": saved,
            "result": {k: v for k, v in result.items() if k != "samples"},
            "telemetry_sample_count": len(result["samples"]),
        }

    def compare_techniques(self, payload: dict[str, Any], principal: Principal) -> dict[str, Any]:
        require_any_capability(principal, ("technique.review", "technique.capture"))
        left_id = str(payload.get("left_id", ""))
        right_id = str(payload.get("right_id", ""))
        if not left_id or not right_id:
            raise ApplicationValidationError("left_id and right_id are required")
        left = self.store.list_telemetry(left_id)
        right = self.store.list_telemetry(right_id)
        return {"left_id": left_id, "right_id": right_id, **compare_captures(left, right)}

    def add_eras_checkpoint(
        self, episode_id: str, payload: dict[str, Any], expected_revision: int | None, principal: Principal
    ) -> dict[str, Any]:
        require_capability(principal, "eras.write")
        record = self.store.get_resource("eras_episode", episode_id)
        self._check_revision(record, expected_revision)
        episode = record["resource"]
        checkpoint = add_checkpoint(episode, payload, actor=principal.username)
        episode["analysis"] = analyze_eras_episode(episode, self.catalogs)
        saved = self.store.save_resource(
            "eras_episode",
            episode,
            actor=principal.username,
            actor_role=principal.role,
            action="eras.checkpoint.add",
            expected_revision=record["revision"],
            audit_detail={"checkpoint_id": checkpoint["checkpoint_id"], "code": checkpoint["code"]},
        )
        saved["added_checkpoint"] = checkpoint
        return saved

    def transition_research(
        self, protocol_id: str, payload: dict[str, Any], expected_revision: int | None, principal: Principal
    ) -> dict[str, Any]:
        require_capability(principal, "research.transition")
        record = self.store.get_resource("research_protocol", protocol_id)
        self._check_revision(record, expected_revision)
        protocol = transition_protocol(
            record["resource"],
            str(payload.get("target_state", "")),
            actor=principal.username,
            reason=str(payload.get("reason") or "human recorded transition"),
            catalogs=self.catalogs,
        )
        return self.store.save_resource(
            "research_protocol",
            protocol,
            actor=principal.username,
            actor_role=principal.role,
            action="research.transition",
            expected_revision=record["revision"],
            audit_detail={"target_state": protocol.get("status")},
        )

    def record_ethics(
        self, protocol_id: str, payload: dict[str, Any], expected_revision: int | None, principal: Principal
    ) -> dict[str, Any]:
        require_capability(principal, "ethics.write")
        record = self.store.get_resource("research_protocol", protocol_id)
        self._check_revision(record, expected_revision)
        protocol, review = record_ethics_decision(record["resource"], payload, actor=principal.username)
        review = self._prepare_resource("ethics_review", review, actor_role=principal.role)
        review_saved = self.store.save_resource(
            "ethics_review",
            review,
            actor=principal.username,
            actor_role=principal.role,
            action="ethics.review.record",
            expected_revision=0,
        )
        protocol["analysis"] = analyze_protocol(protocol, self.catalogs)
        protocol_saved = self.store.save_resource(
            "research_protocol",
            protocol,
            actor=principal.username,
            actor_role=principal.role,
            action="research.ethics_reference.update",
            expected_revision=record["revision"],
            audit_detail={"ethics_review_id": review["resource_id"], "decision": review.get("decision")},
        )
        return {"protocol": protocol_saved, "ethics_review": review_saved}

    def add_research_biospecimen(
        self, protocol_id: str, payload: dict[str, Any], expected_revision: int | None, principal: Principal
    ) -> dict[str, Any]:
        require_capability(principal, "biospecimen.write")
        record = self.store.get_resource("research_protocol", protocol_id)
        self._check_revision(record, expected_revision)
        specimen = add_biospecimen(record["resource"], payload, actor=principal.username)
        specimen = self._prepare_resource("biospecimen", specimen, actor_role=principal.role)
        saved = self.store.save_resource(
            "biospecimen",
            specimen,
            actor=principal.username,
            actor_role=principal.role,
            action="biospecimen.register",
            expected_revision=0,
        )
        # Protocol revision is intentionally unchanged: specimen is linked through parent_id.
        return {"biospecimen": saved, "protocol_revision": record["revision"]}


    def ingest_device_telemetry(self, device_id: str, payload: dict[str, Any], principal: Principal) -> dict[str, Any]:
        require_any_capability(principal, ("telemetry.write", "device_session.run", "device.write"))
        device_record = self.store.get_resource("device", device_id)
        device = device_record["resource"]
        if payload.get("clinical_execution") is True:
            raise SafetyValidationError("telemetry ingest cannot authorize clinical device execution")
        subject_kind = str(payload.get("subject_kind") or "synthetic")
        if subject_kind not in {"synthetic", "phantom"}:
            raise SafetyValidationError("bundled adapters accept synthetic or phantom telemetry only")
        session_id = str(payload.get("session_id") or new_id("device-session"))
        samples = payload.get("samples")
        if not isinstance(samples, list) or not samples:
            raise ApplicationValidationError("samples must be a non-empty list")
        if len(samples) > 100000:
            raise ApplicationValidationError("too many telemetry samples", {"max": 100000})
        adapter = next((item for item in self.catalogs["devices"].get("adapters", []) if item.get("adapter_id") == device.get("adapter_id")), {})
        supported = set(adapter.get("supported_channels", []))
        configurable = "configurable" in supported
        normalized: list[dict[str, Any]] = []
        channel_counts: Counter[str] = Counter()
        for index, sample in enumerate(samples):
            if not isinstance(sample, dict):
                raise ApplicationValidationError("each telemetry sample must be an object", {"index": index})
            channel = str(sample.get("channel") or "").strip()
            if not channel:
                raise ApplicationValidationError("telemetry channel is required", {"index": index})
            if supported and not configurable and channel not in supported:
                raise ApplicationValidationError("channel is not supported by adapter", {"channel": channel, "adapter_id": device.get("adapter_id")})
            numeric = sample.get("numeric_value")
            text = sample.get("text_value")
            if numeric is not None:
                numeric = finite_number(numeric)
                if numeric is None:
                    raise ApplicationValidationError("numeric_value must be finite", {"index": index, "channel": channel})
            if numeric is None and text in (None, ""):
                raise ApplicationValidationError("numeric_value or text_value is required", {"index": index, "channel": channel})
            normalized.append({
                "sequence": int(sample.get("sequence", index)),
                "recorded_at": sample.get("recorded_at") or f"T+{index}",
                "channel": channel,
                "numeric_value": numeric,
                "text_value": text,
                "unit": sample.get("unit"),
                "metadata": {**(sample.get("metadata") or {}), "subject_kind": subject_kind, "clinical_execution": False},
            })
            channel_counts[channel] += 1
        telemetry_result = self.store.add_telemetry(
            session_id, normalized, actor=principal.username, actor_role=principal.role, replace=payload.get("replace", True) is not False
        )
        batch = ensure_resource_shape("device_ingest_batch", {
            "resource_id": payload.get("batch_id") or new_id("ingest-batch"),
            "parent_id": session_id,
            "display_name": payload.get("display_name") or f"{device.get('display_name')} 遥测接入批次",
            "campus_code": device.get("campus_code"),
            "status": "accepted",
            "device_id": device_id,
            "session_id": session_id,
            "adapter_id": device.get("adapter_id"),
            "subject_kind": subject_kind,
            "sample_count": len(normalized),
            "channel_counts": dict(sorted(channel_counts.items())),
            "payload_sha256": sha256_json(normalized),
            "clinical_execution": False,
            "source_status": "device_data_workflow_record",
            "human_review_required": True,
        })
        batch_saved = self.store.save_resource(
            "device_ingest_batch", batch, actor=principal.username, actor_role=principal.role,
            action="device.telemetry.ingest", expected_revision=0,
            audit_detail={"device_id": device_id, "session_id": session_id, "sample_count": len(normalized)},
        )
        return {"telemetry": telemetry_result, "batch": batch_saved, "clinical_execution_authorized": False}

    def relation_mesh(self, intent_text: str, principal: Principal) -> dict[str, Any]:
        require_capability(principal, "mesh.read")
        resources = self.store.list_resource_payloads(limit=5000)
        return build_relation_mesh(resources, intent_text=intent_text, catalogs=self.catalogs)

    def fhir_bundle(self, resource_type: str, resource_id: str, principal: Principal) -> dict[str, Any]:
        require_capability(principal, "fhir.export")
        record = self.store.get_resource(resource_type, resource_id)
        return export_fhir_bundle(record["resource"])

    def _prepare_resource(self, resource_type: str, payload: dict[str, Any], *, actor_role: str) -> dict[str, Any]:
        if resource_type not in RESOURCE_TYPES:
            raise ApplicationValidationError("unsupported resource_type", {"resource_type": resource_type})
        item = ensure_resource_shape(resource_type, payload)
        if resource_type == "device":
            validate_device(item, self.catalogs)
        elif resource_type == "rehab_episode":
            validate_rehab_episode(item, actor_role=actor_role, catalogs=self.catalogs)
            item["analysis"] = analyze_rehab_episode(item, self.catalogs)
        elif resource_type == "rehab_session":
            validate_common(item)
        elif resource_type == "technique_capture":
            validate_technique_capture(item)
        elif resource_type == "eras_episode":
            validate_eras_episode(item, self.catalogs)
            item["analysis"] = analyze_eras_episode(item, self.catalogs)
        elif resource_type == "research_protocol":
            validate_research_protocol(item, self.catalogs)
            item["analysis"] = analyze_protocol(item, self.catalogs)
        else:
            validate_common(item)
        return item

    def _require_write(self, principal: Principal, resource_type: str) -> None:
        capability = WRITE_CAPABILITY_BY_TYPE.get(resource_type)
        if not capability:
            raise ApplicationValidationError("unsupported resource_type", {"resource_type": resource_type})
        require_capability(principal, capability)

    @staticmethod
    def _check_revision(record: Mapping[str, Any], expected_revision: int | None) -> None:
        if expected_revision is None:
            raise ApplicationValidationError("expected_revision is required for write operations")
        if int(record["revision"]) != int(expected_revision):
            raise RevisionConflict(f"revision is {record['revision']}, expected {expected_revision}")

    @staticmethod
    def _load_json(path: Path) -> dict[str, Any]:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            raise ValueError(f"{path} must contain a JSON object")
        return data

    def _seed_session_telemetry(self, session_id: str) -> None:
        record = self.store.get_resource("rehab_session", session_id)
        session = record["resource"]
        device = self.store.get_resource("device", str(session["device_id"]))["resource"]
        result = simulate_rehab_session(session, device=device, sample_count=160)
        merge_session_metrics(session, result)
        self.store.save_resource(
            "rehab_session",
            session,
            actor="system.seed",
            actor_role="system",
            action="demo.telemetry.generate",
            expected_revision=record["revision"],
        )
        self.store.add_telemetry(session_id, result["samples"], actor="system.seed", actor_role="system")

    def _seed_technique_telemetry(self, capture_id: str) -> None:
        record = self.store.get_resource("technique_capture", capture_id)
        capture = record["resource"]
        result = simulate_capture(capture, sample_count=180)
        merge_capture_result(capture, result)
        self.store.save_resource(
            "technique_capture",
            capture,
            actor="system.seed",
            actor_role="system",
            action="demo.technique.generate",
            expected_revision=record["revision"],
        )
        self.store.add_telemetry(capture_id, result["samples"], actor="system.seed", actor_role="system")


class SmartHarborRequestHandler(BaseHTTPRequestHandler):
    server_version = "PudongSmartRehabHarbor/1.0"
    app: SmartHarborApplication

    def do_GET(self) -> None:  # noqa: N802
        self._dispatch("GET")

    def do_HEAD(self) -> None:  # noqa: N802
        self._dispatch("HEAD")

    def do_POST(self) -> None:  # noqa: N802
        self._dispatch("POST")

    def do_PUT(self) -> None:  # noqa: N802
        self._dispatch("PUT")

    def do_DELETE(self) -> None:  # noqa: N802
        self._dispatch("DELETE")

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(HTTPStatus.NO_CONTENT)
        self._common_headers(api=True)
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization,Content-Type,If-Match")
        self.end_headers()

    def log_message(self, format: str, *args: Any) -> None:
        if os.environ.get("SMART_HARBOR_QUIET") != "1":
            super().log_message(format, *args)

    def _dispatch(self, method: str) -> None:
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path.startswith("/api/"):
                self._dispatch_api(method, path, query)
            elif method in {"GET", "HEAD"}:
                self._serve_static(path)
            else:
                self._json_error(HTTPStatus.METHOD_NOT_ALLOWED, "method_not_allowed", "method not allowed")
        except AuthenticationError as exc:
            self._json_error(HTTPStatus.UNAUTHORIZED, "authentication_error", str(exc))
        except AuthorizationError as exc:
            self._json_error(HTTPStatus.FORBIDDEN, "authorization_error", str(exc))
        except ResourceNotFound as exc:
            self._json_error(HTTPStatus.NOT_FOUND, "resource_not_found", str(exc))
        except RevisionConflict as exc:
            self._json_error(HTTPStatus.CONFLICT, "revision_conflict", str(exc))
        except SafetyValidationError as exc:
            self._json_response(
                {"error": {"code": "safety_validation_error", "message": str(exc), "details": exc.details}},
                HTTPStatus.UNPROCESSABLE_ENTITY,
            )
        except ApplicationValidationError as exc:
            self._json_response(
                {"error": {"code": "validation_error", "message": str(exc), "details": exc.details}},
                HTTPStatus.UNPROCESSABLE_ENTITY,
            )
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            self._json_error(HTTPStatus.BAD_REQUEST, "bad_request", str(exc))
        except Exception as exc:  # pragma: no cover - defensive boundary
            traceback.print_exc()
            self._json_error(HTTPStatus.INTERNAL_SERVER_ERROR, "internal_error", str(exc))

    def _dispatch_api(self, method: str, path: str, query: dict[str, list[str]]) -> None:
        if path == "/api/health" and method == "GET":
            self._json_response(self.app.health())
            return
        if path == "/api/auth/login" and method == "POST":
            body = self._read_json()
            principal = authenticate(str(body.get("username", "")), str(body.get("password", "")))
            token = issue_token(principal)
            self.app.store.append_audit(
                resource_type="auth_session",
                resource_id=principal.username,
                actor=principal.username,
                actor_role=principal.role,
                action="auth.login",
                detail={"workflow_label_only": True},
            )
            self._json_response(
                {"token": token, "principal": principal.as_dict(), "expires_in_seconds": token_ttl_seconds()}
            )
            return

        principal = self._principal()
        if path == "/api/auth/me" and method == "GET":
            self._json_response({"principal": principal.as_dict()})
            return
        if path == "/api/bootstrap" and method == "GET":
            require_capability(principal, "catalog.read")
            self._json_response(
                {
                    "principal": principal.as_dict(),
                    "health": self.app.health(),
                    "catalog_summary": catalog_summary(self.app.catalogs),
                    "resource_types": list(RESOURCE_TYPES),
                    "workflow_label_boundary": "demo identities are workflow labels, not identity proof, credentials, or electronic signatures",
                }
            )
            return
        if path == "/api/dashboard" and method == "GET":
            self._json_response(self.app.dashboard(principal))
            return
        if path == "/api/strategy" and method == "GET":
            self._json_response(self.app.strategy_view(principal))
            return
        if path == "/api/resources" and method == "GET":
            resource_type = query.get("type", [None])[0]
            parent_id = query.get("parent_id", [None])[0]
            campus_code = query.get("campus_code", [None])[0]
            status = query.get("status", [None])[0]
            limit = int(query.get("limit", ["500"])[0])
            self._json_response(
                self.app.list_resources(
                    principal,
                    resource_type=resource_type,
                    parent_id=parent_id,
                    campus_code=campus_code,
                    status=status,
                    limit=limit,
                )
            )
            return
        if path == "/api/resources" and method == "POST":
            body = self._read_json()
            resource_type = str(body.get("resource_type", ""))
            payload = body.get("resource") if isinstance(body.get("resource"), dict) else body
            self._json_response(self.app.create_resource(resource_type, payload, principal), HTTPStatus.CREATED)
            return
        if path.startswith("/api/catalog/") and method == "GET":
            require_capability(principal, "catalog.read")
            name = path.rsplit("/", 1)[-1]
            if name not in self.app.catalogs:
                self._json_error(HTTPStatus.NOT_FOUND, "catalog_not_found", "catalog not found")
            else:
                self._json_response(self.app.catalogs[name])
            return
        if path == "/api/techniques/compare" and method == "POST":
            self._json_response(self.app.compare_techniques(self._read_json(), principal))
            return
        if path == "/api/mesh" and method == "GET":
            intent_text = query.get("intent", [""])[0]
            self._json_response(self.app.relation_mesh(intent_text, principal))
            return
        if path == "/api/audit" and method == "GET":
            require_capability(principal, "audit.read")
            resource_type = query.get("resource_type", [None])[0]
            resource_id = query.get("resource_id", [None])[0]
            limit = int(query.get("limit", ["500"])[0])
            self._json_response(
                {"items": self.app.store.list_audit(resource_type=resource_type, resource_id=resource_id, limit=limit)}
            )
            return
        if path == "/api/audit/verify" and method == "GET":
            require_capability(principal, "audit.read")
            self._json_response(self.app.store.verify_audit_chain())
            return
        if path == "/api/demo/reset" and method == "POST":
            self._json_response(self.app.reset_demo(principal))
            return


        match = re.fullmatch(r"/api/device-ingest/([^/]+)", path)
        if match and method == "POST":
            self._json_response(self.app.ingest_device_telemetry(match.group(1), self._read_json(), principal), HTTPStatus.CREATED)
            return

        match = re.fullmatch(r"/api/telemetry/([^/]+)", path)
        if match and method == "GET":
            require_any_capability(principal, ("telemetry.read", "resource.read"))
            limit = int(query.get("limit", ["10000"])[0])
            self._json_response({"session_id": match.group(1), "items": self.app.store.list_telemetry(match.group(1), limit=limit)})
            return

        match = re.fullmatch(r"/api/fhir/([^/]+)/([^/]+)", path)
        if match and method == "GET":
            bundle = self.app.fhir_bundle(match.group(1), match.group(2), principal)
            self._json_response(bundle, content_type="application/fhir+json; charset=utf-8")
            return

        match = re.fullmatch(r"/api/rehab/([^/]+)/(assessments|goals|analyze|simulate)", path)
        if match and method == "POST":
            episode_id, operation = match.groups()
            body = self._read_json()
            expected = self._expected_revision(body)
            if operation == "assessments":
                result = self.app.add_rehab_assessment(episode_id, body, expected, principal)
                self._json_response(result, HTTPStatus.CREATED)
            elif operation == "goals":
                result = self.app.add_rehab_goal(episode_id, body, expected, principal)
                self._json_response(result, HTTPStatus.CREATED)
            elif operation == "analyze":
                self._json_response(self.app.analyze_resource("rehab_episode", episode_id, expected, principal))
            else:
                self._json_response(self.app.simulate_rehab(episode_id, body, expected, principal))
            return

        match = re.fullmatch(r"/api/techniques/([^/]+)/simulate", path)
        if match and method == "POST":
            body = self._read_json()
            self._json_response(
                self.app.simulate_technique(match.group(1), body, self._expected_revision(body), principal)
            )
            return

        match = re.fullmatch(r"/api/eras/([^/]+)/(checkpoints|analyze)", path)
        if match and method == "POST":
            episode_id, operation = match.groups()
            body = self._read_json()
            expected = self._expected_revision(body)
            if operation == "checkpoints":
                self._json_response(
                    self.app.add_eras_checkpoint(episode_id, body, expected, principal), HTTPStatus.CREATED
                )
            else:
                self._json_response(self.app.analyze_resource("eras_episode", episode_id, expected, principal))
            return

        match = re.fullmatch(r"/api/research/([^/]+)/(transition|ethics|biospecimens|analyze)", path)
        if match and method == "POST":
            protocol_id, operation = match.groups()
            body = self._read_json()
            expected = self._expected_revision(body)
            if operation == "transition":
                self._json_response(self.app.transition_research(protocol_id, body, expected, principal))
            elif operation == "ethics":
                self._json_response(self.app.record_ethics(protocol_id, body, expected, principal), HTTPStatus.CREATED)
            elif operation == "biospecimens":
                self._json_response(
                    self.app.add_research_biospecimen(protocol_id, body, expected, principal), HTTPStatus.CREATED
                )
            else:
                self._json_response(self.app.analyze_resource("research_protocol", protocol_id, expected, principal))
            return

        match = re.fullmatch(r"/api/resources/([^/]+)/([^/]+)(?:/(analyze))?", path)
        if match:
            resource_type, resource_id, suffix = match.groups()
            if suffix == "analyze" and method == "POST":
                body = self._read_json()
                self._json_response(
                    self.app.analyze_resource(resource_type, resource_id, self._expected_revision(body), principal)
                )
                return
            if suffix is None and method == "GET":
                self._json_response(self.app.get_resource(resource_type, resource_id, principal))
                return
            if suffix is None and method == "PUT":
                body = self._read_json()
                payload = body.get("resource") if isinstance(body.get("resource"), dict) else body
                self._json_response(
                    self.app.replace_resource(
                        resource_type,
                        resource_id,
                        payload,
                        self._expected_revision(body),
                        principal,
                    )
                )
                return
            if suffix is None and method == "DELETE":
                body = self._read_json()
                self._json_response(
                    self.app.delete_resource(resource_type, resource_id, principal, str(body.get("reason", "")))
                )
                return

        self._json_error(HTTPStatus.NOT_FOUND, "not_found", "API route not found")

    def _principal(self) -> Principal:
        token = bearer_token(self.headers)
        if not token:
            raise AuthenticationError("缺少 Bearer 令牌")
        return verify_token(token)

    def _read_json(self) -> dict[str, Any]:
        raw_length = self.headers.get("Content-Length", "0")
        try:
            length = int(raw_length)
        except ValueError as exc:
            raise ValueError("invalid Content-Length") from exc
        maximum = max_body_bytes()
        if length < 0 or length > maximum:
            raise ApplicationValidationError("request body too large", {"max_bytes": maximum})
        raw = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("request body must be UTF-8 JSON") from exc
        if not isinstance(data, dict):
            raise ValueError("request body must be a JSON object")
        return data

    def _expected_revision(self, body: Mapping[str, Any]) -> int | None:
        if "expected_revision" in body:
            return int(body["expected_revision"])
        header = self.headers.get("If-Match")
        if header:
            return int(header.strip().strip('"'))
        return None

    def _serve_static(self, path: str) -> None:
        relative = "index.html" if path in {"", "/"} else path.lstrip("/")
        target = (WEB_DIR / relative).resolve()
        root = WEB_DIR.resolve()
        if root not in target.parents and target != root:
            self._json_error(HTTPStatus.FORBIDDEN, "forbidden", "invalid path")
            return
        if not target.is_file():
            target = WEB_DIR / "index.html"
        content = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(HTTPStatus.OK)
        self._common_headers(api=False)
        textual = content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}
        self.send_header("Content-Type", f"{content_type}; charset=utf-8" if textual else content_type)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(content)

    def _json_response(
        self,
        payload: Any,
        status: HTTPStatus = HTTPStatus.OK,
        content_type: str = "application/json; charset=utf-8",
    ) -> None:
        raw = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self._common_headers(api=True)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _json_error(self, status: HTTPStatus, code: str, message: str) -> None:
        self._json_response({"error": {"code": code, "message": message}}, status)

    def _common_headers(self, *, api: bool) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
        )
        if api:
            self.send_header("Cache-Control", "no-store")


def build_handler(app: SmartHarborApplication) -> type[SmartHarborRequestHandler]:
    class BoundHandler(SmartHarborRequestHandler):
        pass

    BoundHandler.app = app
    return BoundHandler


def serve(host: str, port: int, *, seed_demo: bool = True, store: SmartHarborStore | None = None) -> None:
    app = SmartHarborApplication(store)
    if seed_demo:
        result = app.seed_demos_if_empty()
        if result.get("seeded"):
            print(f"Seeded {result['count']} synthetic demo resources.")
    server = ThreadingHTTPServer((host, port), build_handler(app))
    print(f"{PROJECT_NAME_ZH} running at http://{host}:{port}")
    print("Demo usernames: admin / leader / rehabdoc / tcmdoc / therapist / engineer / research / ethics / quality / data / patient")
    print("Demo password: SMART_HARBOR_DEMO_PASSWORD (default: mesh41-demo)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()
