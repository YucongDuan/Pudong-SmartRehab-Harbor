from __future__ import annotations

import re
from typing import Any

from .domain import utc_now

BASE = "https://example.org/fhir/StructureDefinition/"


def _id(value: Any) -> str:
    safe = re.sub(r"[^A-Za-z0-9\-.]", "-", str(value or "id"))
    return safe[:64] or "id"


def _entry(resource: dict[str, Any]) -> dict[str, Any]:
    return {"fullUrl": f"urn:uuid:{resource['resourceType']}-{resource['id']}", "resource": resource}


def _patient(payload: dict[str, Any]) -> dict[str, Any]:
    patient = payload.get("patient") or {}
    patient_id = _id(patient.get("patient_id") or f"patient-{payload.get('resource_id')}")
    resource: dict[str, Any] = {
        "resourceType": "Patient",
        "id": patient_id,
        "identifier": [{"system": "https://example.org/synthetic-pseudonym", "value": str(patient.get("pseudonym") or "匿名")}],
        "name": [{"use": "anonymous", "text": str(patient.get("pseudonym") or "匿名")}],
        "extension": [
            {"url": BASE + "subject-kind", "valueString": str(patient.get("subject_kind") or "unknown")},
            {"url": BASE + "synthetic-data", "valueBoolean": bool(patient.get("subject_kind") == "synthetic")},
        ],
    }
    if patient.get("birth_year"):
        resource["birthDate"] = f"{int(patient['birth_year']):04d}"
    return resource


def export_fhir_bundle(payload: dict[str, Any]) -> dict[str, Any]:
    resource_type = str(payload.get("resource_type", ""))
    entries: list[dict[str, Any]] = []
    if resource_type in {"rehab_episode", "eras_episode"}:
        patient = _patient(payload)
        entries.append(_entry(patient))
        episode = {
            "resourceType": "EpisodeOfCare",
            "id": _id(payload.get("resource_id")),
            "status": _episode_status(str(payload.get("status", "planned"))),
            "patient": {"reference": f"Patient/{patient['id']}"},
            "extension": [
                {"url": BASE + "campus-code", "valueString": str(payload.get("campus_code"))},
                {"url": BASE + "source-status", "valueString": str(payload.get("source_status"))},
            ],
        }
        entries.append(_entry(episode))
        if resource_type == "rehab_episode":
            entries.extend(_rehab_entries(payload, patient["id"], episode["id"]))
        else:
            entries.extend(_eras_entries(payload, patient["id"], episode["id"]))
    elif resource_type == "device":
        entries.append(_entry(_device(payload)))
    elif resource_type == "technique_capture":
        entries.extend(_technique_entries(payload))
    elif resource_type == "research_protocol":
        entries.extend(_research_entries(payload))
    else:
        entries.append(
            _entry(
                {
                    "resourceType": "Basic",
                    "id": _id(payload.get("resource_id")),
                    "code": {"text": resource_type or "local-resource"},
                    "extension": [{"url": BASE + "local-json-summary", "valueString": str(payload.get("display_name") or "")}],
                }
            )
        )
    provenance_targets = [
        {"reference": f"{entry['resource']['resourceType']}/{entry['resource']['id']}"}
        for entry in entries
    ]
    provenance = {
        "resourceType": "Provenance",
        "id": _id(f"provenance-{payload.get('resource_id')}"),
        "recorded": utc_now(),
        "target": provenance_targets,
        "agent": [{"type": {"text": "software assembler"}, "who": {"display": "DIKWP-Mesh 4.1 SmartRehab Harbor"}}],
        "extension": [
            {"url": BASE + "export-boundary", "valueString": "prototype collection bundle; no institutional conformance claim"}
        ],
    }
    entries.append(_entry(provenance))
    return {
        "resourceType": "Bundle",
        "id": _id(f"bundle-{payload.get('resource_id')}"),
        "type": "collection",
        "timestamp": utc_now(),
        "meta": {"tag": [{"system": "https://example.org/tags", "code": "synthetic-prototype"}]},
        "entry": entries,
    }


def _episode_status(status: str) -> str:
    return {
        "draft": "planned",
        "new": "planned",
        "active": "active",
        "held": "onhold",
        "completed": "finished",
        "cancelled": "cancelled",
    }.get(status, "planned")


def _device(payload: dict[str, Any]) -> dict[str, Any]:
    status = "active" if payload.get("status") not in {"held", "retired"} else "inactive"
    return {
        "resourceType": "Device",
        "id": _id(payload.get("resource_id")),
        "status": status,
        "deviceName": [{"name": str(payload.get("display_name") or payload.get("resource_id")), "type": "user-friendly-name"}],
        "serialNumber": str(payload.get("serial_number") or "synthetic"),
        "type": {"text": str(payload.get("device_type") or "local device")},
        "extension": [
            {"url": BASE + "adapter-id", "valueString": str(payload.get("adapter_id") or "")},
            {"url": BASE + "clinical-execution-allowed", "valueBoolean": bool(payload.get("clinical_execution_allowed"))},
        ],
    }


def _rehab_entries(payload: dict[str, Any], patient_id: str, episode_id: str) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for item in payload.get("assessments", []):
        value: dict[str, Any]
        if isinstance(item.get("value"), bool):
            value = {"valueBoolean": item.get("value")}
        elif isinstance(item.get("value"), (int, float)):
            value = {"valueQuantity": {"value": item.get("value"), "unit": item.get("unit") or ""}}
        else:
            value = {"valueString": str(item.get("value") or "")}
        observation = {
            "resourceType": "Observation",
            "id": _id(item.get("assessment_id")),
            "status": "final",
            "code": {"text": str(item.get("metric_code"))},
            "subject": {"reference": f"Patient/{patient_id}"},
            "encounter": {"reference": f"EpisodeOfCare/{episode_id}"},
            "effectiveDateTime": str(item.get("recorded_at") or utc_now()),
            **value,
            "note": [{"text": str(item.get("raw_expression") or "")}],
            "extension": [
                {"url": BASE + "axis-id", "valueString": str(item.get("axis_id") or "")},
                {"url": BASE + "observer-label", "valueString": str(item.get("observer") or "")},
            ],
        }
        entries.append(_entry(observation))
    for goal in payload.get("goals", []):
        goal_resource = {
            "resourceType": "Goal",
            "id": _id(goal.get("goal_id")),
            "lifecycleStatus": _goal_status(str(goal.get("status", "proposed"))),
            "description": {"text": str(goal.get("display_name") or "")},
            "subject": {"reference": f"Patient/{patient_id}"},
        }
        if goal.get("target_date"):
            goal_resource["target"] = [{"dueDate": str(goal.get("target_date"))}]
        entries.append(_entry(goal_resource))
    plan = payload.get("session_plan") or {}
    care_plan = {
        "resourceType": "CarePlan",
        "id": _id(f"careplan-{payload.get('resource_id')}"),
        "status": "active" if plan.get("status") == "approved" else "draft",
        "intent": "plan",
        "subject": {"reference": f"Patient/{patient_id}"},
        "title": str(payload.get("display_name") or "康复计划"),
        "activity": [{"detail": {"status": "scheduled", "description": str(plan.get("modality") or "human-reviewed rehabilitation workflow")}}] if plan else [],
        "extension": [{"url": BASE + "autonomous-execution-authorized", "valueBoolean": False}],
    }
    entries.append(_entry(care_plan))
    return entries


def _goal_status(status: str) -> str:
    return {
        "proposed": "proposed",
        "planned": "planned",
        "approved": "accepted",
        "active": "active",
        "completed": "completed",
        "cancelled": "cancelled",
        "held": "on-hold",
    }.get(status, "proposed")


def _eras_entries(payload: dict[str, Any], patient_id: str, episode_id: str) -> list[dict[str, Any]]:
    plan = {
        "resourceType": "CarePlan",
        "id": _id(f"cm-eras-{payload.get('resource_id')}"),
        "status": "active" if payload.get("status") == "active" else "completed" if payload.get("status") == "completed" else "draft",
        "intent": "plan",
        "subject": {"reference": f"Patient/{patient_id}"},
        "title": str(payload.get("display_name") or "CM-ERAS workflow"),
        "extension": [
            {"url": BASE + "template-id", "valueString": str(payload.get("template_id") or "")},
            {"url": BASE + "autonomous-orders", "valueBoolean": False},
        ],
    }
    entries = [_entry(plan)]
    for item in payload.get("checkpoints", []):
        task = {
            "resourceType": "Task",
            "id": _id(item.get("checkpoint_id")),
            "status": "completed" if item.get("status") == "complete" else "on-hold" if item.get("status") == "held" else "requested",
            "intent": "order",
            "for": {"reference": f"Patient/{patient_id}"},
            "encounter": {"reference": f"EpisodeOfCare/{episode_id}"},
            "description": str(item.get("code") or "checkpoint"),
            "authoredOn": str(item.get("recorded_at") or utc_now()),
            "extension": [{"url": BASE + "phase-id", "valueString": str(item.get("phase_id") or "")}],
        }
        entries.append(_entry(task))
    return entries


def _technique_entries(payload: dict[str, Any]) -> list[dict[str, Any]]:
    device = {
        "resourceType": "Device",
        "id": _id(payload.get("device_id") or "technique-device"),
        "status": "active",
        "deviceName": [{"name": str(payload.get("device_id") or "力反馈训练设备"), "type": "user-friendly-name"}],
        "type": {"text": "force-feedback technique capture device"},
    }
    observation = {
        "resourceType": "Observation",
        "id": _id(payload.get("resource_id")),
        "status": "final",
        "code": {"text": "technique capture engineering metrics"},
        "device": {"reference": f"Device/{device['id']}"},
        "valueString": str(payload.get("metrics") or {}),
        "extension": [
            {"url": BASE + "subject-kind", "valueString": str(payload.get("subject_kind") or "")},
            {"url": BASE + "human-playback-authorized", "valueBoolean": False},
        ],
    }
    return [_entry(device), _entry(observation)]


def _research_entries(payload: dict[str, Any]) -> list[dict[str, Any]]:
    status = {
        "concept": "in-review",
        "scientific_review": "in-review",
        "ethics_review": "in-review",
        "regulatory_determination": "in-review",
        "ready_for_recruitment": "approved",
        "analysis": "administratively-completed",
        "closed": "completed",
        "held": "temporarily-closed-to-accrual",
        "terminated": "withdrawn",
    }.get(str(payload.get("status")), "in-review")
    study = {
        "resourceType": "ResearchStudy",
        "id": _id(payload.get("resource_id")),
        "status": status,
        "title": str(payload.get("display_name") or "research protocol"),
        "description": str(payload.get("hypothesis_expression") or ""),
        "identifier": [{"system": "https://example.org/local-research-protocol", "value": str(payload.get("protocol_version") or "draft")}],
        "extension": [
            {"url": BASE + "program-id", "valueString": str(payload.get("program_id") or "")},
            {"url": BASE + "real-human-recruitment-authorized", "valueBoolean": False},
            {"url": BASE + "hgr-applicability", "valueString": str((payload.get("hgr") or {}).get("applicability") or "")},
        ],
    }
    return [_entry(study)]
