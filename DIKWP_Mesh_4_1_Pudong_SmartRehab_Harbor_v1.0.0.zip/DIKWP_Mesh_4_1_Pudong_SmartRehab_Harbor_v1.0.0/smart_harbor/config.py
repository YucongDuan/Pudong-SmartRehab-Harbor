from __future__ import annotations

import os
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent
DATA_DIR = PROJECT_ROOT / "data"
WEB_DIR = PROJECT_ROOT / "web"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
VAR_DIR = PROJECT_ROOT / "var"
DEFAULT_DB_PATH = VAR_DIR / "pudong_smartrehab_harbor.db"

STRATEGY_PATH = DATA_DIR / "strategy_profile.json"
REHAB_PATH = DATA_DIR / "rehab_profiles.json"
DEVICE_PATH = DATA_DIR / "device_catalog.json"
ERAS_PATH = DATA_DIR / "eras_templates.json"
RESEARCH_PATH = DATA_DIR / "research_programs.json"
GOVERNANCE_PATH = DATA_DIR / "governance_rules.json"
SOURCE_PATH = DATA_DIR / "source_register.json"
DEMO_RESOURCES_PATH = DATA_DIR / "demo_resources.json"


def db_path() -> Path:
    raw = os.environ.get("SMART_HARBOR_DB")
    path = Path(raw).expanduser().resolve() if raw else DEFAULT_DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def host() -> str:
    return os.environ.get("SMART_HARBOR_HOST", "127.0.0.1")


def port() -> int:
    raw = os.environ.get("SMART_HARBOR_PORT", "8791")
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError("SMART_HARBOR_PORT must be an integer") from exc
    if not 1 <= value <= 65535:
        raise ValueError("SMART_HARBOR_PORT must be between 1 and 65535")
    return value


def token_secret() -> str:
    return os.environ.get("SMART_HARBOR_TOKEN_SECRET", "mesh41-smart-harbor-demo-change-me")


def demo_password() -> str:
    return os.environ.get("SMART_HARBOR_DEMO_PASSWORD", "mesh41-demo")


def token_ttl_seconds() -> int:
    raw = os.environ.get("SMART_HARBOR_TOKEN_TTL_SECONDS", "28800")
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError("SMART_HARBOR_TOKEN_TTL_SECONDS must be an integer") from exc
    return max(300, min(value, 7 * 24 * 3600))


def max_body_bytes() -> int:
    raw = os.environ.get("SMART_HARBOR_MAX_BODY_BYTES", str(8 * 1024 * 1024))
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError("SMART_HARBOR_MAX_BODY_BYTES must be an integer") from exc
    return max(1024, min(value, 64 * 1024 * 1024))
