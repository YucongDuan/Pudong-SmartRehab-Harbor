from __future__ import annotations

from collections import defaultdict, deque
from typing import Any, Iterable

from .catalog import load_catalogs
from .domain import DIKWP_CHANNELS, new_id, normalize_text, stable_unique, utc_now


def _role_for_resource(resource_type: str) -> str:
    mapping = {
        "strategy_initiative": "P",
        "rehab_episode": "P",
        "rehab_session": "W",
        "device": "K",
        "technique_capture": "D",
        "eras_episode": "W",
        "research_protocol": "K",
        "ethics_review": "W",
        "biospecimen": "D",
        "device_ingest_batch": "D",
        "referral": "I",
    }
    return mapping.get(resource_type, "I")


def _node(node_id: str, label: str, role: str, *, source_status: str, kind: str, payload_ref: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "node_id": node_id,
        "label": label,
        "dikwp_role": role,
        "role_status": "runtime_path_address_not_concept_definition",
        "source_status": source_status,
        "kind": kind,
        "payload_ref": payload_ref or {},
    }


def _edge(source: str, target: str, relation: str, channel: str, *, source_status: str = "engineering_relation") -> dict[str, Any]:
    if channel not in DIKWP_CHANNELS:
        raise ValueError(f"invalid DIKWP channel: {channel}")
    return {
        "edge_id": new_id("edge"),
        "source": source,
        "target": target,
        "relation": relation,
        "dikwp_channel": channel,
        "source_status": source_status,
    }


def build_relation_mesh(
    resources: Iterable[dict[str, Any]],
    *,
    intent_text: str = "",
    catalogs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    runtime = catalogs or load_catalogs()
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    node_ids: set[str] = set()

    intent_id = "mesh-intent-current"
    intent_label = intent_text.strip() or "查看当前智慧港运行闭环"
    nodes.append(_node(intent_id, intent_label, "P", source_status="explicit" if intent_text.strip() else "context_inferred", kind="analysis_intent"))
    node_ids.add(intent_id)

    for campus in runtime["strategy"].get("campuses", []):
        node_id = f"campus:{campus['campus_id']}"
        nodes.append(_node(node_id, campus["display_name"], "K", source_status=campus.get("role_status", "engineering_mapping"), kind="campus"))
        node_ids.add(node_id)
    for portfolio in runtime["strategy"].get("portfolios", []):
        node_id = f"portfolio:{portfolio['initiative_id']}"
        nodes.append(_node(node_id, portfolio["display_name"], "P", source_status="source_mapped", kind="portfolio"))
        node_ids.add(node_id)
        edges.append(_edge(node_id, intent_id, "portfolio_relevance_to_current_intent", "P→P", source_status="intent_conditioned"))
    for dep in runtime["strategy"].get("portfolio_dependencies", []):
        source = f"portfolio:{dep['from']}"
        target = f"portfolio:{dep['to']}"
        if source in node_ids and target in node_ids:
            edges.append(_edge(source, target, dep.get("relation", "related"), dep.get("dikwp_channel", "P→P"), source_status="engineering_mapping"))

    materialized = list(resources)
    for record in materialized:
        payload = record.get("resource", record)
        resource_type = str(payload.get("resource_type") or record.get("resource_type") or "resource")
        resource_id = str(payload.get("resource_id") or record.get("resource_id") or new_id("resource"))
        node_id = f"resource:{resource_type}:{resource_id}"
        node_ids.add(node_id)
        nodes.append(
            _node(
                node_id,
                str(payload.get("display_name") or resource_id),
                _role_for_resource(resource_type),
                source_status=str(payload.get("source_status") or "workflow_record"),
                kind=resource_type,
                payload_ref={"resource_type": resource_type, "resource_id": resource_id},
            )
        )
        campus = f"campus:{payload.get('campus_code')}"
        if campus in node_ids:
            edges.append(_edge(campus, node_id, "hosts_or_operates", "K→W", source_status="workflow_mapping"))
        parent_id = payload.get("parent_id")
        if parent_id:
            matches = [candidate for candidate in node_ids if candidate.endswith(f":{parent_id}") and candidate.startswith("resource:")]
            for parent_node in matches:
                edges.append(_edge(parent_node, node_id, "parent_child_workflow", f"{_role_for_node(nodes,parent_node)}→{_role_for_resource(resource_type)}", source_status="workflow_record"))
        # Resource-level intent and observation nodes.
        for intent in payload.get("intents", []):
            sub_id = f"intent:{resource_id}:{intent.get('intent_id') or new_id('intent')}"
            nodes.append(_node(sub_id, str(intent.get("source_text") or "意图表达"), "P", source_status=str(intent.get("provenance_status") or "recorded"), kind="intent_expression"))
            node_ids.add(sub_id)
            edges.append(_edge(sub_id, node_id, "intent_activates_resource", f"P→{_role_for_resource(resource_type)}", source_status="workflow_record"))
            edges.append(_edge(sub_id, intent_id, "intent_alignment", "P→P", source_status="intent_conditioned"))
        observations = payload.get("assessments", []) or payload.get("observations", [])
        for observation in observations:
            code = observation.get("metric_code") or observation.get("code") or "observation"
            obs_id = f"observation:{resource_id}:{observation.get('assessment_id') or observation.get('observation_id') or new_id('obs')}"
            nodes.append(_node(obs_id, str(observation.get("raw_expression") or code), "D", source_status=str(observation.get("evidence_reliability") or "recorded"), kind="observation"))
            node_ids.add(obs_id)
            edges.append(_edge(obs_id, node_id, "observation_updates_resource", f"D→{_role_for_resource(resource_type)}", source_status="workflow_record"))
        device_id = payload.get("device_id") or (payload.get("session_plan") or {}).get("device_id")
        if device_id:
            device_node = f"resource:device:{device_id}"
            if device_node in node_ids:
                edges.append(_edge(device_node, node_id, "device_supports_workflow", f"K→{_role_for_resource(resource_type)}", source_status="workflow_record"))
        program_id = payload.get("program_id")
        if program_id:
            portfolio_map = {
                "R-THYROID-ORGANOID": "PORT-ORGANOID",
                "R-ISLET-ORGANOID": "PORT-ORGANOID",
                "R-AUTOLOGOUS-NEURAL-BUNDLE-BCI": "PORT-BCI",
                "R-CIRRHOSIS-AUTOLOGOUS-CELL": "PORT-LIVER-CELL",
            }
            portfolio_node = f"portfolio:{portfolio_map.get(program_id, '')}"
            if portfolio_node in node_ids:
                edges.append(_edge(portfolio_node, node_id, "portfolio_instantiated_by_protocol", "P→K", source_status="engineering_mapping"))
        if resource_type == "rehab_episode" and "portfolio:PORT-SMART-REHAB" in node_ids:
            edges.append(_edge("portfolio:PORT-SMART-REHAB", node_id, "portfolio_instantiated_by_episode", "P→P", source_status="engineering_mapping"))
        if resource_type == "technique_capture" and "portfolio:PORT-TECHNIQUE" in node_ids:
            edges.append(_edge("portfolio:PORT-TECHNIQUE", node_id, "portfolio_instantiated_by_capture", "P→D", source_status="engineering_mapping"))
        if resource_type == "eras_episode" and "portfolio:PORT-CM-ERAS" in node_ids:
            edges.append(_edge("portfolio:PORT-CM-ERAS", node_id, "portfolio_instantiated_by_episode", "P→W", source_status="engineering_mapping"))

    # Deduplicate semantic duplicate edges while keeping ids stable enough for output.
    edge_seen: set[tuple[str, str, str, str]] = set()
    deduped_edges: list[dict[str, Any]] = []
    for edge in edges:
        marker = (edge["source"], edge["target"], edge["relation"], edge["dikwp_channel"])
        if marker in edge_seen:
            continue
        edge_seen.add(marker)
        deduped_edges.append(edge)
    edges = deduped_edges

    active = _intent_active_subgraph(nodes, edges, intent_id, intent_label)
    kernel = _counterfactual_relation_kernel(active["nodes"], active["edges"], intent_id)
    channels_used = sorted({edge["dikwp_channel"] for edge in active["edges"]})
    return {
        "mesh_version": "DIKWP-Mesh-4.1",
        "analysis_intent": {"node_id": intent_id, "source_text": intent_label, "provenance_status": "explicit" if intent_text.strip() else "context_inferred"},
        "channel_catalog": list(DIKWP_CHANNELS),
        "channel_count": len(DIKWP_CHANNELS),
        "channels_activated": channels_used,
        "nodes": active["nodes"],
        "edges": active["edges"],
        "intent_conditioned_kernel": kernel,
        "residuals": active["residuals"],
        "reliability": {
            "semantic_stability": "S3" if active["nodes"] else "S0",
            "mesh_examination": "M3" if kernel["kernel_size"] else "M1",
            "evidence_reliability": "Provisional",
            "no_scalar_without_weights": True,
        },
        "definition_boundary": "DIKWP letters are runtime relation addresses; no external concept is universally defined by this graph",
        "analyzed_at": utc_now(),
    }


def _role_for_node(nodes: list[dict[str, Any]], node_id: str) -> str:
    for node in nodes:
        if node.get("node_id") == node_id:
            return str(node.get("dikwp_role") or "I")
    return "I"


def _intent_active_subgraph(nodes: list[dict[str, Any]], edges: list[dict[str, Any]], intent_id: str, intent_text: str) -> dict[str, Any]:
    adjacency: dict[str, set[str]] = defaultdict(set)
    reverse: dict[str, set[str]] = defaultdict(set)
    for edge in edges:
        adjacency[edge["source"]].add(edge["target"])
        reverse[edge["target"]].add(edge["source"])
    active_ids: set[str] = {intent_id}
    queue: deque[tuple[str, int]] = deque([(intent_id, 0)])
    while queue:
        current, depth = queue.popleft()
        if depth >= 4:
            continue
        for neighbor in reverse.get(current, set()) | adjacency.get(current, set()):
            if neighbor not in active_ids:
                active_ids.add(neighbor)
                queue.append((neighbor, depth + 1))
    normalized_intent = normalize_text(intent_text)
    if normalized_intent:
        for node in nodes:
            label = normalize_text(node.get("label"))
            if any(token and token in label for token in normalized_intent.split()):
                active_ids.add(str(node.get("node_id")))
    active_nodes = [node for node in nodes if node.get("node_id") in active_ids]
    active_edges = [edge for edge in edges if edge.get("source") in active_ids and edge.get("target") in active_ids]
    residuals = []
    isolated = [node["node_id"] for node in active_nodes if not any(edge["source"] == node["node_id"] or edge["target"] == node["node_id"] for edge in active_edges)]
    if isolated:
        residuals.append({"type": "isolated_nodes", "node_ids": isolated})
    return {"nodes": active_nodes, "edges": active_edges, "residuals": residuals}


def _reachable(edges: list[dict[str, Any]], start: str, excluded: str | None = None) -> set[str]:
    reverse: dict[str, set[str]] = defaultdict(set)
    for edge in edges:
        if edge["source"] == excluded or edge["target"] == excluded:
            continue
        reverse[edge["target"]].add(edge["source"])
    reached = {start}
    queue = deque([start])
    while queue:
        current = queue.popleft()
        for parent in reverse.get(current, set()):
            if parent not in reached:
                reached.add(parent)
                queue.append(parent)
    return reached


def _counterfactual_relation_kernel(nodes: list[dict[str, Any]], edges: list[dict[str, Any]], intent_id: str) -> dict[str, Any]:
    baseline = _reachable(edges, intent_id)
    critical: list[dict[str, Any]] = []
    for node in nodes:
        node_id = str(node.get("node_id"))
        if node_id == intent_id:
            continue
        altered = _reachable(edges, intent_id, excluded=node_id)
        lost = sorted(baseline - altered - {node_id})
        direct_intent_edge = any(edge["source"] == node_id and edge["target"] == intent_id for edge in edges)
        if lost or direct_intent_edge:
            critical.append({"node_id": node_id, "label": node.get("label"), "lost_reachable_nodes": lost, "direct_intent_relation": direct_intent_edge})
    critical_edges = []
    for edge in edges:
        without = [candidate for candidate in edges if candidate is not edge]
        if _reachable(without, intent_id) != baseline:
            critical_edges.append({key: edge[key] for key in ("edge_id", "source", "target", "relation", "dikwp_channel")})
    return {
        "method": "node_and_edge_deletion_reachability_test",
        "scope": "current_intent_current_graph",
        "critical_nodes": critical,
        "critical_edges": critical_edges,
        "kernel_size": len(critical) + len(critical_edges),
        "not_universal_essence": True,
    }
