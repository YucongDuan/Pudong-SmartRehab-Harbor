from __future__ import annotations

from typing import Any

from .catalog import eras_template_index, load_catalogs
from .domain import new_id, utc_now
from .safety import validate_eras_episode


def _template_checkpoints(template: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for phase in template.get("phases", []):
        for code in phase.get("checkpoints", []):
            result[str(code)] = {
                "phase_id": phase.get("phase_id"),
                "phase_display_name": phase.get("display_name"),
            }
    return result


def analyze_eras_episode(episode: dict[str, Any], catalogs: dict[str, Any] | None = None) -> dict[str, Any]:
    runtime = catalogs or load_catalogs()
    validate_eras_episode(episode, runtime)
    templates = eras_template_index(runtime)
    template = templates[str(episode.get("template_id"))]
    catalog = _template_checkpoints(template)
    recorded = {str(item.get("code")): item for item in episode.get("checkpoints", []) if item.get("code")}
    phases: list[dict[str, Any]] = []
    residuals: list[dict[str, Any]] = []
    for phase in template.get("phases", []):
        items: list[dict[str, Any]] = []
        for code in phase.get("checkpoints", []):
            record = recorded.get(str(code))
            complete = bool(record and record.get("status") in {"complete", "not_applicable_with_reason"})
            items.append({"code": code, "complete": complete, "record": record})
            if not complete:
                residuals.append({"type": "checkpoint_open", "phase_id": phase.get("phase_id"), "code": code})
        phases.append(
            {
                "phase_id": phase.get("phase_id"),
                "display_name": phase.get("display_name"),
                "completed": sum(1 for item in items if item["complete"]),
                "total": len(items),
                "items": items,
            }
        )
    unknown = [code for code in recorded if code not in catalog]
    for code in unknown:
        residuals.append({"type": "unknown_checkpoint", "code": code})
    total = sum(item["total"] for item in phases)
    complete = sum(item["completed"] for item in phases)
    outcomes = episode.get("outcomes") or {}
    outcome_presence = {field: outcomes.get(field) is not None for field in runtime["eras"].get("outcome_fields", [])}
    status = str(episode.get("status", "draft"))
    closure = "closed_for_tracking" if status == "completed" and complete == total else ("partial" if complete else "open")
    if residuals and status == "completed":
        closure = "contested_completed_status"
    semantic = "S4" if closure == "closed_for_tracking" else ("S3" if complete >= max(1, total // 2) else "S2")
    mesh = "M4" if closure == "closed_for_tracking" else ("M3" if complete else "M2")
    evidence = "Provisional" if episode.get("patient", {}).get("subject_kind") == "synthetic" else "Supported"
    return {
        "template": {"template_id": template.get("template_id"), "display_name": template.get("display_name"), "source_status": template.get("source_status")},
        "phase_completion": phases,
        "checkpoint_completion": {"completed": complete, "total": total, "ratio": round(complete / total, 4) if total else 0.0},
        "outcome_presence": outcome_presence,
        "residuals": residuals,
        "closure_status": closure,
        "reliability": {
            "semantic_stability": semantic,
            "mesh_examination": mesh,
            "evidence_reliability": evidence,
            "no_scalar_without_weights": True,
        },
        "clinical_order_generation": False,
        "discharge_decision_generation": False,
        "analyzed_at": utc_now(),
    }


def add_checkpoint(episode: dict[str, Any], payload: dict[str, Any], *, actor: str) -> dict[str, Any]:
    code = str(payload.get("code", "")).strip()
    phase_id = str(payload.get("phase_id", "")).strip()
    if not code or not phase_id:
        raise ValueError("checkpoint code and phase_id are required")
    status = str(payload.get("status", "complete"))
    if status not in {"complete", "open", "held", "not_applicable_with_reason"}:
        raise ValueError("invalid checkpoint status")
    if status == "not_applicable_with_reason" and not payload.get("reason"):
        raise ValueError("not_applicable_with_reason requires reason")
    checkpoint = {
        "checkpoint_id": payload.get("checkpoint_id") or new_id("checkpoint"),
        "phase_id": phase_id,
        "code": code,
        "status": status,
        "recorded_by": actor,
        "recorded_at": payload.get("recorded_at") or utc_now(),
        "source_reference": payload.get("source_reference"),
        "raw_expression": payload.get("raw_expression") or code,
        "reason": payload.get("reason"),
    }
    existing = [item for item in episode.get("checkpoints", []) if item.get("code") != code]
    episode["checkpoints"] = existing + [checkpoint]
    return checkpoint
