from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import uuid
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Sequence

DIKWP_ROLES = ("D", "I", "K", "W", "P")
DIKWP_CHANNELS = tuple(f"{a}→{b}" for a in DIKWP_ROLES for b in DIKWP_ROLES)


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def deep_copy(value: Any) -> Any:
    return copy.deepcopy(value)


def new_id(prefix: str) -> str:
    safe = re.sub(r"[^a-zA-Z0-9_-]+", "-", prefix).strip("-") or "id"
    return f"{safe}-{uuid.uuid4().hex[:12]}"


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def normalize_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().lower()


def coerce_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and value in {0, 1}:
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "y", "是", "有"}:
            return True
        if normalized in {"false", "0", "no", "n", "否", "无"}:
            return False
    return None


def finite_number(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def ensure_resource_shape(resource_type: str, payload: Mapping[str, Any]) -> dict[str, Any]:
    item = deep_copy(dict(payload))
    item["resource_type"] = resource_type
    item.setdefault("schema_version", "1.0.0")
    item.setdefault("resource_id", new_id(resource_type.replace("_", "-")))
    item.setdefault("display_name", item["resource_id"])
    item.setdefault("status", "draft")
    item.setdefault("campus_code", "guangming-xinchang")
    item.setdefault("source_status", "engineering_configuration")
    item.setdefault("definition_boundary", "source_scoped_operational_label_not_universal_definition")
    item.setdefault("human_review_required", True)
    item.setdefault("created_at", utc_now())
    item["updated_at"] = utc_now()
    item.setdefault("intents", [])
    item.setdefault("observations", [])
    item.setdefault("relations", [])
    item.setdefault("residuals", [])
    return item


def latest_by_time(items: Iterable[Mapping[str, Any]], time_key: str = "recorded_at") -> dict[str, Any] | None:
    materialized = [dict(item) for item in items]
    if not materialized:
        return None
    return max(materialized, key=lambda item: str(item.get(time_key, "")))


def index_by(items: Iterable[Mapping[str, Any]], key: str) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    for source in items:
        item = dict(source)
        value = str(item.get(key, "")).strip()
        if value:
            result.setdefault(value, []).append(item)
    return result


def linear_resample(values: Sequence[float], length: int) -> list[float]:
    if length <= 0:
        return []
    if not values:
        return [0.0] * length
    if len(values) == 1:
        return [float(values[0])] * length
    if length == 1:
        return [float(values[0])]
    result: list[float] = []
    last = len(values) - 1
    for idx in range(length):
        position = idx * last / (length - 1)
        left = int(math.floor(position))
        right = min(last, left + 1)
        fraction = position - left
        result.append(float(values[left]) * (1.0 - fraction) + float(values[right]) * fraction)
    return result


def rmse(left: Sequence[float], right: Sequence[float]) -> float:
    if not left or not right:
        return 0.0
    length = max(len(left), len(right))
    a = linear_resample([float(v) for v in left], length)
    b = linear_resample([float(v) for v in right], length)
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)) / length)


def stable_unique(values: Iterable[Any]) -> list[Any]:
    seen: set[str] = set()
    result: list[Any] = []
    for value in values:
        marker = canonical_json(value)
        if marker in seen:
            continue
        seen.add(marker)
        result.append(value)
    return result
