from __future__ import annotations

from typing import Any

from .catalog import load_catalogs, research_program_index
from .domain import new_id, utc_now
from .safety import SafetyValidationError, research_gate_analysis, validate_research_protocol

ALLOWED_TRANSITIONS: dict[str, set[str]] = {
    "concept": {"scientific_review", "held", "terminated"},
    "scientific_review": {"ethics_review", "concept", "held", "terminated"},
    "ethics_review": {"regulatory_determination", "scientific_review", "held", "terminated"},
    "regulatory_determination": {"ready_for_recruitment", "ethics_review", "held", "terminated"},
    "ready_for_recruitment": {"recruiting", "regulatory_determination", "held", "terminated"},
    "recruiting": {"active_followup", "held", "terminated"},
    "active_followup": {"analysis", "held", "terminated"},
    "analysis": {"closed", "active_followup", "held", "terminated"},
    "closed": set(),
    "held": {"concept", "scientific_review", "ethics_review", "regulatory_determination", "analysis", "terminated"},
    "terminated": set(),
}


def analyze_protocol(protocol: dict[str, Any], catalogs: dict[str, Any] | None = None) -> dict[str, Any]:
    runtime = catalogs or load_catalogs()
    programs = research_program_index(runtime)
    program_id = str(protocol.get("program_id", ""))
    if program_id not in programs:
        raise SafetyValidationError("program_id is not in research catalog")
    program = programs[program_id]
    state = str(protocol.get("status", "concept"))
    gate_analysis = research_gate_analysis(protocol, runtime)
    required_documents = set(runtime["research"].get("required_documents", []))
    documents = set(protocol.get("documents", []))
    document_status = [
        {"document": item, "present": item in documents}
        for item in sorted(required_documents)
    ]
    hgr = protocol.get("hgr") or {}
    residuals: list[dict[str, Any]] = []
    if not protocol.get("protocol_version"):
        residuals.append({"type": "missing_protocol_version"})
    if not protocol.get("principal_investigator"):
        residuals.append({"type": "missing_principal_investigator"})
    if not hgr.get("applicability"):
        residuals.append({"type": "missing_hgr_determination"})
    for gate in gate_analysis.get("missing_gates", []):
        residuals.append({"type": "missing_transition_gate", "gate": gate, "state": state})
    if protocol.get("human_recruitment") is True:
        residuals.append({"type": "real_human_recruitment_not_authorized_in_release"})
    if state in {"recruiting", "active_followup"}:
        residuals.append({"type": "state_not_runnable_for_real_human_research_in_release"})
    if state == "closed" and "final_report_recorded" not in (protocol.get("gates") or {}):
        residuals.append({"type": "closed_state_without_final_report_gate"})
    semantic = "S3" if protocol.get("hypothesis_expression") and protocol.get("protocol_version") else "S2"
    if residuals:
        mesh = "M2"
        evidence = "Blocked" if any(item["type"].startswith("state_not") or item["type"].startswith("real_human") for item in residuals) else "Provisional"
        closure = "open_or_blocked"
    else:
        mesh = "M4"
        evidence = "Provisional"
        closure = "locally_closed_for_research_governance"
    return {
        "program": program,
        "workflow_state": state,
        "allowed_next_states": sorted(ALLOWED_TRANSITIONS.get(state, set())),
        "gate_analysis": gate_analysis,
        "document_status": document_status,
        "residuals": residuals,
        "closure_status": closure,
        "reliability": {
            "semantic_stability": semantic,
            "mesh_examination": mesh,
            "evidence_reliability": evidence,
            "no_scalar_without_weights": True,
        },
        "clinical_validity_inference": False,
        "human_recruitment_authorized_by_system": False,
        "analyzed_at": utc_now(),
    }


def transition_protocol(
    protocol: dict[str, Any],
    target_state: str,
    *,
    actor: str,
    reason: str,
    catalogs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    runtime = catalogs or load_catalogs()
    current = str(protocol.get("status", "concept"))
    target = str(target_state)
    if target not in runtime["research"].get("workflow_states", []):
        raise ValueError("target_state is not in workflow catalog")
    if target in {"recruiting", "active_followup"}:
        raise SafetyValidationError("this release does not execute real human recruitment or follow-up")
    if target not in ALLOWED_TRANSITIONS.get(current, set()):
        raise ValueError(f"transition {current} -> {target} is not allowed")
    if target == "ready_for_recruitment":
        trial = dict(protocol)
        trial["status"] = target
        analysis = research_gate_analysis(trial, runtime)
        if analysis["missing_gates"]:
            raise SafetyValidationError("transition gates are incomplete", analysis)
    if target == "closed":
        required = runtime["research"].get("transition_gates", {}).get("closed", [])
        gates = protocol.get("gates") or {}
        missing = [gate for gate in required if gates.get(gate) is not True]
        if missing:
            raise SafetyValidationError("closeout gates are incomplete", {"missing_gates": missing})
    protocol["status"] = target
    protocol.setdefault("transition_history", []).append(
        {
            "transition_id": new_id("transition"),
            "from": current,
            "to": target,
            "recorded_at": utc_now(),
            "actor": actor,
            "reason": reason,
            "source_status": "workflow_record",
        }
    )
    protocol["analysis"] = analyze_protocol(protocol, runtime)
    validate_research_protocol(protocol, runtime)
    return protocol


def record_ethics_decision(
    protocol: dict[str, Any],
    payload: dict[str, Any],
    *,
    actor: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    decision = str(payload.get("decision", "pending"))
    if decision not in {"pending", "approved", "approved_with_conditions", "deferred", "rejected", "suspended"}:
        raise ValueError("invalid ethics decision")
    review = {
        "resource_type": "ethics_review",
        "resource_id": payload.get("resource_id") or new_id("ethics-review"),
        "parent_id": protocol.get("resource_id"),
        "display_name": payload.get("display_name") or f"伦理审查-{protocol.get('display_name')}",
        "campus_code": protocol.get("campus_code"),
        "status": "complete" if decision in {"approved", "approved_with_conditions", "rejected"} else "under_review",
        "source_status": "workflow_record",
        "definition_boundary": "ethics_committee_record_container_not_system_ethics_judgment",
        "human_review_required": True,
        "committee_reference": payload.get("committee_reference"),
        "submission_version": payload.get("submission_version") or protocol.get("protocol_version"),
        "decision": decision,
        "decision_date": payload.get("decision_date") or utc_now(),
        "conditions": list(payload.get("conditions", [])),
        "continuing_review_due": payload.get("continuing_review_due"),
        "recorded_by": actor,
        "synthetic_only": payload.get("synthetic_only", True),
    }
    protocol.setdefault("gates", {})["ethics_approved"] = decision in {"approved", "approved_with_conditions"}
    protocol["ethics_decision_reference"] = review["resource_id"]
    protocol["analysis"] = analyze_protocol(protocol)
    return protocol, review


def add_biospecimen(protocol: dict[str, Any], payload: dict[str, Any], *, actor: str) -> dict[str, Any]:
    specimen = {
        "resource_type": "biospecimen",
        "resource_id": payload.get("resource_id") or new_id("specimen"),
        "parent_id": protocol.get("resource_id"),
        "display_name": payload.get("display_name") or "研究样本记录",
        "campus_code": protocol.get("campus_code"),
        "status": payload.get("status") or "registered",
        "source_status": "workflow_record",
        "definition_boundary": "biospecimen_chain_of_custody_record_not_material_authorization",
        "human_review_required": True,
        "subject_kind": payload.get("subject_kind") or "synthetic",
        "specimen_type": payload.get("specimen_type"),
        "collection_time": payload.get("collection_time"),
        "storage_location": payload.get("storage_location"),
        "hgr_applicability": payload.get("hgr_applicability") or (protocol.get("hgr") or {}).get("applicability"),
        "consent_reference": payload.get("consent_reference"),
        "chain_of_custody": [
            {
                "event": "registered",
                "recorded_at": utc_now(),
                "actor": actor,
            }
        ],
        "synthetic_only": payload.get("synthetic_only", True),
    }
    if specimen["subject_kind"] != "synthetic":
        raise SafetyValidationError("this release only stores synthetic biospecimen demonstrations")
    return specimen
