from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass
from typing import Any, Iterable

from .config import demo_password, token_secret, token_ttl_seconds


class AuthenticationError(PermissionError):
    pass


class AuthorizationError(PermissionError):
    pass


@dataclass(frozen=True)
class Principal:
    username: str
    display_name: str
    role: str
    workflow_label_only: bool = True

    def as_dict(self) -> dict[str, Any]:
        return {
            "username": self.username,
            "display_name": self.display_name,
            "role": self.role,
            "workflow_label_only": self.workflow_label_only,
        }


DEMO_USERS: dict[str, Principal] = {
    "admin": Principal("admin", "演示系统管理员", "admin"),
    "leader": Principal("leader", "演示医院管理角色", "hospital_leader"),
    "rehabdoc": Principal("rehabdoc", "演示康复医师角色", "rehab_physician"),
    "tcmdoc": Principal("tcmdoc", "演示中医临床角色", "tcm_clinician"),
    "therapist": Principal("therapist", "演示康复治疗师角色", "rehab_therapist"),
    "engineer": Principal("engineer", "演示设备工程角色", "device_engineer"),
    "research": Principal("research", "演示研究负责人角色", "research_pi"),
    "ethics": Principal("ethics", "演示伦理秘书角色", "ethics_secretary"),
    "quality": Principal("quality", "演示质量管理角色", "quality_manager"),
    "data": Principal("data", "演示数据管理角色", "data_manager"),
    "patient": Principal("patient", "演示患者代理角色", "patient_proxy"),
}


ROLE_CAPABILITIES: dict[str, set[str]] = {
    "admin": {"*"},
    "hospital_leader": {
        "dashboard.read", "strategy.read", "strategy.write", "catalog.read", "resource.read",
        "portfolio.review", "audit.read", "mesh.read", "export.read",
    },
    "rehab_physician": {
        "dashboard.read", "strategy.read", "catalog.read", "resource.read", "rehab.write",
        "rehab.approve", "device_session.approve", "eras.write", "eras.approve", "referral.write",
        "audit.read", "mesh.read", "fhir.export",
    },
    "tcm_clinician": {
        "dashboard.read", "strategy.read", "catalog.read", "resource.read", "rehab.write",
        "tcm_observation.write", "technique.review", "eras.write", "eras.approve", "referral.write",
        "audit.read", "mesh.read", "fhir.export",
    },
    "rehab_therapist": {
        "dashboard.read", "strategy.read", "catalog.read", "resource.read", "rehab.write",
        "device_session.run", "technique.capture", "eras.write", "referral.write", "mesh.read",
    },
    "device_engineer": {
        "dashboard.read", "strategy.read", "catalog.read", "resource.read", "device.write",
        "device.calibrate", "device_session.run", "technique.capture", "technique.review",
        "audit.read", "mesh.read",
    },
    "research_pi": {
        "dashboard.read", "strategy.read", "catalog.read", "resource.read", "research.write",
        "research.transition", "biospecimen.write", "audit.read", "mesh.read", "fhir.export",
    },
    "ethics_secretary": {
        "dashboard.read", "strategy.read", "catalog.read", "resource.read", "ethics.write",
        "research.read_sensitive", "audit.read", "mesh.read",
    },
    "quality_manager": {
        "dashboard.read", "strategy.read", "catalog.read", "resource.read", "quality.review",
        "audit.read", "mesh.read", "export.read", "fhir.export",
    },
    "data_manager": {
        "dashboard.read", "strategy.read", "catalog.read", "resource.read", "data.write",
        "telemetry.write", "telemetry.read", "audit.read", "mesh.read", "fhir.export",
    },
    "patient_proxy": {
        "catalog.read", "resource.read_own", "rehab.checkin", "consent.write", "goal.write",
    },
}


def _b64encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _b64decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def _password_digest(password: str, username: str) -> bytes:
    salt = f"dikwp-mesh41-smart-harbor:{username}".encode("utf-8")
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 120_000)


def authenticate(username: str, password: str) -> Principal:
    principal = DEMO_USERS.get(str(username).strip())
    if principal is None:
        _password_digest(str(password), "unknown")
        raise AuthenticationError("用户名或密码错误")
    expected = _password_digest(demo_password(), principal.username)
    actual = _password_digest(str(password), principal.username)
    if not hmac.compare_digest(expected, actual):
        raise AuthenticationError("用户名或密码错误")
    return principal


def issue_token(principal: Principal) -> str:
    now = int(time.time())
    payload = {
        "sub": principal.username,
        "name": principal.display_name,
        "role": principal.role,
        "iat": now,
        "exp": now + token_ttl_seconds(),
        "jti": secrets.token_hex(8),
        "aud": "pudong-smartrehab-harbor-public-prototype",
    }
    encoded = _b64encode(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"))
    signature = _b64encode(hmac.new(token_secret().encode("utf-8"), encoded.encode("ascii"), hashlib.sha256).digest())
    return f"{encoded}.{signature}"


def verify_token(token: str) -> Principal:
    try:
        encoded, signature = token.split(".", 1)
        expected = _b64encode(hmac.new(token_secret().encode("utf-8"), encoded.encode("ascii"), hashlib.sha256).digest())
        if not hmac.compare_digest(signature, expected):
            raise AuthenticationError("令牌签名无效")
        payload = json.loads(_b64decode(encoded).decode("utf-8"))
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise AuthenticationError("令牌格式无效") from exc
    if payload.get("aud") != "pudong-smartrehab-harbor-public-prototype":
        raise AuthenticationError("令牌受众无效")
    if int(payload.get("exp", 0)) < int(time.time()):
        raise AuthenticationError("令牌已过期")
    username = str(payload.get("sub", ""))
    principal = DEMO_USERS.get(username)
    if principal is None or principal.role != payload.get("role"):
        raise AuthenticationError("令牌主体无效")
    return principal


def bearer_token(headers: Any) -> str | None:
    value = headers.get("Authorization") if headers is not None else None
    if not value or not str(value).lower().startswith("bearer "):
        return None
    return str(value)[7:].strip()


def has_capability(principal: Principal, capability: str) -> bool:
    capabilities = ROLE_CAPABILITIES.get(principal.role, set())
    return "*" in capabilities or capability in capabilities


def require_capability(principal: Principal, capability: str) -> None:
    if not has_capability(principal, capability):
        raise AuthorizationError(f"角色 {principal.role} 无权限执行 {capability}")


def require_any_capability(principal: Principal, capabilities: Iterable[str]) -> None:
    if not any(has_capability(principal, capability) for capability in capabilities):
        joined = ", ".join(capabilities)
        raise AuthorizationError(f"角色 {principal.role} 不具备任一权限：{joined}")


def require_any_role(principal: Principal, roles: Iterable[str]) -> None:
    allowed = set(roles)
    if principal.role not in allowed and principal.role != "admin":
        raise AuthorizationError(f"角色 {principal.role} 不在允许范围")
