"""DIKWP-Mesh 4.1 Pudong SmartRehab Harbor public-information customized prototype."""

__version__ = "1.0.0"
PROJECT_NAME = "DIKWP-Mesh 4.1 Pudong SmartRehab Harbor"
PROJECT_NAME_ZH = "浦东光明中医医院人形康复智慧港与中西医转化医学协同平台"
