from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping

from .catalog import adapter_index, device_type_index, eras_template_index, load_catalogs, metric_index, research_program_index
from .domain import coerce_bool, finite_number


class SafetyValidationError(ValueError):
    def __init__(self, message: str, details: Mapping[str, Any] | None = None) -> None:
        super().__init__(message)
        self.details = dict(details or {})


PROHIBITED_TRUE_KEYS = {
    "autonomous_execute",
    "autonomous_diagnosis",
    "autonomous_prescription",
    "autonomous_acupoint_selection",
    "autonomous_discharge_decision",
    "autonomous_research_eligibility_decision",
    "patient_execution_allowed",
}
PROHIBITED_PARAMETER_KEYS = {
    "needle_depth",
    "needle_angle",
    "acupoint_selection",
    "herbal_formula",
    "drug_dose",
    "dose_selection",
    "automatic_discharge",
}


def _parse_time(value: Any) -> datetime | None:
    if not value:
        return None
    raw = str(value).replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def scan_prohibited_autonomy(payload: Any, *, path: str = "$") -> list[dict[str, Any]]:
    violations: list[dict[str, Any]] = []
    if isinstance(payload, dict):
        for key, value in payload.items():
            child = f"{path}.{key}"
            if key in PROHIBITED_TRUE_KEYS and coerce_bool(value) is True:
                violations.append({"path": child, "reason": "prohibited_autonomous_or_human_execution_flag"})
            if key in PROHIBITED_PARAMETER_KEYS and value not in (None, "", [], {}):
                violations.append({"path": child, "reason": "prohibited_treatment_parameter_generation"})
            violations.extend(scan_prohibited_autonomy(value, path=child))
    elif isinstance(payload, list):
        for idx, value in enumerate(payload):
            violations.extend(scan_prohibited_autonomy(value, path=f"{path}[{idx}]"))
    return violations


def validate_common(payload: dict[str, Any]) -> None:
    violations = scan_prohibited_autonomy(payload)
    if violations:
        raise SafetyValidationError("payload violates non-autonomous clinical boundary", {"violations": violations})
    if payload.get("human_review_required") is False:
        raise SafetyValidationError("human_review_required cannot be disabled")
    if payload.get("definition_boundary") == "universal_definition":
        raise SafetyValidationError("universal_definition is outside this system boundary")


def validate_device(payload: dict[str, Any], catalogs: dict[str, Any] | None = None) -> None:
    validate_common(payload)
    runtime = catalogs or load_catalogs()
    types = device_type_index(runtime)
    adapters = adapter_index(runtime)
    device_type = str(payload.get("device_type", ""))
    adapter_id = str(payload.get("adapter_id", ""))
    if device_type not in types:
        raise SafetyValidationError("device_type is not in catalog", {"device_type": device_type})
    if adapter_id not in adapters:
        raise SafetyValidationError("adapter_id is not in catalog", {"adapter_id": adapter_id})
    if payload.get("clinical_execution_allowed") is True:
        raise SafetyValidationError("this release does not authorize clinical device execution")
    if payload.get("status") == "clinical_pilot":
        required = ["calibration", "emergency_stop_verified", "operator_roles"]
        missing = [field for field in required if not payload.get(field)]
        if missing:
            raise SafetyValidationError("clinical_pilot device record is incomplete", {"missing": missing})


def validate_rehab_episode(payload: dict[str, Any], actor_role: str, catalogs: dict[str, Any] | None = None) -> None:
    validate_common(payload)
    runtime = catalogs or load_catalogs()
    metrics = metric_index(runtime)
    patient = payload.get("patient") or {}
    if not patient.get("pseudonym"):
        raise SafetyValidationError("patient.pseudonym is required")
    subject_kind = str(patient.get("subject_kind", ""))
    if subject_kind not in runtime["governance"].get("human_subject_kinds", []):
        raise SafetyValidationError("invalid patient.subject_kind")
    for assessment in payload.get("assessments", []):
        code = str(assessment.get("metric_code", ""))
        if code not in metrics:
            raise SafetyValidationError("assessment metric is not in catalog", {"metric_code": code})
        allowed = set(metrics[code].get("observer_roles", []))
        observer = str(assessment.get("observer", actor_role))
        if actor_role == "patient_proxy":
            observer = "patient_proxy"
        if observer not in allowed and actor_role not in {"admin", "rehab_physician"}:
            raise SafetyValidationError(
                "observer role is not allowed for metric", {"metric_code": code, "observer": observer}
            )
        if metrics[code].get("value_type") == "number" and finite_number(assessment.get("value")) is None:
            raise SafetyValidationError("numeric metric requires a finite number", {"metric_code": code})
    plan = payload.get("session_plan") or {}
    if plan and plan.get("status") == "approved":
        if not plan.get("approved_by"):
            raise SafetyValidationError("approved session_plan requires approved_by")
        if plan.get("autonomous_execute") is True:
            raise SafetyValidationError("session_plan cannot enable autonomous execution")
        if not plan.get("stop_conditions"):
            raise SafetyValidationError("approved session_plan requires stop_conditions")


def validate_rehab_session(
    session: dict[str, Any],
    *,
    device: dict[str, Any] | None,
    catalogs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    validate_common(session)
    runtime = catalogs or load_catalogs()
    subject_kind = str(session.get("subject_kind", ""))
    clinical_like = subject_kind in {"patient", "healthy_volunteer", "research_participant"}
    checks: list[dict[str, Any]] = []

    def check(name: str, passed: bool, required: bool = True) -> None:
        checks.append({"check": name, "passed": bool(passed), "required": required})

    check("approved_session", bool(session.get("approved_session")), required=clinical_like)
    check("operator_present", bool(session.get("operator_present")), required=True)
    check("consent_current", bool(session.get("consent_current")), required=clinical_like)
    check("calibration_current", bool(session.get("calibration_current")), required=True)
    check("emergency_stop_verified", bool(session.get("emergency_stop_verified")), required=True)
    check("stop_conditions_recorded", bool(session.get("stop_conditions_recorded")), required=True)
    check("device_exists", device is not None, required=True)
    if device:
        check("device_not_held", device.get("status") not in {"held", "retired"}, required=True)
        check("device_clinical_flag_false", device.get("clinical_execution_allowed") is not True, required=True)
        adapter = adapter_index(runtime).get(str(device.get("adapter_id", "")), {})
        if clinical_like:
            check("adapter_clinical_execution_allowed", bool(adapter.get("clinical_execution_allowed")), required=True)
        else:
            check("simulation_or_phantom_scope", subject_kind in {"synthetic", "phantom"}, required=True)
    blocking = [item for item in checks if item["required"] and not item["passed"]]
    return {
        "gate_status": "blocked" if blocking else "open_for_simulation_only",
        "checks": checks,
        "blocking": blocking,
        "clinical_execution_authorized": False,
    }


def validate_technique_capture(payload: dict[str, Any]) -> None:
    validate_common(payload)
    subject_kind = str(payload.get("subject_kind", ""))
    if subject_kind not in {"phantom", "synthetic"}:
        raise SafetyValidationError("technique capture is limited to phantom/synthetic subjects in this release")
    if payload.get("patient_execution_allowed") is True:
        raise SafetyValidationError("patient playback is prohibited in this release")
    scopes = set(payload.get("playback_scope", []))
    if scopes - {"simulation", "phantom"}:
        raise SafetyValidationError("playback_scope can only contain simulation or phantom")
    force_limit = finite_number(payload.get("force_limit_newton"))
    if force_limit is None or force_limit <= 0:
        raise SafetyValidationError("positive force_limit_newton is required")
    practitioner = payload.get("practitioner") or {}
    if practitioner.get("consent_to_capture") is not True:
        raise SafetyValidationError("practitioner consent_to_capture is required")


def validate_eras_episode(payload: dict[str, Any], catalogs: dict[str, Any] | None = None) -> None:
    validate_common(payload)
    templates = eras_template_index(catalogs or load_catalogs())
    template_id = str(payload.get("template_id", ""))
    if template_id not in templates:
        raise SafetyValidationError("template_id is not in CM-ERAS catalog")
    if payload.get("status") in {"active", "completed"}:
        approval = payload.get("clinician_approval") or {}
        if approval.get("approved") is not True or not approval.get("approved_by"):
            raise SafetyValidationError("active/completed CM-ERAS episode requires clinician approval")
        if payload.get("autonomous_orders") is True:
            raise SafetyValidationError("CM-ERAS episode cannot create autonomous orders")
        if not payload.get("stop_conditions"):
            raise SafetyValidationError("CM-ERAS episode requires stop_conditions")


def research_gate_analysis(payload: dict[str, Any], catalogs: dict[str, Any] | None = None) -> dict[str, Any]:
    runtime = catalogs or load_catalogs()
    programs = research_program_index(runtime)
    program_id = str(payload.get("program_id", ""))
    if program_id not in programs:
        raise SafetyValidationError("program_id is not in research catalog")
    gates = payload.get("gates") or {}
    state = str(payload.get("status", "concept"))
    required = list(runtime["research"].get("transition_gates", {}).get(state, []))
    checks: list[dict[str, Any]] = []
    for gate in required:
        passed = gates.get(gate) is True or (gate in runtime["research"].get("workflow_states", []) and state == gate)
        checks.append({"gate": gate, "passed": passed})
    missing = [item["gate"] for item in checks if not item["passed"]]
    return {
        "program": programs[program_id],
        "state": state,
        "required_gates": checks,
        "missing_gates": missing,
        "ready": not missing,
        "human_recruitment_authorized_by_system": False,
    }


def validate_research_protocol(payload: dict[str, Any], catalogs: dict[str, Any] | None = None) -> None:
    validate_common(payload)
    runtime = catalogs or load_catalogs()
    analysis = research_gate_analysis(payload, runtime)
    state = str(payload.get("status", "concept"))
    if state in {"ready_for_recruitment", "recruiting", "active_followup"} and analysis["missing_gates"]:
        raise SafetyValidationError("research protocol transition gates are incomplete", analysis)
    if payload.get("human_recruitment") is True and state not in {"recruiting", "active_followup"}:
        raise SafetyValidationError("human_recruitment can only be true in recruiting/active_followup")
    if payload.get("human_recruitment") is True:
        # This runnable release is not a production recruitment system.
        raise SafetyValidationError("this release does not authorize real human recruitment")
    hgr = payload.get("hgr") or {}
    if not hgr.get("applicability"):
        raise SafetyValidationError("hgr.applicability determination is required")


def calibration_is_current(device: dict[str, Any], *, now: datetime | None = None) -> bool:
    calibration = device.get("calibration") or {}
    if calibration.get("result") != "pass":
        return False
    expires = _parse_time(calibration.get("expires_at"))
    if not expires:
        return False
    current = now or datetime.now(timezone.utc)
    return expires >= current
