from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from .config import db_path
from .domain import canonical_json, ensure_resource_shape, new_id, sha256_json, utc_now


class RevisionConflict(RuntimeError):
    pass


class ResourceNotFound(KeyError):
    pass


class SmartHarborStore:
    """SQLite JSON-resource store with optimistic revisions, telemetry, and an audit hash chain."""

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path else db_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.initialize()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=20, isolation_level=None, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        try:
            yield conn
        finally:
            conn.close()

    def initialize(self) -> None:
        with self._lock, self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS resources (
                    resource_type TEXT NOT NULL,
                    resource_id TEXT NOT NULL,
                    parent_id TEXT,
                    campus_code TEXT NOT NULL,
                    display_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    source_status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    payload_sha256 TEXT NOT NULL,
                    revision INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(resource_type, resource_id)
                );
                CREATE INDEX IF NOT EXISTS idx_resources_type_updated
                    ON resources(resource_type, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_resources_parent
                    ON resources(parent_id, resource_type, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_resources_status
                    ON resources(resource_type, status, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_resources_campus
                    ON resources(campus_code, resource_type, updated_at DESC);

                CREATE TABLE IF NOT EXISTS telemetry_samples (
                    session_id TEXT NOT NULL,
                    sequence INTEGER NOT NULL,
                    recorded_at TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    numeric_value REAL,
                    text_value TEXT,
                    unit TEXT,
                    payload_json TEXT NOT NULL,
                    PRIMARY KEY(session_id, sequence, channel)
                );
                CREATE INDEX IF NOT EXISTS idx_telemetry_session
                    ON telemetry_samples(session_id, sequence, channel);

                CREATE TABLE IF NOT EXISTS audit_events (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL UNIQUE,
                    resource_type TEXT,
                    resource_id TEXT,
                    recorded_at TEXT NOT NULL,
                    actor TEXT NOT NULL,
                    actor_role TEXT NOT NULL,
                    action TEXT NOT NULL,
                    detail_json TEXT NOT NULL,
                    previous_hash TEXT,
                    event_hash TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_audit_resource
                    ON audit_events(resource_type, resource_id, sequence);
                CREATE INDEX IF NOT EXISTS idx_audit_action
                    ON audit_events(action, sequence);
                """
            )

    def save_resource(
        self,
        resource_type: str,
        payload: dict[str, Any],
        *,
        actor: str,
        actor_role: str,
        action: str = "resource.save",
        expected_revision: int | None = None,
        audit_detail: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        item = ensure_resource_shape(resource_type, payload)
        resource_id = str(item["resource_id"])
        now = utc_now()
        item["updated_at"] = now
        campus_code = str(item.get("campus_code") or "unknown")
        display_name = str(item.get("display_name") or resource_id)
        status = str(item.get("status") or "draft")
        source_status = str(item.get("source_status") or "engineering_configuration")
        parent_id = item.get("parent_id")
        payload_json = canonical_json(item)
        digest = sha256_json(item)

        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT revision, created_at FROM resources WHERE resource_type=? AND resource_id=?",
                (resource_type, resource_id),
            ).fetchone()
            if row:
                current_revision = int(row["revision"])
                if expected_revision is not None and int(expected_revision) != current_revision:
                    conn.execute("ROLLBACK")
                    raise RevisionConflict(
                        f"{resource_type}/{resource_id} revision is {current_revision}, expected {expected_revision}"
                    )
                revision = current_revision + 1
                created_at = str(row["created_at"])
                item["created_at"] = created_at
                item["updated_at"] = now
                payload_json = canonical_json(item)
                digest = sha256_json(item)
                conn.execute(
                    """UPDATE resources
                       SET parent_id=?, campus_code=?, display_name=?, status=?, source_status=?,
                           payload_json=?, payload_sha256=?, revision=?, updated_at=?
                       WHERE resource_type=? AND resource_id=?""",
                    (
                        parent_id, campus_code, display_name, status, source_status,
                        payload_json, digest, revision, now, resource_type, resource_id,
                    ),
                )
            else:
                if expected_revision not in (None, 0):
                    conn.execute("ROLLBACK")
                    raise RevisionConflict(f"{resource_type}/{resource_id} does not exist")
                revision = 1
                created_at = str(item.get("created_at") or now)
                item["created_at"] = created_at
                item["updated_at"] = now
                payload_json = canonical_json(item)
                digest = sha256_json(item)
                conn.execute(
                    """INSERT INTO resources(
                           resource_type,resource_id,parent_id,campus_code,display_name,status,source_status,
                           payload_json,payload_sha256,revision,created_at,updated_at
                       ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        resource_type, resource_id, parent_id, campus_code, display_name, status,
                        source_status, payload_json, digest, revision, created_at, now,
                    ),
                )
            detail = {
                "resource_type": resource_type,
                "resource_id": resource_id,
                "revision": revision,
                "payload_sha256": digest,
                "status": status,
                "campus_code": campus_code,
                **(audit_detail or {}),
            }
            self._append_audit_in_transaction(
                conn,
                resource_type=resource_type,
                resource_id=resource_id,
                actor=actor,
                actor_role=actor_role,
                action=action,
                detail=detail,
            )
            conn.execute("COMMIT")
        return {
            "resource": item,
            "revision": revision,
            "payload_sha256": digest,
            "created_at": created_at,
            "updated_at": now,
        }

    def get_resource(self, resource_type: str, resource_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM resources WHERE resource_type=? AND resource_id=?",
                (resource_type, resource_id),
            ).fetchone()
        if row is None:
            raise ResourceNotFound(f"{resource_type}/{resource_id}")
        return self._row_to_record(row)

    def list_resources(
        self,
        *,
        resource_type: str | None = None,
        parent_id: str | None = None,
        campus_code: str | None = None,
        status: str | None = None,
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 5000))
        clauses: list[str] = []
        params: list[Any] = []
        if resource_type:
            clauses.append("resource_type=?")
            params.append(resource_type)
        if parent_id:
            clauses.append("parent_id=?")
            params.append(parent_id)
        if campus_code:
            clauses.append("campus_code=?")
            params.append(campus_code)
        if status:
            clauses.append("status=?")
            params.append(status)
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = (
            "SELECT resource_type,resource_id,parent_id,campus_code,display_name,status,source_status,"
            "payload_sha256,revision,created_at,updated_at FROM resources"
            + where
            + " ORDER BY updated_at DESC LIMIT ?"
        )
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(row) for row in rows]

    def list_resource_payloads(
        self,
        *,
        resource_type: str | None = None,
        parent_id: str | None = None,
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if resource_type:
            clauses.append("resource_type=?")
            params.append(resource_type)
        if parent_id:
            clauses.append("parent_id=?")
            params.append(parent_id)
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(max(1, min(int(limit), 5000)))
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM resources" + where + " ORDER BY updated_at DESC LIMIT ?", params
            ).fetchall()
        return [self._row_to_record(row) for row in rows]

    def delete_resource(
        self,
        resource_type: str,
        resource_id: str,
        *,
        actor: str,
        actor_role: str,
        reason: str,
    ) -> bool:
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT resource_id FROM resources WHERE resource_type=? AND resource_id=?",
                (resource_type, resource_id),
            ).fetchone()
            if not row:
                conn.execute("ROLLBACK")
                return False
            self._append_audit_in_transaction(
                conn,
                resource_type=resource_type,
                resource_id=resource_id,
                actor=actor,
                actor_role=actor_role,
                action="resource.delete",
                detail={"reason": reason},
            )
            conn.execute(
                "DELETE FROM resources WHERE resource_type=? AND resource_id=?",
                (resource_type, resource_id),
            )
            conn.execute("DELETE FROM telemetry_samples WHERE session_id=?", (resource_id,))
            conn.execute("COMMIT")
            return True

    def count_resources(self) -> dict[str, int]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT resource_type, COUNT(*) AS count FROM resources GROUP BY resource_type ORDER BY resource_type"
            ).fetchall()
        return {str(row["resource_type"]): int(row["count"]) for row in rows}

    def add_telemetry(
        self,
        session_id: str,
        samples: list[dict[str, Any]],
        *,
        actor: str,
        actor_role: str,
        replace: bool = True,
    ) -> dict[str, Any]:
        normalized: list[dict[str, Any]] = []
        for sample in samples:
            sequence = int(sample.get("sequence", len(normalized)))
            recorded_at = str(sample.get("recorded_at") or utc_now())
            channel = str(sample.get("channel", "value"))
            numeric_value = sample.get("numeric_value")
            text_value = sample.get("text_value")
            unit = sample.get("unit")
            normalized.append(
                {
                    "session_id": session_id,
                    "sequence": sequence,
                    "recorded_at": recorded_at,
                    "channel": channel,
                    "numeric_value": numeric_value,
                    "text_value": text_value,
                    "unit": unit,
                    "metadata": sample.get("metadata", {}),
                }
            )
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            if replace:
                conn.execute("DELETE FROM telemetry_samples WHERE session_id=?", (session_id,))
            for item in normalized:
                conn.execute(
                    """INSERT OR REPLACE INTO telemetry_samples(
                           session_id,sequence,recorded_at,channel,numeric_value,text_value,unit,payload_json
                       ) VALUES(?,?,?,?,?,?,?,?)""",
                    (
                        session_id, item["sequence"], item["recorded_at"], item["channel"],
                        item["numeric_value"], item["text_value"], item["unit"], canonical_json(item),
                    ),
                )
            self._append_audit_in_transaction(
                conn,
                resource_type="telemetry_session",
                resource_id=session_id,
                actor=actor,
                actor_role=actor_role,
                action="telemetry.replace" if replace else "telemetry.append",
                detail={"sample_count": len(normalized), "replace": replace},
            )
            conn.execute("COMMIT")
        return {"session_id": session_id, "sample_count": len(normalized)}

    def list_telemetry(self, session_id: str, *, limit: int = 10000) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT payload_json FROM telemetry_samples
                   WHERE session_id=? ORDER BY sequence, channel LIMIT ?""",
                (session_id, max(1, min(int(limit), 100000))),
            ).fetchall()
        return [json.loads(row["payload_json"]) for row in rows]

    def append_audit(
        self,
        *,
        resource_type: str | None,
        resource_id: str | None,
        actor: str,
        actor_role: str,
        action: str,
        detail: dict[str, Any],
    ) -> dict[str, Any]:
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            event = self._append_audit_in_transaction(
                conn,
                resource_type=resource_type,
                resource_id=resource_id,
                actor=actor,
                actor_role=actor_role,
                action=action,
                detail=detail,
            )
            conn.execute("COMMIT")
            return event

    def _append_audit_in_transaction(
        self,
        conn: sqlite3.Connection,
        *,
        resource_type: str | None,
        resource_id: str | None,
        actor: str,
        actor_role: str,
        action: str,
        detail: dict[str, Any],
    ) -> dict[str, Any]:
        previous = conn.execute("SELECT event_hash FROM audit_events ORDER BY sequence DESC LIMIT 1").fetchone()
        previous_hash = str(previous["event_hash"]) if previous else None
        event = {
            "event_id": new_id("audit"),
            "resource_type": resource_type,
            "resource_id": resource_id,
            "recorded_at": utc_now(),
            "actor": actor,
            "actor_role": actor_role,
            "action": action,
            "detail": detail,
            "previous_hash": previous_hash,
        }
        event_hash = sha256_json(event)
        event["event_hash"] = event_hash
        conn.execute(
            """INSERT INTO audit_events(
                   event_id,resource_type,resource_id,recorded_at,actor,actor_role,action,
                   detail_json,previous_hash,event_hash
               ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (
                event["event_id"], resource_type, resource_id, event["recorded_at"], actor,
                actor_role, action, canonical_json(detail), previous_hash, event_hash,
            ),
        )
        return event

    def list_audit(
        self,
        *,
        resource_type: str | None = None,
        resource_id: str | None = None,
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if resource_type:
            clauses.append("resource_type=?")
            params.append(resource_type)
        if resource_id:
            clauses.append("resource_id=?")
            params.append(resource_id)
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(max(1, min(int(limit), 5000)))
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM audit_events" + where + " ORDER BY sequence DESC LIMIT ?", params
            ).fetchall()
        result: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["detail"] = json.loads(item.pop("detail_json"))
            result.append(item)
        return result

    def verify_audit_chain(self) -> dict[str, Any]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM audit_events ORDER BY sequence").fetchall()
        previous_hash: str | None = None
        for row in rows:
            detail = json.loads(row["detail_json"])
            event = {
                "event_id": row["event_id"],
                "resource_type": row["resource_type"],
                "resource_id": row["resource_id"],
                "recorded_at": row["recorded_at"],
                "actor": row["actor"],
                "actor_role": row["actor_role"],
                "action": row["action"],
                "detail": detail,
                "previous_hash": row["previous_hash"],
            }
            expected = sha256_json(event)
            if row["previous_hash"] != previous_hash:
                return {
                    "valid": False,
                    "event_count": len(rows),
                    "failed_sequence": int(row["sequence"]),
                    "reason": "previous_hash_mismatch",
                }
            if row["event_hash"] != expected:
                return {
                    "valid": False,
                    "event_count": len(rows),
                    "failed_sequence": int(row["sequence"]),
                    "reason": "event_hash_mismatch",
                }
            previous_hash = str(row["event_hash"])
        return {"valid": True, "event_count": len(rows), "last_hash": previous_hash}

    @staticmethod
    def _row_to_record(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "resource": json.loads(row["payload_json"]),
            "revision": int(row["revision"]),
            "payload_sha256": row["payload_sha256"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }
