from __future__ import annotations

import math
import random
from typing import Any

from .domain import rmse, utc_now
from .safety import validate_technique_capture


def _series(samples: list[dict[str, Any]], channel: str) -> list[float]:
    return [float(item["numeric_value"]) for item in samples if item.get("channel") == channel and item.get("numeric_value") is not None]


def _metrics(samples: list[dict[str, Any]]) -> dict[str, Any]:
    force = _series(samples, "force_z")
    x = _series(samples, "position_x")
    y = _series(samples, "position_y")
    velocity = _series(samples, "velocity")
    if not force:
        return {"sample_frames": 0, "synthetic_only": True}
    path = 0.0
    for idx in range(1, min(len(x), len(y))):
        path += math.hypot(x[idx] - x[idx - 1], y[idx] - y[idx - 1])
    jerk = 0.0
    if len(velocity) >= 3:
        acceleration = [velocity[i] - velocity[i - 1] for i in range(1, len(velocity))]
        jerk_values = [acceleration[i] - acceleration[i - 1] for i in range(1, len(acceleration))]
        jerk = sum(abs(value) for value in jerk_values) / len(jerk_values) if jerk_values else 0.0
    return {
        "sample_frames": len(force),
        "mean_force_n": round(sum(force) / len(force), 6),
        "peak_force_n": round(max(force), 6),
        "force_variability_n": round(math.sqrt(sum((value - sum(force) / len(force)) ** 2 for value in force) / len(force)), 6),
        "path_length_mm": round(path, 6),
        "mean_speed_proxy": round(sum(abs(value) for value in velocity) / len(velocity), 6) if velocity else 0.0,
        "mean_abs_jerk_proxy": round(jerk, 6),
        "synthetic_only": True,
        "clinical_interpretation": False,
    }


def simulate_capture(capture: dict[str, Any], *, sample_count: int = 160) -> dict[str, Any]:
    validate_technique_capture(capture)
    sample_count = max(40, min(int(sample_count), 2000))
    seed = int(capture.get("capture_seed", 17))
    rng = random.Random(seed)
    duration_seconds = float(capture.get("duration_seconds", 32.0))
    force_limit = float(capture.get("force_limit_newton", 45.0))
    samples: list[dict[str, Any]] = []
    last_x = 0.0
    last_y = 0.0
    for idx in range(sample_count):
        phase = idx / max(1, sample_count - 1)
        t = phase * duration_seconds
        x = 32.0 * math.sin(phase * math.pi * 4) + 5.0 * math.sin(phase * math.pi * 10) + rng.uniform(-0.8, 0.8)
        y = 18.0 * math.cos(phase * math.pi * 4) + 2.5 * math.sin(phase * math.pi * 8) + rng.uniform(-0.6, 0.6)
        envelope = 0.3 + 0.7 * (math.sin(phase * math.pi) ** 0.7)
        force = min(force_limit * 0.88, max(0.0, force_limit * 0.46 * envelope + 5.5 * math.sin(phase * math.pi * 8) + rng.uniform(-1.2, 1.2)))
        velocity = math.hypot(x - last_x, y - last_y) / max(duration_seconds / sample_count, 1e-6)
        last_x, last_y = x, y
        recorded_at = f"T+{t:.3f}s"
        for channel, value, unit in [
            ("position_x", x, "mm"),
            ("position_y", y, "mm"),
            ("force_z", force, "N"),
            ("velocity", velocity, "mm/s"),
        ]:
            samples.append(
                {
                    "sequence": idx,
                    "recorded_at": recorded_at,
                    "channel": channel,
                    "numeric_value": round(value, 6),
                    "unit": unit,
                    "metadata": {"subject_kind": capture.get("subject_kind"), "synthetic": True},
                }
            )
    metrics = _metrics(samples)
    metrics["force_limit_n"] = force_limit
    metrics["force_limit_respected"] = metrics.get("peak_force_n", 0) <= force_limit
    return {
        "samples": samples,
        "metrics": metrics,
        "gate": {
            "status": "open_for_phantom_or_simulation_capture",
            "human_playback_authorized": False,
            "patient_execution_allowed": False,
        },
        "captured_at": utc_now(),
    }


def compare_captures(
    left_samples: list[dict[str, Any]],
    right_samples: list[dict[str, Any]],
) -> dict[str, Any]:
    channels = ["force_z", "position_x", "position_y", "velocity"]
    channel_comparison: list[dict[str, Any]] = []
    for channel in channels:
        left = _series(left_samples, channel)
        right = _series(right_samples, channel)
        channel_comparison.append(
            {
                "channel": channel,
                "left_samples": len(left),
                "right_samples": len(right),
                "resampled_rmse": round(rmse(left, right), 6) if left and right else None,
            }
        )
    force_errors = [item["resampled_rmse"] for item in channel_comparison if item["channel"] == "force_z" and item["resampled_rmse"] is not None]
    return {
        "method": "linear_resampling_plus_rmse",
        "channel_comparison": channel_comparison,
        "force_trace_difference": force_errors[0] if force_errors else None,
        "interpretation_boundary": "engineering_similarity_signal_not_clinical_or_mastery_score",
        "no_scalar_mastery_score": True,
    }


def merge_capture_result(capture: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
    capture["metrics"] = result.get("metrics", {})
    capture["capture_gate"] = result.get("gate", {})
    capture["captured_at"] = result.get("captured_at")
    capture["status"] = "captured"
    capture["updated_at"] = utc_now()
    return capture
