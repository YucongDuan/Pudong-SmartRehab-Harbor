from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

from .config import (
    DEVICE_PATH,
    ERAS_PATH,
    GOVERNANCE_PATH,
    REHAB_PATH,
    RESEARCH_PATH,
    SOURCE_PATH,
    STRATEGY_PATH,
)
from .domain import DIKWP_CHANNELS


def _load(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return data


@lru_cache(maxsize=1)
def load_catalogs() -> dict[str, Any]:
    catalogs = {
        "strategy": _load(STRATEGY_PATH),
        "rehab": _load(REHAB_PATH),
        "devices": _load(DEVICE_PATH),
        "eras": _load(ERAS_PATH),
        "research": _load(RESEARCH_PATH),
        "governance": _load(GOVERNANCE_PATH),
        "sources": _load(SOURCE_PATH),
    }
    channels = tuple(catalogs["governance"].get("dikwp_channels", []))
    if channels != DIKWP_CHANNELS:
        raise ValueError("governance catalog must contain the ordered 25 DIKWP channels")
    return catalogs


def metric_index(catalogs: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    runtime = catalogs or load_catalogs()
    return {item["code"]: item for item in runtime["rehab"].get("metric_catalog", [])}


def axis_index(catalogs: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    runtime = catalogs or load_catalogs()
    return {item["axis_id"]: item for item in runtime["rehab"].get("axes", [])}


def device_type_index(catalogs: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    runtime = catalogs or load_catalogs()
    return {item["device_type"]: item for item in runtime["devices"].get("device_types", [])}


def adapter_index(catalogs: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    runtime = catalogs or load_catalogs()
    return {item["adapter_id"]: item for item in runtime["devices"].get("adapters", [])}


def eras_template_index(catalogs: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    runtime = catalogs or load_catalogs()
    return {item["template_id"]: item for item in runtime["eras"].get("templates", [])}


def research_program_index(catalogs: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    runtime = catalogs or load_catalogs()
    return {item["program_id"]: item for item in runtime["research"].get("programs", [])}


def campus_index(catalogs: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    runtime = catalogs or load_catalogs()
    return {item["campus_id"]: item for item in runtime["strategy"].get("campuses", [])}


def source_index(catalogs: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    runtime = catalogs or load_catalogs()
    return {item["source_id"]: item for item in runtime["sources"].get("sources", [])}


def catalog_summary(catalogs: dict[str, Any] | None = None) -> dict[str, Any]:
    runtime = catalogs or load_catalogs()
    return {
        "campuses": len(runtime["strategy"].get("campuses", [])),
        "portfolios": len(runtime["strategy"].get("portfolios", [])),
        "rehab_axes": len(runtime["rehab"].get("axes", [])),
        "rehab_metrics": len(runtime["rehab"].get("metric_catalog", [])),
        "rehab_modalities": len(runtime["rehab"].get("modalities", [])),
        "device_types": len(runtime["devices"].get("device_types", [])),
        "device_adapters": len(runtime["devices"].get("adapters", [])),
        "eras_templates": len(runtime["eras"].get("templates", [])),
        "research_programs": len(runtime["research"].get("programs", [])),
        "source_records": len(runtime["sources"].get("sources", [])),
        "dikwp_channels": len(runtime["governance"].get("dikwp_channels", [])),
    }
