from __future__ import annotations

import math
import random
from collections import defaultdict
from typing import Any

from .catalog import axis_index, load_catalogs, metric_index
from .domain import finite_number, new_id, stable_unique, utc_now
from .safety import validate_rehab_episode, validate_rehab_session


def _assessment_index(episode: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in episode.get("assessments", []):
        code = str(item.get("metric_code", ""))
        if code:
            result[code].append(dict(item))
    for values in result.values():
        values.sort(key=lambda item: str(item.get("recorded_at", "")))
    return dict(result)


def _trend(values: list[dict[str, Any]]) -> dict[str, Any]:
    numeric = [(item, finite_number(item.get("value"))) for item in values]
    numeric = [(item, value) for item, value in numeric if value is not None]
    if not numeric:
        latest = values[-1] if values else None
        return {"sample_count": len(values), "latest": latest, "numeric_change": None, "direction": "not_numeric"}
    first_item, first = numeric[0]
    latest_item, latest = numeric[-1]
    change = float(latest) - float(first)
    direction = "stable" if abs(change) < 1e-9 else ("increased" if change > 0 else "decreased")
    return {
        "sample_count": len(values),
        "first": {"value": first, "recorded_at": first_item.get("recorded_at")},
        "latest": {"value": latest, "recorded_at": latest_item.get("recorded_at")},
        "numeric_change": round(change, 6),
        "direction": direction,
    }


def _core_analysis(episode: dict[str, Any], catalogs: dict[str, Any]) -> dict[str, Any]:
    axes = axis_index(catalogs)
    metrics = metric_index(catalogs)
    assessments = list(episode.get("assessments", []))
    by_axis: dict[str, list[dict[str, Any]]] = {axis_id: [] for axis_id in axes}
    residuals: list[dict[str, Any]] = []
    for item in assessments:
        code = str(item.get("metric_code", ""))
        definition = metrics.get(code)
        if not definition:
            residuals.append({"type": "unknown_metric", "metric_code": code})
            continue
        expected_axis = str(definition.get("axis_id"))
        actual_axis = str(item.get("axis_id") or expected_axis)
        if actual_axis != expected_axis:
            residuals.append(
                {"type": "axis_mismatch", "metric_code": code, "expected_axis": expected_axis, "actual_axis": actual_axis}
            )
        by_axis.setdefault(expected_axis, []).append(item)
        if definition.get("unit") and item.get("unit") != definition.get("unit"):
            residuals.append(
                {
                    "type": "unit_mismatch",
                    "metric_code": code,
                    "expected_unit": definition.get("unit"),
                    "actual_unit": item.get("unit"),
                }
            )
        if not item.get("raw_expression"):
            residuals.append({"type": "missing_raw_expression", "metric_code": code})
        if not item.get("observer"):
            residuals.append({"type": "missing_observer", "metric_code": code})
        if not item.get("recorded_at"):
            residuals.append({"type": "missing_time", "metric_code": code})

    axis_coverage = []
    for axis_id, axis in axes.items():
        values = by_axis.get(axis_id, [])
        axis_coverage.append(
            {
                "axis_id": axis_id,
                "display_name": axis.get("display_name"),
                "observation_count": len(values),
                "covered": bool(values),
                "source_id": axis.get("source_id"),
            }
        )

    intents = episode.get("intents", [])
    explicit_intents = [item for item in intents if item.get("provenance_status") in {"explicit", "user_stipulated"}]
    goals = episode.get("goals", [])
    goal_analysis: list[dict[str, Any]] = []
    metric_idx = _assessment_index(episode)
    for goal in goals:
        linked_metrics = list(goal.get("metrics", []))
        goal_analysis.append(
            {
                "goal_id": goal.get("goal_id"),
                "display_name": goal.get("display_name"),
                "status": goal.get("status"),
                "source_intent_id": goal.get("source_intent_id"),
                "metric_coverage": [
                    {"metric_code": code, "present": bool(metric_idx.get(code)), "trend": _trend(metric_idx.get(code, []))}
                    for code in linked_metrics
                ],
            }
        )

    safety_residuals = []
    plan = episode.get("session_plan") or {}
    if plan:
        if plan.get("status") == "approved" and not plan.get("approved_by"):
            safety_residuals.append("approved_plan_missing_approver")
        if not plan.get("stop_conditions"):
            safety_residuals.append("missing_stop_conditions")
        if plan.get("autonomous_execute") is True:
            safety_residuals.append("autonomous_execution_prohibited")
    else:
        safety_residuals.append("session_plan_absent")
    consent = episode.get("consent") or {}
    patient = episode.get("patient") or {}
    subject_kind = patient.get("subject_kind")
    if subject_kind in {"patient", "healthy_volunteer", "research_participant"} and not consent.get("care_workflow"):
        safety_residuals.append("care_consent_missing")
    if plan.get("device_id") and subject_kind in {"patient", "healthy_volunteer", "research_participant"} and not consent.get("device_session"):
        safety_residuals.append("device_session_consent_missing")

    active_questions: list[dict[str, Any]] = []
    if not explicit_intents:
        active_questions.append(
            {"question_id": "Q-INTENT", "priority": 1, "target": "intent", "text": "当前康复目标的患者原始表达是什么？", "dikwp_channel": "P→D"}
        )
    for item in axis_coverage:
        if not item["covered"]:
            active_questions.append(
                {
                    "question_id": f"Q-{item['axis_id']}",
                    "priority": 2,
                    "target": item["axis_id"],
                    "text": f"{item['display_name']}轴尚无来源明确的记录，当前可获得的观察是什么？",
                    "dikwp_channel": "P→D",
                }
            )
    for residual in safety_residuals:
        active_questions.append(
            {
                "question_id": f"Q-SAFE-{residual}",
                "priority": 0,
                "target": "safety",
                "text": f"安全门控残差需要人工记录：{residual}",
                "dikwp_channel": "W→D",
            }
        )

    covered = sum(1 for item in axis_coverage if item["covered"])
    if safety_residuals:
        semantic = "S1" if explicit_intents else "S0"
        mesh = "M1"
        evidence = "Blocked"
        closure = "blocked"
    elif covered == len(axis_coverage) and explicit_intents and goals:
        semantic = "S4"
        mesh = "M4"
        evidence = "Supported" if subject_kind != "synthetic" else "Provisional"
        closure = "locally_closed_for_tracking"
    elif covered >= 4 and explicit_intents:
        semantic = "S3"
        mesh = "M3"
        evidence = "Provisional"
        closure = "partial"
    else:
        semantic = "S2" if explicit_intents else "S1"
        mesh = "M2" if covered >= 2 else "M1"
        evidence = "Provisional"
        closure = "open"

    return {
        "intent_summary": {
            "explicit_or_stipulated_count": len(explicit_intents),
            "all_intents": intents,
        },
        "axis_coverage": axis_coverage,
        "goal_analysis": goal_analysis,
        "metric_trends": {code: _trend(values) for code, values in metric_idx.items()},
        "safety_gate": {
            "gate_status": "blocked" if safety_residuals else "open_for_human_reviewed_workflow",
            "residuals": safety_residuals,
            "autonomous_execution_authorized": False,
        },
        "active_questions": active_questions,
        "residuals": residuals,
        "closure_status": closure,
        "reliability": {
            "semantic_stability": semantic,
            "mesh_examination": mesh,
            "evidence_reliability": evidence,
            "no_scalar_without_weights": True,
        },
    }


def _signature(core: dict[str, Any]) -> tuple[Any, ...]:
    return (
        core.get("closure_status"),
        core.get("safety_gate", {}).get("gate_status"),
        tuple((item.get("axis_id"), item.get("covered")) for item in core.get("axis_coverage", [])),
        tuple(sorted(item.get("question_id") for item in core.get("active_questions", []))),
        tuple(
            (goal.get("goal_id"), tuple((m.get("metric_code"), m.get("present")) for m in goal.get("metric_coverage", [])))
            for goal in core.get("goal_analysis", [])
        ),
    )


def _counterfactual_kernel(episode: dict[str, Any], catalogs: dict[str, Any], base: dict[str, Any]) -> dict[str, Any]:
    baseline = _signature(base)
    critical_nodes: list[dict[str, Any]] = []
    candidates: list[tuple[str, int, dict[str, Any]]] = []
    for idx, item in enumerate(episode.get("intents", [])):
        candidates.append(("intents", idx, item))
    for idx, item in enumerate(episode.get("assessments", [])):
        candidates.append(("assessments", idx, item))
    for idx, item in enumerate(episode.get("goals", [])):
        candidates.append(("goals", idx, item))
    for collection, idx, item in candidates:
        altered = {key: value for key, value in episode.items()}
        altered[collection] = [value for pos, value in enumerate(episode.get(collection, [])) if pos != idx]
        altered_core = _core_analysis(altered, catalogs)
        changed = _signature(altered_core) != baseline
        if changed:
            node_id = item.get("intent_id") or item.get("assessment_id") or item.get("goal_id") or f"{collection}-{idx}"
            critical_nodes.append(
                {
                    "node_id": node_id,
                    "collection": collection,
                    "counterfactual_effect": "closure_signature_changed",
                    "source_status": item.get("provenance_status") or item.get("source_status") or "recorded",
                }
            )
    return {
        "method": "single_node_deletion_and_reanalysis",
        "scope": "current_episode_current_intent_current_catalog",
        "critical_nodes": critical_nodes,
        "kernel_size": len(critical_nodes),
        "not_universal_essence": True,
    }


def analyze_rehab_episode(episode: dict[str, Any], catalogs: dict[str, Any] | None = None) -> dict[str, Any]:
    runtime = catalogs or load_catalogs()
    validate_rehab_episode(episode, actor_role="rehab_physician", catalogs=runtime)
    core = _core_analysis(episode, runtime)
    core["intent_conditioned_kernel"] = _counterfactual_kernel(episode, runtime, core)
    core["analyzed_at"] = utc_now()
    core["analysis_scope"] = "source_scoped_operational_closure_not_clinical_diagnosis"
    return core


def add_assessment(
    episode: dict[str, Any],
    payload: dict[str, Any],
    *,
    actor_role: str,
    catalogs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    runtime = catalogs or load_catalogs()
    metrics = metric_index(runtime)
    code = str(payload.get("metric_code", ""))
    if code not in metrics:
        raise ValueError("metric_code is not in catalog")
    definition = metrics[code]
    observer = "patient_proxy" if actor_role == "patient_proxy" else str(payload.get("observer") or actor_role)
    item = {
        "assessment_id": payload.get("assessment_id") or new_id("assessment"),
        "axis_id": payload.get("axis_id") or definition.get("axis_id"),
        "metric_code": code,
        "value": payload.get("value"),
        "unit": payload.get("unit") if "unit" in payload else definition.get("unit"),
        "observer": observer,
        "recorded_at": payload.get("recorded_at") or utc_now(),
        "raw_expression": payload.get("raw_expression") or f"{code}={payload.get('value')}",
        "source_type": payload.get("source_type") or ("patient_report" if actor_role == "patient_proxy" else "workflow_entry"),
        "evidence_reliability": payload.get("evidence_reliability") or ("Provisional" if actor_role == "patient_proxy" else "Supported"),
    }
    episode.setdefault("assessments", []).append(item)
    validate_rehab_episode(episode, actor_role=actor_role, catalogs=runtime)
    episode["analysis"] = analyze_rehab_episode(episode, runtime)
    return item


def add_goal(episode: dict[str, Any], payload: dict[str, Any], *, actor_role: str) -> dict[str, Any]:
    display_name = str(payload.get("display_name", "")).strip()
    if not display_name:
        raise ValueError("goal.display_name is required")
    if actor_role == "patient_proxy" and payload.get("status") == "approved":
        raise ValueError("patient_proxy cannot approve a clinical goal")
    goal = {
        "goal_id": payload.get("goal_id") or new_id("goal"),
        "display_name": display_name,
        "status": payload.get("status") or "proposed",
        "target_date": payload.get("target_date"),
        "source_intent_id": payload.get("source_intent_id"),
        "metrics": list(payload.get("metrics", [])),
        "raw_expression": payload.get("raw_expression") or display_name,
        "recorded_by": actor_role,
        "recorded_at": payload.get("recorded_at") or utc_now(),
    }
    episode.setdefault("goals", []).append(goal)
    return goal


def simulate_rehab_session(
    session: dict[str, Any],
    *,
    device: dict[str, Any] | None,
    sample_count: int = 120,
) -> dict[str, Any]:
    gate = validate_rehab_session(session, device=device)
    if gate["gate_status"] == "blocked":
        return {"gate": gate, "samples": [], "metrics": {}, "simulation_executed": False}
    sample_count = max(20, min(int(sample_count), 1000))
    seed = int(session.get("simulation_seed", 41))
    rng = random.Random(seed)
    duration_seconds = float(session.get("duration_seconds", 180.0))
    samples: list[dict[str, Any]] = []
    assistance_values: list[float] = []
    angle_values: list[float] = []
    balance_values: list[float] = []
    fatigue_values: list[float] = []
    for idx in range(sample_count):
        phase = idx / max(1, sample_count - 1)
        t = phase * duration_seconds
        angle = 34.0 + 18.0 * math.sin(phase * math.pi * 6) + rng.uniform(-1.1, 1.1)
        assistance = max(0.0, 20.0 - 7.0 * phase + 3.2 * math.sin(phase * math.pi * 4) + rng.uniform(-0.8, 0.8))
        balance = min(1.0, max(0.0, 0.48 + 0.32 * phase + rng.uniform(-0.035, 0.035)))
        fatigue = min(1.0, max(0.0, 0.12 + 0.62 * phase + rng.uniform(-0.025, 0.025)))
        recorded_at = f"T+{t:.2f}s"
        for channel, value, unit in [
            ("joint_angle", angle, "degree"),
            ("assistance_force", assistance, "N"),
            ("balance_proxy", balance, "ratio"),
            ("fatigue_proxy", fatigue, "ratio"),
        ]:
            samples.append(
                {
                    "sequence": idx,
                    "recorded_at": recorded_at,
                    "channel": channel,
                    "numeric_value": round(value, 6),
                    "unit": unit,
                    "metadata": {"synthetic": True, "clinical_interpretation": False},
                }
            )
        angle_values.append(angle)
        assistance_values.append(assistance)
        balance_values.append(balance)
        fatigue_values.append(fatigue)
    metrics = {
        "sample_frames": sample_count,
        "duration_seconds": duration_seconds,
        "mean_assistance_force_n": round(sum(assistance_values) / sample_count, 4),
        "peak_assistance_force_n": round(max(assistance_values), 4),
        "joint_angle_range_degree": round(max(angle_values) - min(angle_values), 4),
        "balance_proxy_change": round(balance_values[-1] - balance_values[0], 4),
        "fatigue_proxy_end": round(fatigue_values[-1], 4),
        "synthetic_only": True,
        "clinical_interpretation": False,
    }
    return {"gate": gate, "samples": samples, "metrics": metrics, "simulation_executed": True}


def merge_session_metrics(session: dict[str, Any], simulation: dict[str, Any]) -> dict[str, Any]:
    session["metrics"] = simulation.get("metrics", {})
    session["safety_gate"] = simulation.get("gate", {})
    session["status"] = "completed" if simulation.get("simulation_executed") else "held"
    session["updated_at"] = utc_now()
    return session
